import sys, importlib, pandas as pd, engine
from common import *
def run(variant):
    import engine as E
    orig=E.static_flags
    def sf(r):
        f=orig(r)
        if variant.get('old_filing') and r.payer_id=='PY01': f['D03']= r.lag>30
        if variant.get('no_u3') and r.payer_id=='PY02' and r.svc=='T1019': f['D04']= r['mod']!='U2'
        return f
    E.static_flags=sf
    g={'__name__':'x'}
    src=open('sim2.py').read().split("H=allc[allc.src=='hist']")[0]
    exec(src,g)
    E.static_flags=orig
    return g['allc'][['claim_id','src','pred','denial_code','status','payer_id','dos','lag']].copy()
base=run({})
for name,v in [('old_filing',{'old_filing':1}),('no_u3',{'no_u3':1})]:
    o=run(v); m=base.merge(o[['claim_id','pred']],on='claim_id',suffixes=('','_alt'))
    ch=m[m.pred!=m.pred_alt]
    print('==',name,'changed preds',ch.groupby('src').size().to_dict())
    print(ch.groupby(['src','pred_alt','pred']).size().to_string())
    h=m[m.src=='hist']
    for c in ['pred','pred_alt']:
        print(c,'exact',round((h[c]==h.denial_code).mean(),4),'status',round(((h[c]=='')==(h.status=='paid')).mean(),4))
    hc=ch[ch.src=='hist']; print('hist changed: actual',hc.denial_code.replace('','PAID').value_counts().to_dict())
