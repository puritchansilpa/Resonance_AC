import pandas as pd
a=pd.read_pickle('allc.pkl'); H=a[a.src=='hist']
x=H[(H.denial_code=='D02')&(H.pred=='D03')]
print(x[['claim_id','payer_id','dos','sub','lag','units','D01','D09','D07','D08']].to_string())
# D03 flagged but not reported: what were they
y=H[H.D03.astype(bool)]
print(pd.crosstab(y.payer_id,y.denial_code.replace('','PAID')))
z=H[(H.denial_code=='D10')|(H.remark.str.contains('amendment'))]
print(pd.crosstab(z.denial_code,z.pred))
print(H[(H.denial_code=='D10')&(H.pred=='D05')][['claim_id','D05','D09']])
