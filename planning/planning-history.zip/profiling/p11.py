import pandas as pd
h=pd.read_pickle('h2.pkl')
h['amend']=h.remark.str.contains('amendment 3')
p=h[(h.payer_id=='PY03')].copy(); p['nonhour']=p.units%4!=0
p['code']=p.denial_code.replace('','PAID')
p.loc[p.amend,'code']=p.loc[p.amend,'code']+'*'
print(pd.crosstab([p.nonhour,p.dos.dt.to_period('M')],p.code).to_string())
print(pd.crosstab([p.nonhour,p['sub'].dt.to_period('M')],p.code).to_string())
n=p[p.nonhour&(p.nf==0)]
print(pd.crosstab(n.svc,n.code))
