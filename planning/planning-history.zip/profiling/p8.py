import pandas as pd
from engine import A
h=pd.read_pickle('h.pkl')
codes=['D01','D03','D04','D05','D07','D08','D09']
h['nf']=h[codes].sum(axis=1)
h=h.sort_values(['sub','claim_id']).reset_index(drop=True)
rem={k:v for k,v in A.u.items()}
day={}
h['exceed_auth']=False; h['exceed_day']=False; h['rem_before']=None
for i,r in h.iterrows():
    if r.auth_id:
        h.at[i,'rem_before']=rem[r.auth_id]
        h.at[i,'exceed_auth']= r.units>rem[r.auth_id]
    if r.payer_id=='PY02':
        k=(r.patient_id,r.dos); h.at[i,'exceed_day']= day.get(k,0)+r.units>32
    if r.status=='paid':
        if r.auth_id: rem[r.auth_id]-=r.units
        if r.payer_id=='PY02': day[k]=day.get(k,0)+r.units
print('neg balance auths',sum(v<0 for v in rem.values()))
c=h[h.nf==0]
print('no static flag: exceed_auth x code');print(pd.crosstab(c.exceed_auth,c.denial_code.replace('','PAID')))
print('no static flag PY02: exceed_day x code');print(pd.crosstab(c[c.payer_id=='PY02'].exceed_day,c[c.payer_id=='PY02'].denial_code.replace('','PAID')))
s=h[h.nf>0]
print('static flagged & exceed_auth',s.exceed_auth.sum(),'static&exceed_day',s.exceed_day.sum())
print(pd.crosstab(c.exceed_auth & c.exceed_day, c.denial_code.replace('','PAID')))
# PY02 daily: is it across all payers? patient has one payer; check daily totals
h.to_pickle('h2.pkl')
