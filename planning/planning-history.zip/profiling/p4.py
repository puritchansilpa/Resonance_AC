from common import *
e=load('evv_visits'); a=load('authorizations'); h=load('claims_history')
h=h.drop_duplicates(subset=[c for c in h.columns if c not in()][:17])
a=a.set_index('auth_id')
d8=h[h.denial_code=='D08']
m=d8.join(a,on='auth_id',rsuffix='_a')
m['inrange']=(m.dos>=pd.to_datetime(m.start_date))&(m.dos<=pd.to_datetime(m.end_date))
print(pd.crosstab(m.remark,m.inrange))
print(m[m.remark=='Auth/service mismatch'][['claim_id','patient_id','svc','dos','auth_id','patient_id_a','service_code_a','start_date','end_date']].head(8).to_string())
