import itertools, pandas as pd
from flagsim import run
ALL=['D01','D02','D03','D04','D05','D06','D07','D08','D09','D10']
NAIVE={p:ALL for p in ['PY01','PY02','PY03']}   # order of denial_codes.md, no tuning
V1={'PY01':['D01','D09','D07','D08','D02','D03','D05'],
    'PY02':['D01','D09','D07','D08','D04','D05','D06','D02'],
    'PY03':['D01','D07','D08','D10','D09','D02','D03','D05']}
def learn(df):
    """pairwise wins among multi-flag denied claims -> per-payer order by (wins-losses), fallback naive order"""
    out={}; ev={}
    for p in ['PY01','PY02','PY03']:
        W={}
        for _,r in df[(df.payer_id==p)&(df.fl.str.len()>1)&(df.status=='denied')].iterrows():
            if r.denial_code not in r.fl: continue
            for y in r.fl:
                if y!=r.denial_code: W[(r.denial_code,y)]=W.get((r.denial_code,y),0)+1
        score={c:sum(v for (a,b),v in W.items() if a==c)-sum(v for (a,b),v in W.items() if b==c) for c in ALL}
        out[p]=sorted(ALL,key=lambda c:(-score[c],ALL.index(c))); ev[p]=W
    return out,ev
def metrics(d,lab):
    st=((d.pred=='')==(d.status=='paid')).mean(); ex=(d.pred==d.denial_code).mean()
    den=d.status=='denied'; pden=d.pred!=''
    tp=(den&pden).sum(); fp=(~den&pden).sum(); fn=(den&~pden).sum()
    held=d[~den&pden].billed_amount.astype(float).sum()
    mf=d[d.fl.str.len()>1]; mfa=(mf.pred==mf.denial_code).mean() if len(mf) else float('nan')
    cd=d[den&pden]; ca=(cd.pred==cd.denial_code).mean()
    print(f'{lab:38s} n={len(d):4d} status={st:.4f} exact={ex:.4f} code|both-denied={ca:.4f} denyP={tp/(tp+fp):.4f} denyR={tp/(tp+fn):.4f} falseHolds={fp} (${held:.0f}) missed={fn} multiflag n={len(mf)} acc={mfa:.3f}')
# 1) flags with naive precedence (flags don't depend on precedence except via paid-state for to_check; hist uses actual)
base=run(NAIVE)
H=base[base.src=='hist']
train=H[H.dos<'2026-09-01']; test=H[H.dos>='2026-09-01']
L,ev=learn(train); print('learned on Jun-Aug:',L)
for name,prec,use10 in [('naive order, no amendment',NAIVE,False),('naive order + amendment(learned Jun-Aug)',NAIVE,True),('learned Jun-Aug order + amendment',L,True),('v1 order (fit on all) + amendment',V1,True)]:
    d=run(prec,use_d10=use10); h=d[d.src=='hist']
    print('==',name)
    metrics(h[h.dos<'2026-09-01'],'  train Jun-Aug'); metrics(h[h.dos>='2026-09-01'],'  test Sep-Oct'); metrics(h,'  all')
    d.to_pickle(f'run_{name.split()[0]}_{int(use10)}.pkl')
