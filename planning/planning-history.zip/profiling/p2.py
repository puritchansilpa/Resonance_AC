from common import *
for n in ['claims_history','claims_to_check']:
    df=pd.read_csv(D+n+'.csv',dtype=str,keep_default_na=False)
    for c in ['date_of_service','submitted_date']:
        sl=df[c][df[c].str.contains('/')]
        a=sl.str.split('/').str[0].astype(int); b=sl.str.split('/').str[1].astype(int)
        print(n,c,'slash n',len(sl),'first>12',(a>12).sum(),'second>12',(b>12).sum(),'both<=12',((a<=12)&(b<=12)).sum())
h=load('claims_history'); t=load('claims_to_check')
for n,df in [('hist',h),('check',t)]:
    print(n,'dos',df.dos.min(),df.dos.max(),'sub',df['sub'].min(),df['sub'].max())
    print(' lag describe',df.lag.describe().to_dict(), 'neg lag',(df.lag<0).sum())
    print(' dos by month',df.dos.dt.to_period('M').value_counts().sort_index().to_dict())
    print(' payer',df.payer_id.value_counts().to_dict(), 'svc',df.svc.value_counts().to_dict())
    print(' payer x mod',pd.crosstab(df.payer_id,df['mod']).to_dict())
    print(' svc x mod',pd.crosstab(df.svc,df['mod']).to_dict())
# dup claim ids
d=h[h.claim_id.duplicated(keep=False)].sort_values('claim_id')
print('dup id rows',len(d),'exact dup rows', h.duplicated(subset=list(h.columns[:17]),keep='first').sum())
print(d.head(6).to_string())
# differing dup?
g=d.groupby('claim_id').nunique()
print('cols differing within dup ids', (g>1).sum()[lambda s:s>0].to_dict())
print('check ids in hist', t.claim_id.isin(h.claim_id).sum())
print('orig ids in hist', t.original_claim_id[t.original_claim_id!=''].isin(h.claim_id).sum())
print('status by payer');print(pd.crosstab(h.payer_id,h.status))
print(pd.crosstab(h.denial_code,h.payer_id,margins=True))
print(pd.crosstab([h.denial_code],h.remark).T.to_string())
