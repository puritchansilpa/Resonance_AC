import pandas as pd
h=pd.read_pickle('h2.pkl')
h['amend']=h.remark.str.contains('amendment 3')
p=h[h.payer_id=='PY03'].copy(); p['nonhour']=p.units%4!=0
print('amend remarks by code',h[h.amend].denial_code.value_counts().to_dict(),'payers',h[h.amend].payer_id.value_counts().to_dict())
print('amend by agency',h[h.amend].agency_id.value_counts().to_dict())
print('amend dos range',h[h.amend].dos.min(),h[h.amend].dos.max(),'sub range',h[h.amend]['sub'].min(),h[h.amend]['sub'].max())
print('amend units',h[h.amend].units.value_counts().to_dict())
print('amend svc',h[h.amend].svc.value_counts().to_dict())
q=p[p.nf==0]
print(pd.crosstab([q.agency_id],[q.nonhour,q.denial_code.replace('','PAID')]).to_string())
