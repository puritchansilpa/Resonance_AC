from engine import *
PREC={'PY01':['D01','D09','D07','D08','D03','D05','D02'],
      'PY02':['D01','D09','D07','D08','D04','D05','D06','D02'],
      'PY03':['D01','D07','D08','D09','D03','D05','D10','D02']}
h=load('claims_history'); h=h.drop_duplicates(subset=list(h.columns[:17])); h['src']='hist'
t=load('claims_to_check'); t['src']='check'
allc=pd.concat([h,t],ignore_index=True).sort_values(['sub','claim_id']).reset_index(drop=True)
F=pd.DataFrame([static_flags(r) for _,r in allc.iterrows()]); allc=pd.concat([allc,F],axis=1)
rem=dict(A.u); day={}; seen=set()
pred=[];
for i,r in allc.iterrows():
    f={c:bool(r[c]) for c in F.columns}
    key=(r.patient_id,r.svc,r.dos,r.payer_id)
    f['D05']= r.frequency_code=='1' and key in seen
    seen.add(key)
    f['D10']= r.payer_id=='PY03' and r.dos>=pd.Timestamp('2026-07-01') and r.units%4!=0
    f['D02']= bool(r.auth_id) and r.units>rem[r.auth_id]
    f['D06']= r.payer_id=='PY02' and day.get((r.patient_id,r.dos),0)+r.units>32
    code=next((c for c in PREC[r.payer_id] if f.get(c)),'')
    pred.append(code)
    paid = (r.status=='paid') if r.src=='hist' else (code=='')
    if paid:
        if r.auth_id: rem[r.auth_id]-=r.units
        if r.payer_id=='PY02': day[(r.patient_id,r.dos)]=day.get((r.patient_id,r.dos),0)+r.units
allc['pred']=pred
allc['nflags_all']=[0]*len(allc)
allc.to_pickle('allc.pkl')
H=allc[allc.src=='hist']
H_true=H.denial_code
print('hist n',len(H),'status acc',((H.pred=='')==(H.status=='paid')).mean(),'exact acc',(H.pred==H_true).mean())
print(pd.crosstab(H_true.replace('','PAID'),H.pred.replace('','PAID')).to_string())
for p in ['PY01','PY02','PY03']:
    x=H[H.payer_id==p]; print(p,len(x),'status',round(((x.pred=='')==(x.status=='paid')).mean(),4),'exact',round((x.pred==x.denial_code).mean(),4))
x=H[(H.payer_id=='PY01')]; 
for lab,m in [('PY01 dos<Aug1',x.dos<'2026-08-01'),('PY01 dos>=Aug1',x.dos>='2026-08-01')]:
    y=x[m]; print(lab,len(y),'D03 true',(y.denial_code=='D03').sum(),'exact',round((y.pred==y.denial_code).mean(),4))
x=H[(H.payer_id=='PY02')&(H.svc=='T1019')]
for lab,m in [('PY02 T1019 pre-Sep',x.dos<'2026-09-01'),('PY02 T1019 Sep+ wkend',(x.dos>='2026-09-01')&(x.dos.dt.dayofweek>=5)),('PY02 T1019 Sep+ wkday',(x.dos>='2026-09-01')&(x.dos.dt.dayofweek<5))]:
    y=x[m]; print(lab,len(y),'D04 true',(y.denial_code=='D04').sum(),'exact',round((y.pred==y.denial_code).mean(),4))
T=allc[allc.src=='check']
print('check n',len(T),'pred dist',T.pred.replace('','PAID').value_counts().to_dict())
print('check by payer',pd.crosstab(T.payer_id,T.pred.replace('','PAID')).to_string())
print('freq7 preds',T[T.frequency_code=='7'].pred.replace('','PAID').value_counts().to_dict())
