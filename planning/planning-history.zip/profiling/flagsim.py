"""Chronological pass recording ALL flags per claim (history ∪ to_check). Precedence applied later."""
from engine import *
def run(prec, use_d10=True, d10_from='2026-07-01', tie_desc=False, hist_state='actual'):
    h=load('claims_history'); h=h.drop_duplicates(subset=list(h.columns[:17])); h['src']='hist'
    t=load('claims_to_check'); t['src']='check'
    allc=pd.concat([h,t],ignore_index=True)
    allc=allc.sort_values(['sub','claim_id'],ascending=[True, not tie_desc]).reset_index(drop=True)
    F=pd.DataFrame([static_flags(r) for _,r in allc.iterrows()]); allc=pd.concat([allc,F],axis=1)
    rem=dict(A.u); day={}; seen=set(); preds=[]; flags=[]; dep=[]
    paid_by={}  # auth -> list of (src) paid draws
    for i,r in allc.iterrows():
        f={c:bool(r[c]) for c in F.columns}
        key=(r.patient_id,r.svc,r.dos,r.payer_id)
        f['D05']= r.frequency_code=='1' and key in seen; seen.add(key)
        f['D10']= use_d10 and r.payer_id=='PY03' and r.dos>=pd.Timestamp(d10_from) and r.units%4!=0
        f['D02']= bool(r.auth_id) and r.units>rem[r.auth_id]
        # would D02 hold if to_check draws were excluded?
        if f['D02']:
            chk=sum(u for s,u in paid_by.get(r.auth_id,[]) if s=='check')
            dep.append(r.units<=rem[r.auth_id]+chk)
        else: dep.append(False)
        f['D06']= r.payer_id=='PY02' and day.get((r.patient_id,r.dos),0)+r.units>32
        fl=[c for c in f if f[c]]
        code=next((c for c in prec[r.payer_id] if c in fl),'')
        preds.append(code); flags.append(fl)
        if r.src=='hist' and hist_state=='actual': paid=r.status=='paid'
        else: paid= code==''
        if paid:
            if r.auth_id: rem[r.auth_id]-=r.units; paid_by.setdefault(r.auth_id,[]).append((r.src,r.units))
            if r.payer_id=='PY02': day[(r.patient_id,r.dos)]=day.get((r.patient_id,r.dos),0)+r.units
    allc['pred']=preds; allc['fl']=flags; allc['d02_dep_check']=dep
    return allc
