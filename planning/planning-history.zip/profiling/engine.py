from common import *
import math
e=load('evv_visits'); a=load('authorizations')
e['ci']=pd.to_datetime(e.clock_in); e['co']=pd.to_datetime(e.clock_out)
e['mins']=(e.co-e.ci).dt.total_seconds()/60; e['day']=e.ci.dt.normalize()
ver=e[e.verification_status=='verified'].groupby(['patient_id','service_code','day']).mins.sum()
anyv=e.groupby(['patient_id','service_code','day']).verification_status.agg(lambda s:','.join(sorted(set(s))))
A=a.set_index('auth_id'); A['u']=A.units_authorized.astype(int); A['s']=pd.to_datetime(A.start_date); A['e']=pd.to_datetime(A.end_date)
def units_from(m,p):
    if p=='PY01': return int(m//15)+(1 if m%15>=8 else 0)
    return int(m//15)
def static_flags(r):
    f={}
    k=(r.patient_id,r.svc,r.dos)
    m=ver.get(k)
    f['D01']= m is None
    f['D09']= (m is not None) and r.units>units_from(m,r.payer_id)
    lim={'PY01':(45 if r.dos>=pd.Timestamp('2026-08-01') else 30),'PY03':60}.get(r.payer_id)
    f['D03']= lim is not None and r.lag>lim
    f['D07']= r.auth_id==''
    if r.auth_id:
        x=A.loc[r.auth_id]
        f['D08']= not (x.patient_id==r.patient_id and x.service_code==r.svc and x.payer_id==r.payer_id and x.s<=r.dos<=x.e)
    else: f['D08']=False
    if r.payer_id=='PY02' and r.svc=='T1019':
        need='U3' if (r.dos>=pd.Timestamp('2026-09-01') and r.dos.dayofweek>=5) else 'U2'
        f['D04']= r['mod']!=need
    else: f['D04']=False
    return f
