from engine import *
h=load('claims_history'); h=h.drop_duplicates(subset=list(h.columns[:17])).reset_index(drop=True)
F=pd.DataFrame([static_flags(r) for r in h.itertuples(index=False)] if False else [static_flags(r) for _,r in h.iterrows()])
h=pd.concat([h,F],axis=1)
print('paid amount==billed for paid',(h[h.status=="paid"].paid_amount.astype(float)==h[h.status=="paid"].billed_amount.astype(float)).mean())
# duplicates: freq1 same key submitted earlier
h=h.sort_values(['sub','claim_id']).reset_index(drop=True)
key=h.patient_id+'|'+h.svc+'|'+h.dos.astype(str)+'|'+h.payer_id
h['D05']=key.duplicated(keep='first')
same=h[key.duplicated(keep=False)].groupby(key).agg(n=('claim_id','size'),subs=('sub','nunique'))
print('dup groups',len(same),'groups with same-day submissions', (same.subs<same.n).sum())
codes=['D01','D02','D03','D04','D05','D06','D07','D08','D09']
for c in ['D01','D03','D04','D05','D07','D08','D09']:
    print(c,'flagged',h[c].sum(),'flag&denied',(h[c]&(h.status=='denied')).sum(),'flag&reported',(h[c]&(h.denial_code==c)).sum(),'reported',(h.denial_code==c).sum(), 'reported&notflag',((h.denial_code==c)&~h[c]).sum())
h.to_pickle('h.pkl')
