import pandas as pd, itertools
h=pd.read_pickle('h.pkl')
codes=['D01','D03','D04','D05','D07','D08','D09']
h['nflags']=h[codes].sum(axis=1)
print('static flag count dist',h.nflags.value_counts().to_dict())
mf=h[h.nflags>1]
print('multi-flag claims',len(mf))
mf=mf.assign(fl=mf[codes].apply(lambda r:'+'.join(c for c in codes if r[c]),axis=1))
print(pd.crosstab(mf.fl,mf.denial_code))
# pairwise wins
W={}
for _,r in mf.iterrows():
    fl=[c for c in codes if r[c]]
    for x,y in itertools.permutations(fl,2):
        if r.denial_code==x: W[(x,y)]=W.get((x,y),0)+1
for c1 in codes:
    print(c1,{c2:W.get((c1,c2),0) for c2 in codes if c2!=c1})
# unflagged denials
print(h[(h.nflags==0)&(h.status=='denied')].denial_code.value_counts().to_dict())
