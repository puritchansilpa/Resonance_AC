import pandas as pd, re
D='/workspace/resonance-ac/brief/data/'
def pat(s):
    s=str(s)
    return re.sub(r'\d','9',s)
for f in ['claims_history','claims_to_check','authorizations','evv_visits']:
    df=pd.read_csv(D+f+'.csv',dtype=str,keep_default_na=False)
    print('=====',f,df.shape)
    for c in df.columns:
        vc=df[c].value_counts()
        print(f'-- {c}: nunique={df[c].nunique()} blanks={(df[c].str.strip()=="").sum()}')
        if c.endswith('date') or c in('clock_in','clock_out'):
            print('   patterns:',df[c].map(pat).value_counts().to_dict())
        elif df[c].nunique()<=40:
            print('   ',{repr(k):v for k,v in vc.items()})
        else:
            print('   sample',list(vc.index[:5]), 'patterns', df[c].map(pat).value_counts().head(6).to_dict())
