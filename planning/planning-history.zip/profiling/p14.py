import pandas as pd
a=pd.read_pickle('allc.pkl'); H=a[a.src=='hist']
err=H[H.pred!=H.denial_code]
print(err.groupby(['payer_id','denial_code','pred']).size())
