from engine import *
a=pd.read_pickle('allc.pkl'); H=a[a.src=='hist']; T=a[a.src=='check']
print('id ranges hist',H.claim_id.min(),H.claim_id.max(),'check',T.claim_id.min(),T.claim_id.max())
def mins(r): return ver.get((r.patient_id,r.svc,r.dos))
H=H.copy(); H['m']=H.apply(mins,axis=1)
k=H[H.m.notna()].copy()
k['floor']=(k.m//15).astype(int); k['eight']=k.floor+((k.m%15)>=8).astype(int)
for p in ['PY01','PY02','PY03']:
    x=k[k.payer_id==p]
    print(p,'units==floor+1 & m%15>=8:',((x.units==x.eight)&(x.eight>x.floor)).sum(),'-> status',x[(x.units==x.eight)&(x.eight>x.floor)].denial_code.replace('','PAID').value_counts().to_dict())
    print(p,'units<=floor',(x.units<=x.floor).sum(),'units>eight',(x.units>x.eight).sum())
# D01 split: no EVV at all vs only unverified
st=anyv
d1=H[H.denial_code=='D01']
s=d1.apply(lambda r: st.get((r.patient_id,r.svc,r.dos),'none'),axis=1)
print('D01 evv status',s.value_counts().to_dict())
# wrong-date: EVV exists for patient/svc within +-1 day
# overnight visits relevance
e2=e[e.co.dt.normalize()>e.day]
print('overnight visits',len(e2),'verified',(e2.verification_status=='verified').sum())
# claims whose dos = clock-out date of overnight visit (next-day trap)
nx=set(zip(e2.patient_id,e2.service_code,e2.co.dt.normalize()))
trap=a[[ (r.patient_id,r.svc,r.dos) in nx for r in a.itertuples()]]
print('claims dated on overnight clock-out day',len(trap),trap.groupby('src').pred.apply(lambda s:s.replace('','PAID').value_counts().to_dict()).to_dict())
print(H[[ (r.patient_id,r.svc,r.dos) in nx for r in H.itertuples()]].denial_code.replace('','PAID').value_counts().to_dict())
# multi visit days
mv=e[e.verification_status=='verified'].groupby(['patient_id','service_code','day']).size(); mv=mv[mv>1]
mk=set(mv.index); print('multi-visit claims',sum((r.patient_id,r.svc,r.dos) in mk for r in a.itertuples()))
# date format by agency
raw=pd.read_csv(D+'claims_history.csv',dtype=str)
raw['slash']=raw.date_of_service.str.contains('/')|raw.submitted_date.str.contains('/')
print('slash rows by agency',raw.groupby('agency_id').slash.mean().round(2).to_dict())
print('rows with any slash date hist',raw.slash.sum())
# auth units drawdown overall
print('auth period units', A.groupby('s').u.sum().to_dict())
# weekend T1019 PY02 sep+ in check w/ U2
