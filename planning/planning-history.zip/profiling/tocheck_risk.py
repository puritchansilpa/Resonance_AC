import pandas as pd
from flagsim import run
from holdout import V1, learn
import engine
d=pd.read_pickle('run_v1_1.pkl'); H=d[d.src=='hist']; T=d[d.src=='check']
_,ev=learn(H)  # pair evidence on all history
print('to_check pred dist',T.pred.replace('','PAID').value_counts().to_dict())
print('DOS after last hist DOS',(T.dos>H.dos.max()).sum(), 'last hist dos',H.dos.max().date())
mf=T[T.fl.str.len()>1]; print('to_check multi-flag',len(mf))
thin=[]
for _,r in mf.iterrows():
    W=ev[r.payer_id]; w=r.pred
    mins=min(W.get((w,y),0)+W.get((y,w),0) for y in r.fl if y!=w) if w else 0
    thin.append(mins)
mf=mf.assign(minev=thin)
print('multi-flag by min pair evidence', mf.minev.value_counts().sort_index().to_dict())
print(mf[mf.minev<=1][['claim_id','payer_id','fl','pred','minev']].to_string())
print('D02 preds that depend on earlier to_check paid draws', (T.d02_dep_check & (T.pred=='D02')).sum(), 'of', (T.pred=='D02').sum())
print('hist D02 depending on to_check draws', (H.d02_dep_check & (H.denial_code=='D02')).sum())
t2=run(V1,tie_desc=True); T2=t2[t2.src=='check'].set_index('claim_id').pred
ch=(T.set_index('claim_id').pred!=T2.reindex(T.claim_id).values); print('tie-order sensitive to_check',ch.sum())
H2=t2[t2.src=='hist'].set_index('claim_id'); hh=H.set_index('claim_id'); print('tie-order sensitive hist preds',(hh.pred!=H2.pred.reindex(hh.index)).sum(), 'exact reversed', (H2.pred==H2.denial_code).mean())
# D05 between two to_check claims
d5=T[T.pred=='D05']
key=lambda df: df.patient_id+'|'+df.svc+'|'+df.dos.astype(str)+'|'+df.payer_id
hk=set(key(H)); print('D05 preds',len(d5),'first claim in history',key(d5).isin(hk).sum(),'first claim in to_check',(~key(d5).isin(hk)).sum())
# D05 flagged anywhere
print('to_check with D05 flag',T.fl.apply(lambda f:'D05' in f).sum())
# freq7
f7=T[T.frequency_code=='7']; print('freq7 preds',f7.pred.replace('','PAID').value_counts().to_dict())
# D01 split
st=engine.anyv
d1=T[T.pred=='D01']; print('D01 preds evv status',d1.apply(lambda r: st.get((r.patient_id,r.svc,r.dos),'none'),axis=1).value_counts().to_dict())
# fully simulated history state
ds=run(V1,hist_state='predicted'); Ts=ds[ds.src=='check'].set_index('claim_id').pred
print('to_check preds changed if history outcomes are simulated not actual',(T.set_index('claim_id').pred!=Ts.reindex(T.claim_id).values).sum())
Hs=ds[ds.src=='hist']; print('hist exact under simulated state',(Hs.pred==Hs.denial_code).mean())
