import pandas as pd
h=pd.read_pickle('h2.pkl')
x=h[(h.nf==0)&(h.denial_code=='D02')&(~h.exceed_auth)]
for _,r in x.iterrows():
    g=h[h.auth_id==r.auth_id][['claim_id','sub','dos','units','status','denial_code','rem_before','submitted_date']]
    print(r.claim_id,r.payer_id,r.remark); print(g.to_string()); print()
