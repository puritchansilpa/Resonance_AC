import pandas as pd, numpy as np
D='/workspace/resonance-ac/brief/data/'
PAYER={'PY01':'PY01','NORTHWIND HP':'PY01','Northwind Health Plan':'PY01','PY02':'PY02','Harbor Medicaid Plan':'PY02','Harbor Medicaid':'PY02','PY03':'PY03','SUMMIT CARE':'PY03','Summit Care Partners':'PY03'}
def pdate(s):
    s=s.strip()
    if '/' in s: return pd.to_datetime(s,format='%m/%d/%Y')
    return pd.to_datetime(s,format='%Y-%m-%d')
def load(name):
    df=pd.read_csv(D+name+'.csv',dtype=str,keep_default_na=False)
    if 'payer' in df:
        df['payer_id']=df.payer.map(PAYER)
        df['svc']=df.service_code.str.strip()
        df['mod']=df.modifier.str.strip().str.upper()
        df['dos']=df.date_of_service.map(pdate)
        df['sub']=df.submitted_date.map(pdate)
        df['units']=df.units.astype(int)
        df['lag']=(df['sub']-df['dos']).dt.days
    return df
