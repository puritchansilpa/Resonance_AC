import pandas as pd
h=pd.read_pickle('h.pkl')
codes=['D01','D03','D04','D05','D07','D08','D09']
h['fl']=h[codes].apply(lambda r:'+'.join(c for c in codes if r[c]),axis=1)
mf=h[h.fl.str.count(r'\+')>=1]
print(mf.groupby(['fl','payer_id','denial_code']).size().to_string())
