import pandas as pd
h=pd.read_pickle('h2.pkl')
am=h[h.remark.str.contains('amendment 3')]
print(pd.crosstab(am.agency_id,am.denial_code).T.to_string())
print(pd.crosstab(am.remark,am.denial_code))
print(pd.crosstab(am['sub'].dt.to_period('M'),am.denial_code))
d=h[(h.denial_code=='D99')&~h.remark.str.contains('amendment')]
print('D99 other n',len(d),'by payer',d.payer_id.value_counts().to_dict(),'agency',d.agency_id.value_counts().to_dict())
print('D99 svc',d.svc.value_counts().to_dict(),'nf',d.nf.value_counts().to_dict())
print('D99 dos month',d.dos.dt.to_period('M').value_counts().sort_index().to_dict())
print('D99 rate overall among no-flag', len(d[d.nf==0])/len(h[h.nf==0]))
