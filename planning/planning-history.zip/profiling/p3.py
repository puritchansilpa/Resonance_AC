from common import *
e=load('evv_visits'); a=load('authorizations'); h=load('claims_history'); t=load('claims_to_check')
e['ci']=pd.to_datetime(e.clock_in); e['co']=pd.to_datetime(e.clock_out)
e['mins']=(e.co-e.ci).dt.total_seconds()/60
e['day']=e.ci.dt.normalize()
print('mins describe',e.mins.describe().to_dict(),'neg/zero',(e.mins<=0).sum())
print('overnight',(e.co.dt.normalize()>e.day).sum())
print('evv date range',e.ci.min(),e.co.max())
g=e.groupby(['patient_id','service_code','day']).size()
print('patient-svc-day groups',len(g),'with >1 visit',(g>1).sum(), 'max',g.max())
gv=e[e.verification_status=='verified'].groupby(['patient_id','service_code','day']).size()
print('verified groups',len(gv),'multi',(gv>1).sum())
# mixed status in a group
st=e.groupby(['patient_id','service_code','day']).verification_status.agg(lambda s:','.join(sorted(set(s))))
print(st.value_counts().to_dict())
print('mins mod 15 ==0 share', (e.mins%15==0).mean(), 'minute remainder dist', (e.mins%15).value_counts().sort_index().to_dict())
print('auth start/end',a.start_date.value_counts().to_dict(),a.end_date.value_counts().to_dict())
a['u']=a.units_authorized.astype(int); print('units auth',a.u.describe().to_dict())
print('auths per patient-payer-svc', a.groupby(['patient_id','payer_id','service_code']).size().value_counts().to_dict())
print('patients with >1 payer in auths', (a.groupby('patient_id').payer_id.nunique()>1).sum())
for n,df in [('hist',h),('check',t)]:
    m=df.merge(a[['auth_id','patient_id','payer_id','service_code','start_date','end_date']],on='auth_id',how='left',suffixes=('','_a'))
    has=df.auth_id!=''
    print(n,'auth present',has.sum(),'auth found',m.patient_id_a.notna().sum(),
      'pt mismatch',(has&(m.patient_id!=m.patient_id_a)).sum(),'svc mismatch',(has&(m.svc!=m.service_code_a)).sum(),
      'payer mismatch',(has&(m.payer_id!=m.payer_id_a)).sum(),
      'dos out of range',(has&((m.dos<pd.to_datetime(m.start_date))|(m.dos>pd.to_datetime(m.end_date)))).sum())
    k=df.merge(e.assign(dos=e.day)[['patient_id','service_code','dos']].drop_duplicates(),left_on=['patient_id','svc','dos'],right_on=['patient_id','service_code','dos'],how='left',indicator=True)
    print(n,'claims with any EVV match',(k._merge=='both').sum(),'of',len(df))
    # weekday
    print(n,'PY02 T1019 by weekend/period x mod')
    s=df[(df.payer_id=='PY02')&(df.svc=='T1019')].copy(); s['wknd']=s.dos.dt.dayofweek>=5; s['post']=s.dos>=pd.Timestamp('2026-09-01')
    print(pd.crosstab([s.post,s.wknd],s['mod']).to_string() if n=='check' else pd.crosstab([s.post,s.wknd],[s['mod'],s.status]).to_string())
