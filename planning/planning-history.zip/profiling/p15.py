import pandas as pd
a=pd.read_pickle('allc.pkl'); H=a[a.src=='hist']; T=a[a.src=='check']
print('check sub range',T['sub'].min(),T['sub'].max(),'hist sub max',H['sub'].max())
print('check claims submitted before last hist sub',(T['sub']<H['sub'].max()).sum())
print('check sub by month',T['sub'].dt.to_period('M').value_counts().sort_index().to_dict())
print('hist sub by month',H['sub'].dt.to_period('M').value_counts().sort_index().to_dict())
ids=['C011708','C001931','C010286','C007353','C018598','C007300','C017711','C011120','C016741','C005201']
for cid in ids[:3]:
    r=H[H.claim_id==cid].iloc[0]
    print(cid, a[(a.auth_id==r.auth_id)][['claim_id','src','sub','units','status','pred']].to_string())
# same auth shared hist/check
print('check auths also in hist',T.auth_id[T.auth_id!=''].isin(H.auth_id).mean())
# dup key check-vs-hist
