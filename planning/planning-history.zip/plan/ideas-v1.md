# Ideas v1: going past "the assistant"

*Claims Visionary pass. Every number below comes from a script run on `brief/data/` (pandas, payer names and dates normalised first) or from the brief. Anything not derivable is labelled **ASSUMPTION**.*

---

## The one-paragraph thesis

Leadership asked for a billing-team assistant that catches bad claims before submission. The data says that's the wrong place to stand. **Of the 1,104 denials in `claims_history.csv`, 604 (54.7% by count, $67,594 = 58.5% of the $115,472 denied) carry codes whose cause existed before anyone opened a billing screen** (D01 no verified EVV, D09 units over EVV time, D06 daily max, D10 contract hourly rule, D02 auth exhausted). Those are visit, schedule and authorization problems. Exchange4Health is the only company that owns the visit, the schedule, the auth and the claim in one platform. So the bold version is: **stop denials where the care happens, keep the payer rulebook current automatically, and learn the rules nobody wrote down from the whole network's denials.** An assistant checks claims. A platform makes the bad claim impossible to create.

## What the data actually contains (profile)

| File | Rows | What matters |
|---|---|---|
| `claims_history.csv` | 3,862 | 2,758 paid / 1,104 denied (28.6% by count, 30.3% by $). $381,140 billed, $265,668 paid. 12 agencies (AG001–AG012), 3 payers, 300 patients, DOS 2026-06-01 → 2026-10-20. All `frequency_code` = 1. |
| `claims_to_check.csv` | 546 | 532 new + 14 corrected (`frequency_code` 7 with `original_claim_id`). $54,065 billed. DOS 2026-08-06 → 2026-11-10. |
| `authorizations.csv` | 780 | 2–4 auths per patient; units 8–468 (median 128). PY01 288 / PY02 280 / PY03 212. |
| `evv_visits.csv` | 5,076 | 4,989 verified, 50 rejected, 37 manual_edit_pending. 140 caregivers. 191 visits cross midnight. Visits run 60–554 min. No patient has two visits for one service on one day. |
| `payers/` | 5 docs | Northwind (PY01) 8-minute rounding, 30-day filing → **bulletin 2026-07: 45 days for DOS ≥ 1 Aug**. Harbor (PY02) floor rounding, T1019 needs U2, 32 units/day cap, no filing limit → **notice 2026-08: weekend T1019 = U3 from 1 Sep**. Summit (PY03) floor rounding, 60-day filing, "§9.5 additional requirements may apply under your agency's contract" (no detail given). |

Denial mix (history): D09 240 · D03 218 · D01 182 · D06 79 · D07 75 · D99 73 · D08 70 · D02 67 · D04 37 · D10 36 · D05 27.

Messiness the base build has to absorb: 9 spellings of 3 payers (e.g. `NORTHWIND HP`, `Harbor Medicaid`, `SUMMIT CARE`); 457 DOS and 423 submitted dates in `MM/DD/YYYY`; modifiers like `' U1'`, `u2`; 176 service codes with stray whitespace.

---

## Idea 1: Clock-out Guardian ⭐ PICK

**Pitch:** The claim is decided when the caregiver taps "clock out". So check it there.

**Evidence:**
- Joining history to `evv_visits.csv` on patient + service + clock-in date explains **every** D01 and D09: 422 denials, $42,235, 36.6% of denied dollars. Rule-based, no AI needed.
  - D01 (182): 104 have no EVV record at all, 45 match a `rejected` visit, 33 match a `manual_edit_pending` one. Not one D01 claim had a verified visit.
  - D09 (240): billed units are over the payer-rounded verified minutes in all 240. Median overbill is **1 unit**, max 5. **128 of the 240 billed exactly ceil(minutes/15)**, so agencies round up when Northwind uses the 8-minute rule and Harbor and Summit round down.
  - Example: `C000022` (AG010, Summit, T1019) billed 15 units for 215 verified minutes. Summit floors that to 14, so D09.
- Same moment, other codes: Harbor's 32-unit daily cap (D06, 79 claims, $14,999, e.g. `C000244` billed 36 units of T1005) and Summit's hourly rule (Idea 3) can both be enforced when the visit is **scheduled**.

**Beyond the assistant:** The assistant tells a biller on day 15 that the claim will bounce. By then the visit is over and the fix is a write-down. The Guardian works at clock-out: "This is a Northwind visit. 2h07m = 8 billable units, not 9." At scheduling time: "This puts PT0211 at 36 Harbor units today, cap is 32." A coordinator gets "visit V000063 is `manual_edit_pending`. Don't bill until the aggregator accepts it." That's the three-sided value proposition (caregiver → agency → payer) used for revenue.

**Scores:** Impact 5 · Build **0.75 h** (on top of the base rules engine: a "simulate clock-out" panel that takes payer, service and minutes and returns billable units plus warnings, and a "hold until verified" list for pending visits) · Demo 5

**Risks:** We can't touch the real mobile app, so this is a simulated surface and we have to say so. Caregiver UX could backfire: telling an aide "you're 3 minutes short of a unit" invites padded clock-outs. The prompt must show the billable outcome, never a nudge to stay longer, and a payer program-integrity team would want that guardrail. The data has no multi-visit days, so the "payers add visits together" rule goes untested.

---

## Idea 2: Bulletin-to-Rule Compiler ⭐ PICK

**Pitch:** A payer publishes a bulletin and an approved, versioned rule goes live the same afternoon, already backtested.

**Evidence:**
- **Northwind 45-day bulletin:** for DOS ≥ 2026-08-01, **64 claims were submitted 31–45 days after DOS and all 64 were paid**. Before 1 Aug, 44 of the 50 claims in that same 31–45 window were D03. A checker built from the manual alone would raise 64 false denials. That's the trust-killer.
- **Harbor weekend U3 notice:** T1019 on a weekend with DOS ≥ 2026-09-01: **25 claims with U3 paid; all 3 with U2 got D04**. Before 1 Sep, weekend U3 claims got D04 (2 of 2) and weekend U2 paid. The rule flips on a date.
- Bulletins are short markdown (5–7 lines). Structured extraction with Haiku costs pennies.

**Beyond the assistant:** The assistant reads rules. This keeps the rulebook itself up to date. The LLM turns a bulletin into a structured diff (`payer, rule, field, old→new, effective_from`). A human approves it. The system immediately replays history and says "this change flips 64 predictions from deny to pay, and matches 64/64 actual outcomes." The AI drafts, deterministic code enforces, and a human signs off on anything that changes money. Scale it to 180+ payers and keeping rules current becomes a product of its own. Today every agency's billing team does this by hand.

**Scores:** Impact 4 · Build **1.0 h** (one LLM call per bulletin → JSON schema; approve/reject toggle; rerun backtest and show the delta) · Demo 5

**Risks:** LLM misreads an effective date, which is why there's human approval plus a backtest gate. Only 2 bulletins exist, so this demonstrates the capability rather than proving it works at scale. The rules engine must be data-driven (rules as effective-dated config, not if-statements), which constrains the base build. Flag that to the base planner.

---

## Idea 3: Hidden-Rule Detective ⭐ PICK (stretch; drop to a scripted reveal if time is short)

**Pitch:** There is a rule in this data that appears in no document. The network's denials reveal it.

**Evidence:**
- Summit's manual only says (§9.5) "additional billing requirements may apply under your agency's contract". No contract is in the pack.
- Remarks say: *"Contract amendment 3: services must be billed in whole hours"* / *"Units not billable per amendment 3 (hourly increments)"*. **48 claims** carry these remarks: 36 coded D10 **and 12 coded D99**, so the payer's own coding is inconsistent and the remark is the real signal.
- Pattern test: Summit claims with units not divisible by 4 → **June DOS: 106 claims, 0 amendment denials. DOS ≥ 2026-07-01: 53 claims, 48 amendment denials** (the other 5 got a different single code first, consistent with "payer reports one code only"). First hit 2026-07-01, last 2026-10-15.
- It hit **11 of 12 agencies** (all but AG008). Each one learned it the hard way, separately.
- In `claims_to_check.csv`, 18 Summit claims with DOS ≥ July have non-hourly units (rough screen).

**Beyond the assistant:** The assistant only knows the rules it was given. This learns new ones. Cluster denial remarks, have the LLM propose a rule hypothesis ("PY03, DOS ≥ 2026-07-01, units % 4 ≠ 0 → D10"), validate it statistically against history, then route it to a human as a *candidate* rule (it joins Idea 2's approval queue). This is the moat: **one agency's denial teaches all 32,000.** No single agency and no point-solution competitor sees enough denials to do this.

**Scores:** Impact 4 · Build **0.75 h** (group remarks by text, one LLM call to hypothesise, a pandas check for support/precision, push into the Idea 2 approval queue). Fallback: a 0.25 h scripted reveal of the query and result. · Demo 5

**Risks:** The synthetic data is planted, so it's clean. Real remarks are messier, and real "amendments" may be per agency (the manual says "your agency's contract") while here it hits nearly everyone. Must never auto-activate: a false learned rule blocks payable claims. Overfitting risk with small n per payer × agency.

---

## Idea 4: Authorization Runway

**Pitch:** "PT0079's Harbor attendant-care auth has 1 unit left and 12 units of claims waiting." Find out before the claim does.

**Evidence:**
- Paid units drawn down per `auth_id`, then pending `claims_to_check.csv` units on top: **18 auths where pending demand exceeds remaining balance, touching 32 claims.** E.g. `AUTH11022` (PT0079, PY02, S5125): 56 authorised, 55 paid, 12 pending. **56 auths would be ≥ 90% used** and 21 over 100%.
- Order matters (help article: drawdown happens "in the order claims are submitted"). `AUTH10512` (PT0042, Summit T1005, 68 units): the June 21 visit (`C003070`) wasn't submitted until 09/29, after later visits had used the balance, so D02. **Late billing of early visits loses the race.**
- D02 history: 67 claims, $7,046.

**Beyond the assistant:** Turns a denial into a care-coordination signal: ask the payer for an auth extension, or reschedule. That serves members (care doesn't stop) and payers (utilisation visibility), not just billers.

**Scores:** Impact 3 · Build 1.0 h · Demo 3

**Risks / data limits:** No future schedule in the pack, so a true *forecast* (burn rate × visits scheduled before `end_date`) can only be naive extrapolation. The honest version is "remaining vs pending". Real auth renewal workflows aren't in the data.

---

## Idea 5: Agency Denial Fingerprint

**Pitch:** Every agency gets a one-line diagnosis: "Your problem isn't payer rules, it's filing late."

**Evidence:**
- Denial rate spread: **AG008 23.5% → AG003 34.9%**, AG009 32.9% (highest volume, 443 claims).
- Different diseases: AG009 has **38 D03** (8.6% of its claims) and 38 D09. AG003 has 25 D03 out of 249. D09 rate runs from **AG005 3.5% to AG006 9.4%**.
- D09 is *not* a rogue-caregiver issue: 240 D09s are spread across 114 caregivers (max 5 each). It's a process (rounding) issue at the agency level, which tells you where to intervene.

**Beyond the assistant:** Agencies get coaching plus a clear outsourced-RCM upsell trigger. Payers get a network-management view ("which providers in my network leak money and why"). This is a feature both sides of the platform pay for.

**Scores:** Impact 3 · Build 0.5 h · Demo 3

**Risks:** 12 agencies and roughly 250–450 claims each means small cells (some codes have 0–3 per agency). Benchmarks need confidence intervals or they mislead. Naming agencies to payers is commercially sensitive.

---

## Idea 6: Certified Clean Claim (payer-side pre-adjudication)

**Pitch:** If payer and provider run the same versioned rulebook, a claim that passes is pre-adjudicated. Pay it fast.

**Evidence:** 94.7% of denied claims (1,043 of 1,104) have a cause our rule set explains (all codes except the 61 genuine D99 "contact payer / under review"). The payer adjudication in this pack is essentially deterministic. Northwind and Summit rules are published, and Harbor publishes its own.

**Beyond the assistant:** Exchange4Health already sells programme-integrity tools to payers. A shared, payer-approved rule pack makes the platform the **adjudication layer**, not just the pipe. It's the most ambitious idea and the strongest moat.

**Scores:** Impact 5 (long run) · Build 0 h (a narrative and "next steps" slide only) · Demo 2

**Risks / data limits:** **The synthetic data can't support this beyond the 94.7% figure.** There's nothing on payer appetite, payer adjudication cost, payment speed or contracts. It's purely a strategy hypothesis for the discussion, so don't build it.

---

## Score table

| # | Idea | Impact | Build (h) | Demo | Pick? |
|---|---|---|---|---|---|
| 1 | Clock-out Guardian | 5 | 0.75 | 5 | ✅ |
| 2 | Bulletin-to-Rule Compiler | 4 | 1.0 | 5 | ✅ |
| 3 | Hidden-Rule Detective | 4 | 0.75 (0.25 scripted fallback) | 5 | ✅ stretch |
| 4 | Authorization Runway | 3 | 1.0 | 3 | — |
| 5 | Agency Denial Fingerprint | 3 | 0.5 | 3 | — (cheap add if time remains) |
| 6 | Certified Clean Claim | 5 | 0 (narrative) | 2 | narrative only |

**Hours check:** picks = 0.75 + 1.0 + 0.75 = **2.5 h on top of the base rules engine** (normalise data, EVV join, effective-dated rules, backtest against history). That's tight in a 2–4 h total. The order: build #2's data-driven rule config *into* the base engine (no extra cost, just a design choice), then #1 (0.75 h), then #2's LLM extraction plus approval (1.0 h). Only build #3 if ≥ 45 min remain, otherwise use the 0.25 h scripted reveal. That gives a realistic floor of 2.0 h of picks with a 1.75–2 h base.

---

## The commercial story

**Who feels the pain (from the data):** denials cost agencies 30.3% of billed dollars in this pack ($115,472 of $381,140, about **$9,623 per agency** over the June–October dates of service). Not all of it is lost for good, but every denial means rework, delay, or a write-off:
- **Unrecoverable by design:** D03 late filing, 218 claims / $20,819. No corrected claim fixes a missed deadline.
- **Recoverable with a corrected claim (freq 7):** D04 + D07, 112 claims / $10,490, recovered late and with extra work.
- **Preventable before billing (point of care / schedule / auth):** 604 claims / $67,594 = **58.5% of denied $**. This is the Guardian's territory.

**Scale maths (assumptions labelled):**
- From the brief: $38B processed ÷ 32,000 providers ≈ **$1.19M per provider per year**. *ASSUMPTION: all processed payments are provider claim revenue, spread evenly. Real agencies vary massively.*
- *ASSUMPTION: real-world first-pass denial rate `d`.* The synthetic 30.3% is almost certainly inflated for the exercise, so don't use it. *ASSUMPTION: the synthetic denial mix carries over, so 58.5% of denied $ is preventable upstream.*

| Assumed denial rate `d` | Denied $ per provider/yr | Preventable upstream (×58.5%) | Network-wide preventable ($38B × d × 0.585) |
|---|---|---|---|
| 5% | $59,375 | ≈ $34,700 | ≈ $1.11B |
| 10% | $118,750 | ≈ $69,500 | ≈ $2.22B |

Read that as "dollars paid first time instead of after rework or never". It is **not** profit. Agency ROI = (write-offs avoided + rework hours avoided × *ASSUMED* cost per hour + days-to-cash gained) − price. Pricing isn't published (brief §4), so the pitch is a break-even line, not an invented price: *the product pays for itself if it costs less than the write-offs it prevents.*

**Who pays:**
- **Providers:** a billing module upgrade, plus a natural funnel into the existing *outsourced revenue cycle services* line (Idea 5 finds the agencies that need it).
- **Payers:** fewer bad claims to adjudicate and appeal, auth-utilisation visibility (Idea 4), network leakage dashboards (Idea 5), and long term the rule-pack partnership (Idea 6). This fits the existing payer BI and programme-integrity products.
- **Caregivers:** don't pay, but benefit. Clean claims mean the agency gets paid, and the caregiver logs hours correctly first time (their stated need in brief §2).

**Moat fit:** Ideas 1, 3 and 4 *need* EVV + schedule + auth + claim outcomes for the same visit, across many agencies and payers. A standalone claim-scrubber has the claim. Exchange4Health has the whole lifecycle for 485M visits/yr, dominant in 30+ states, plus denial feedback from 180+ payers. Every denial anywhere makes every agency's rulebook better (Idea 3). That's a data network effect competitors can't buy.

---

## The demo moment (10 minutes, make them remember one thing)

**Open with the stat, not the app (20 s):** "38% of the denials in this pack were decided the moment the caregiver clocked out. Leadership asked for a billing assistant. I think the bill is the wrong place to stand."

**Beat 1, the Clock-out Guardian (90 s):** simulate a Northwind visit, 127 minutes. The panel says **8 units, not 9**: the 7 leftover minutes are under the 8-minute threshold. Then a Summit visit, 110 minutes: **7 units, plus a warning that non-hourly units have been denied since July (amendment 3), so bill 4 or schedule 2h**. Then: "128 of the 240 overbilling denials in history are exactly this: rounding up."

**Beat 2, the live bulletin drop (2 min), the money shot:** run the backtest with the manual-only rulebook and show the 64 false Northwind D03 predictions in red. Paste the Northwind bulletin. The LLM produces the structured rule diff (`timely_filing: 30→45, effective DOS ≥ 2026-08-01`). Click **Approve**. Backtest reruns live: **64 false alarms go away, matched against 64/64 actual paid outcomes.** The audience sees the AI draft, the human decide, and the data prove it.

**Beat 3, the reveal (60 s):** "One more thing. There's a rule in this data that isn't in any document." Show the remark cluster, the LLM's hypothesis, and the 0/106 June vs 48/53 July+ split. "11 of 12 agencies learned this the hard way. On this platform, the first one teaches the rest."

**Close (20 s):** "That's why this belongs to Exchange4Health and not a bolt-on scrubber: it owns the visit, the schedule, the auth and the claim." Then the honest bit: what's simulated (caregiver app surface), what's untested (multi-visit days, real remark noise), and the 61 D99s we can't predict and route to a human.

**Guardrails to say out loud:** rules are deterministic and auditable; the LLM only drafts rules, hypotheses and explanations; nothing touches money or goes live without human approval and a backtest.

---

*Critique files: none found in `plan/` at time of writing.*
