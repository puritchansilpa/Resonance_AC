"""Numbers quoted in plan/ideas-v3.md. Run from repo root: python plan/scripts/ideas_v3_stats.py
Part A reads brief/data CSVs directly. Part B reads profiling/run_v1_1.pkl (to_check predictions from the
pre-build prototype engine, profiling/holdout.py) to size the coordinator queue."""
import pandas as pd, numpy as np
D='brief/data/'
h=pd.read_csv(D+'claims_history.csv',dtype=str).drop_duplicates().copy()
c=pd.read_csv(D+'claims_to_check.csv',dtype=str); e=pd.read_csv(D+'evv_visits.csv',dtype=str)
pm={'PY01':'PY01','NORTHWIND HP':'PY01','Northwind Health Plan':'PY01','PY02':'PY02','Harbor Medicaid':'PY02','Harbor Medicaid Plan':'PY02','PY03':'PY03','SUMMIT CARE':'PY03','Summit Care Partners':'PY03'}
def dt(s): return pd.to_datetime(s,format='%Y-%m-%d',errors='coerce').fillna(pd.to_datetime(s,format='%m/%d/%Y',errors='coerce'))
for d in (h,c):
    d['p']=d.payer.map(pm); d['dos']=dt(d.date_of_service); d['sub']=dt(d.submitted_date); d['u']=d.units.astype(int); d['b']=d.billed_amount.astype(float)
print('== A. Summit (PY03) non-hourly claims (units % 4 != 0), deduped history, by DOS window')
s=h[(h.p=='PY03')&(h.u%4!=0)].copy(); s['am']=s.remark.fillna('').str.contains('amendment 3')
for lo,hi,lab in [('2026-06-01','2026-07-01','Jun'),('2026-07-01','2026-09-01','Jul-Aug'),('2026-09-01','2026-11-01','Sep-Oct'),('2026-07-01','2026-11-01','Jul-Oct')]:
    x=s[(s.dos>=lo)&(s.dos<hi)]
    print(f'{lab}: n={len(x)} denied={x.status.eq("denied").sum()} paid={x.status.eq("paid").sum()} amend_remark={x.am.sum()} codes={x.denial_code.fillna("paid").value_counts().to_dict()} amend_by_code={x[x.am].denial_code.value_counts().to_dict()}')
am=h[h.remark.fillna('').str.contains('amendment 3')]
print('all amendment-3 remarks:',len(am),am.denial_code.value_counts().to_dict(),' DOS range',am.dos.min().date(),am.dos.max().date())
print('any amendment remark on an hourly (units%4==0) claim?',(am.u%4==0).sum())
a8=h[(h.agency_id=='AG008')&(h.p=='PY03')]; print('AG008 Summit: June non-hourly',((a8.dos<'2026-07-01')&(a8.u%4!=0)).sum(),'of',(a8.dos<'2026-07-01').sum(),'; Jul+ non-hourly',((a8.dos>='2026-07-01')&(a8.u%4!=0)).sum(),'of',(a8.dos>='2026-07-01').sum())
cs=c[(c.p=='PY03')&(c.dos>='2026-07-01')&(c.u%4!=0)]; print('to_check Summit non-hourly DOS>=Jul:',len(cs),' AG008 ones:',cs[cs.agency_id=='AG008'].claim_id.tolist())
print('== A2. Northwind bulletin window (PY01, DOS>=2026-08-01, lag 31-45)')
n=h[(h.p=='PY01')&(h.dos>='2026-08-01')]; lag=(n['sub']-n.dos).dt.days; w=n[(lag>30)&(lag<=45)]
print('history in window',len(w),w.denial_code.fillna('paid').value_counts().to_dict())
nc=c[(c.p=='PY01')&(c.dos>='2026-08-01')]; lc=(nc['sub']-nc.dos).dt.days; print('to_check in window',((lc>30)&(lc<=45)).sum())
print('== B. Coordinator queue sizing (prototype engine predictions for to_check)')
r=pd.read_pickle('profiling/run_v1_1.pkl'); T=r[r.src=='check'].copy(); T['b']=T.billed_amount.astype(float)
ev=e.copy(); ev['date']=pd.to_datetime(ev.clock_in).dt.normalize(); ev['sc']=ev.service_code.str.strip()
st=ev.groupby(['patient_id','sc','date']).verification_status.agg(lambda x:','.join(sorted(set(x)))).to_dict()
def action(row):
    p=row.pred
    if p=='': return 'SUBMIT'
    if p=='D01':
        s_=st.get((row.patient_id,row.svc,row.dos),'none')
        return 'HOLD_EVV_PENDING' if 'manual_edit_pending' in s_ else ('FIX_VISIT' if 'rejected' in s_ else 'NO_VISIT_RECORD')
    return {'D05':'DROP_DUPLICATE','D03':'WRITE_OFF_OR_SUBMIT_BY','D09':'FIX_AND_SUBMIT','D04':'FIX_AND_SUBMIT','D07':'FIX_AND_SUBMIT',
            'D10':'FIX_AND_SUBMIT (learned rule)','D02':'AUTH_SHORTFALL','D06':'DAILY_CAP','D08':'AUTH_WINDOW'}.get(p,'MANUAL_REVIEW')
T['action']=T.apply(action,axis=1)
F=T[T.pred!='']; print('flagged',len(F),'of',len(T),' $ at stake',round(F.b.sum(),2),'of',round(T.b.sum(),2))
print(F.groupby('action').b.agg(['count','sum']).sort_values('sum',ascending=False).round(2).to_string())
print('multi-flag flagged',(F.fl.str.len()>1).sum())
print('top 5 by $:'); print(F.sort_values('b',ascending=False)[['claim_id','payer_id','svc','units','b','pred','fl','action']].head(5).to_string())
print('pending-hold claims:',F[F.action=='HOLD_EVV_PENDING'].claim_id.tolist())
mf=F[F.fl.str.len()>1].sort_values('b',ascending=False); print('multi-flag examples:'); print(mf[['claim_id','payer_id','svc','units','b','pred','fl']].head(5).to_string())
