"""Re-derives the numbers quoted in plan/ideas-v2.md. Run from repo root: python plan/scripts/ideas_v2_stats.py"""
import pandas as pd, numpy as np
D='brief/data/'
h=pd.read_csv(D+'claims_history.csv',dtype=str); c=pd.read_csv(D+'claims_to_check.csv',dtype=str)
e=pd.read_csv(D+'evv_visits.csv',dtype=str); a=pd.read_csv(D+'authorizations.csv',dtype=str)
raw=len(h); h=h.drop_duplicates().copy(); print('history rows raw',raw,'deduped',len(h))
pm={'PY01':'PY01','NORTHWIND HP':'PY01','Northwind Health Plan':'PY01','PY02':'PY02','Harbor Medicaid':'PY02','Harbor Medicaid Plan':'PY02','PY03':'PY03','SUMMIT CARE':'PY03','Summit Care Partners':'PY03'}
def dt(s): return pd.to_datetime(s,format='%Y-%m-%d',errors='coerce').fillna(pd.to_datetime(s,format='%m/%d/%Y',errors='coerce'))
for d in (h,c):
    d['p']=d.payer.map(pm); d['sc']=d.service_code.str.strip(); d['dos']=dt(d.date_of_service); d['sub']=dt(d.submitted_date); d['u']=d.units.astype(int); d['b']=d.billed_amount.astype(float)
e['ci']=pd.to_datetime(e.clock_in); e['min']=(pd.to_datetime(e.clock_out)-e.ci).dt.total_seconds()/60; e['date']=e.ci.dt.normalize(); e['sc']=e.service_code.str.strip()
den=h[h.status=='denied']; N=len(den); B=den.b.sum()
print(f'denials {N}  denied$ {B:.2f}  billed$ {h.b.sum():.2f}')
def share(codes,label):
    x=den[den.denial_code.isin(codes)]; print(f'{label}: {len(x)}/{N} = {len(x)/N:.1%} by count; ${x.b.sum():.2f}/{B:.2f} = {x.b.sum()/B:.1%} by $')
share(['D01','D09'],'EVV-decided (D01+D09)')
share(['D01'],'D01 only')
share(['D09'],'D09 only')
share(['D01','D09','D06','D10','D02'],'upstream-caused v1 set')
# EVV join: verify every D01 has no verified visit, every D09 bills over payer-rounded verified minutes
v=e[e.verification_status=='verified'].groupby(['patient_id','sc','date'])['min'].sum().rename('vmin')
st=e.groupby(['patient_id','sc','date']).verification_status.agg(lambda s:','.join(sorted(set(s)))).rename('st')
m=h.join(v,on=['patient_id','sc','dos']).join(st,on=['patient_id','sc','dos'])
def units(r):
    if pd.isna(r.vmin): return 0
    f=int(r.vmin//15); return f+(1 if (r.p=='PY01' and r.vmin-15*f>=8) else 0)
m['evu']=m.apply(units,axis=1)
d1=m[m.denial_code=='D01']; print('D01 with verified visit:',d1.vmin.notna().sum(),' split:',d1.st.fillna('NO_EVV_ROW').value_counts().to_dict())
d9=m[m.denial_code=='D09']; print('D09 not over EVV units:',(d9.u<=d9.evu).sum(), ' billed==ceil(min/15):',(d9.u==np.ceil(d9.vmin/15)).sum(),'of',len(d9), ' overbill median',(d9.u-d9.evu).median())
flag01=m.vmin.isna(); flag09=m.vmin.notna()&(m.u>m.evu)
print('claims with EVV flag (either):',(flag01|flag09).sum(),' of which denied:',m[flag01|flag09].status.eq('denied').sum())
# Summit amendment 3: holdout - learn from DOS Jun-Aug, test Sep-Oct
s=h[(h.p=='PY03')&(h.u%4!=0)].copy(); s['am']=s.remark.fillna('').str.contains('amendment')
for lo,hi,lab in [('2026-06-01','2026-07-01','June'),('2026-07-01','2026-09-01','Jul-Aug (learn)'),('2026-09-01','2026-11-01','Sep-Oct (holdout)')]:
    x=s[(s.dos>=lo)&(s.dos<hi)]; print(f'PY03 non-hourly {lab}: {len(x)} claims, amendment remark {x.am.sum()}, other denial {(~x.am & x.status.eq("denied")).sum()}, paid {x.status.eq("paid").sum()}')
am=h[h.remark.fillna('').str.contains('amendment')]; print('amendment remarks',len(am),am.denial_code.value_counts().to_dict())
# drift monitor: when would amendment denials have surfaced, by submitted date
am=am.sort_values('sub'); print('first amendment denial submitted',am['sub'].iloc[0].date(),' 5th',am['sub'].iloc[4].date(),' 10th',am['sub'].iloc[9].date())
# down-billed Summit hourly claims after July: units%4==0 and units < evu, paid?
sm=m[(m.p=='PY03')&(m.dos>='2026-07-01')&(m.u%4==0)&(m.u<m.evu)]; print('Summit Jul+ whole-hour claims billed below verified units:',len(sm),sm.status.value_counts().to_dict())
# remark vocabulary size (does free text need an LLM?)
print('distinct remark strings',h.remark.dropna().nunique())
# D02 out-of-order: denied D02 claim whose DOS is earlier than DOS of a claim on same auth submitted before it and paid
pd_=h[h.status=='paid']; cnt=0
for _,r in h[h.denial_code=='D02'].iterrows():
    q=pd_[(pd_.auth_id==r.auth_id)&(pd_['sub']<r['sub'])&(pd_.dos>r.dos)]
    cnt+= len(q)>0
print('D02 claims beaten by a later-DOS claim submitted earlier:',cnt,'of',(h.denial_code=='D02').sum())
# pending vs rejected in to_check (hold vs deny)
mc=c.join(v,on=['patient_id','sc','dos']).join(st,on=['patient_id','sc','dos'])
print('to_check no verified visit:',mc.vmin.isna().sum(),mc[mc.vmin.isna()].st.fillna('NO_EVV_ROW').value_counts().to_dict())
# agencies hit by amendment
print('agencies with amendment denial',h[h.remark.fillna('').str.contains('amendment')].agency_id.nunique())
