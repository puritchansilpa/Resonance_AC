# Critique v1: plan-v1.md and ideas-v1.md

*Client Critic. I read this as the Resonance assessors, Exchange4Health leadership, an agency billing lead and a payer integrity team would. I re-ran the Architect's `profiling/sim2.py` and `flips.py` and wrote my own checks against `brief/data/`. Every number below comes from those runs.*

## What I verified (so nobody re-argues it)

| Claim | Verdict |
|---|---|
| 98.07% in-sample exact match (3,756/3,830), 98.38% status | **Reproduces.** Same confusion matrix: all 74 misses are 61 opaque D99s, 12 amendment D99s and 1 paid claim predicted D02. |
| Northwind bulletin flips 49 history and 17 to_check predictions | **Reproduces** (49 = 45 D03→paid, 3 D03→D05, 1 D02→paid; 17 = 10 D03→paid, 6 D03→D05, 1 paid→D02). One slip: plan §4 says history has "1 paid→D02". It is the other way round: D02 under the old rule, paid under the bulletin. |
| Harbor U3 notice flips 36 history / 14 to_check | Reproduces. |
| A time holdout | **Does not exist.** No script in `profiling/` does it, the plan reports no holdout number, and it sits at #6 on the cut list. |
| 210-minute build | It's an estimate, not a measurement. See M1. |
| Amendment 3 applies payer-wide | Supported. AG008 is the only agency never hit, but its Summit claims went from 6 of 13 non-hourly in June to 0 of 73 from July onwards. So it complied rather than being exempt. |
| Visionary: "64 Northwind claims, all paid" / "no patient has two visits a day" | Both wrong. The plan already refutes them. |

---

## Blockers

### B1. The "how I worked with AI" story is not yet owned by the candidate, and the plan scripts part of it in advance (plan §6 8:15–9:15, README §8)
- **Why it fails.** This is one of the four things the brief tells you to cover. "Building with AI" is graded on whether you *drive* the AI and *understand the code you ship*. Every hard finding in this plan was produced before the build by AI agents outside Claude Code: the cross-file drawdown interleave, the payer precedence tables, the D99/D10 label noise and the hidden rule. The build then becomes "make Claude Code reproduce numbers I was handed" (steps 3, 4 and 7 have literally pinned targets). The demo beat even suggests the Claude Code failure to talk about in advance ("for example dayfirst date parsing or drawdown order"). An assessor who asks "how did *you* find that 10 D02s need the to_check claims interleaved?" or "why is PY03's D10 above D09?" will find the gap in about 30 seconds.
- **What a fix must achieve.** The candidate can explain and defend every non-obvious design choice without notes, especially the interleave, precedence and amendment 3. The AI story comes from what actually happened in the session, and is told in the session history or CLAUDE.md. Use of other AI tools is disclosed, as the setup guide requires ("Tell us what you used and why").

---

## Major

### M1. The scope fills the time box with no contingency, and the time box leaves out work already done (plan §3, ideas "Hours check")
- 10 steps add up to exactly 210 min. Each "done when" needs an exact count on the first pass (D02 65/65, D06 79/79, misses 61+12+1). Step 9 is a 5-part Streamlit app (queue, detail, backtest, live rule toggles that re-run the backtest, units calculator) in 25 min. Step 8 is Haiku explainer, cache, dry-run and a 100-claim LLM baseline in 25 min. Neither is credible. Rehearsing a 10-minute demo, the design PNG and the README share 15 min.
- The guide's "2 to 4 hours" is judged on honesty as much as on the clock. The profiling that makes 210 min look possible isn't counted anywhere.
- **The fix must achieve** a build whose core (normaliser, engine, predictions.csv, backtest, README, sketch) is done and tested well inside 2.5 h, with the extras explicitly optional, and a truthful answer to "how long did this take?"

### M2. The AI contribution looks ornamental, and the reason given for keeping it small misreads the brief (plan §1 out-of-scope, §2.2, §8 Idea 2 row)
- The plan says "the brief allows Haiku per-claim calls only". It doesn't. The guide says Haiku is *cheaper if* you call once per claim. That misreading is why the plan rejects using the LLM to turn bulletins into rules, the one place where the AI does real work under human approval.
- What's left is Haiku writing explanations whose every `field/from/to` must match a rule-computed value, or a template is used instead. A sceptical assessor will ask what the LLM adds over the template. The plan has no measure of that. The LLM-only baseline only shows why the LLM shouldn't *predict*, which nobody was arguing.
- **The fix must achieve** a defensible, evidenced answer to "what does the AI do that rules can't, and how do you know it does it well?", or an honest statement that AI's role is small and why.

### M3. The evaluation would not convince a sceptic: in-sample, self-confirming, and silent on the 546 that get graded (plan §4, step 3–4 checks)
- **Fit to the answer key.** The precedence lists were picked after seeing all of history. The earlier precedence in `sim.py` scores 97.44%, and `sim2.py` scores 98.07%. The amendment rule's date was also read off history and is worth 0.9 pp. So about 1.5 pp of the headline is tuned to the data it's scored on. The holdout that would address this isn't built, and it's on the cut list.
- **Circular tests.** "Tests pinned to profiled counts" check that the code agrees with the earlier script, not that either one matches the manuals. If both share a bug, the tests pass.
- **to_check differs from history in ways the backtest can't see.**
  - 149 of 546 to_check claims (27%) have DOS after the last history DOS (20 Oct).
  - 14 corrected claims (frequency 7) exist, and history has **zero**, so how they're processed (duplicate exemption, filing clock) is untested and taken straight from `billing_basics.md`.
  - 29 to_check claims break 2 or more rules. In about 15 of them the reported code depends on a precedence pair seen 0 or 1 times in history: PY02 D05 vs D06 (6 claims), PY01 D03 vs D05 (3), PY03 D10 vs D03 (3), and singletons.
- **The fix must achieve** a reported number the assessors can believe for *unseen* claims, plus a stated confidence split: status (robust) versus code (fragile on the multi-rule claims). The 98% must be presented as "in-sample, with a ceiling", never as the expected score on `predictions.csv`.

### M4. "What good looks like" is a leaderboard metric, not a billing outcome (plan §1)
- Target 1 is "≥ 97% exact status+code". A billing lead doesn't care which of two codes the payer prints. They care about claims held that would have paid (cash delayed) and denials missed (rework, write-off). Precision and recall of "denied" sit in §4 as a secondary line.
- If the candidate leans transformation, the brief says assessors will probe "key next steps for implementing it in a business". The plan has no pilot, rollout, success KPI (first-pass rate, days to cash, hours of rework) or owner. §6's close is a list of product ideas, not an implementation path.
- **The fix must achieve** success criteria a billing manager would sign up to, and a credible "how this lands in an agency" answer.

### M5. Nobody owns the rule config, and a real billing team would refuse to own it (plan §2.1 item 2, §2.3 "Rule owner")
- Rules are hand-encoded YAML with precedence lists. §2.3 says a "rule owner" approves changes, but never says who that is: the agency, Exchange4Health, or the payer? Agency billers won't maintain YAML for every payer they bill. Exchange4Health has 180+ payers. The plan rejects automating bulletin intake (M2) and then leaves maintenance to an unnamed role.
- **The fix must achieve** a named owner and a believable process for keeping rules current, including how a payer's unannounced change (like amendment 3) gets caught in production rather than in a one-off script.

### M6. Ideas: the opening stat and Beat 1 overclaim and contradict the ideas' own guardrail (ideas thesis, "demo moment")
- "38% of the denials were decided the moment the caregiver clocked out" is (182 D01 + 240 D09)/1,104. But D09 is decided by **whoever enters the units**: ideas itself says 128 of the 240 are agencies rounding up. That's a billing error, fixed by a billing check. Only D01 is visit-side, and 78 of those are rejected or pending visits, which is a coordinator and aggregator problem. Opening on a stat an assessor can take apart in one question is fatal for credibility.
- Beat 1 tells the user to "bill 4 or schedule 2h" on a Summit visit. "Schedule 2h" to hit a billing threshold is exactly the padding nudge the ideas' Risks section says the product must never give. A payer integrity team would flag it on sight.
- Beat 2 still says "64/64". That's wrong (43 paid; 47/49 changed predictions match).
- **The fix must achieve** an opening claim that holds up to the obvious follow-up, and a demo with no line a payer would read as encouraging upcoding.

---

## Minor

- **m1. The D01 wording for pending visits** (plan §2.3, to_check). 4 to_check claims predicted D01 have `manual_edit_pending` visits and 5 have `rejected` ones. Telling a biller "will deny" when the right action is "hold until the aggregator accepts" is wrong advice for those 4. The output must tell a fixable hold apart from a real denial.
- **m2. Drawdown assumes the file's submitted_date is the real submission order** (plan §2.1 item 5). In production the biller controls the order. The plan's own example (AUTH10512: an early visit billed late loses to later visits) shows the order changes outcomes. The plan must say what the tool assumes and why, in one line the assessors can accept.
- **m3. Duplicates between two to_check claims** (6 of the 27 predicted D05s). The engine flags whichever one has the later submitted_date. The biller needs to be told which claim to drop and why, not just "D05".
- **m4. The demo has too many beats** (plan §6). That's 8 segments in 10 minutes, plus live toggles and a calculator. One stumble (Streamlit reload, network to Haiku) eats the "working with AI" slot, which is graded. Run the demo on cached output, and know what to drop on the day.
- **m5. Unseen precedence pairs are said to be "marked in config"**, but the report doesn't list which to_check predictions depend on them. See M3 for the count.
- **m6. Ideas: commercial maths** ($38B ÷ 32,000 → $1.1B–$2.2B preventable). It's labelled as an assumption, but the assessors will read it as inflated. Keep it out of the 10 minutes unless asked.
- **m7. Ideas: the hidden-rule "reveal" is framed as a surprise to the people who planted it.** The assessors know amendment 3 exists. What earns marks is how it's governed (D10 vs D99 label noise, human confirmation, payer-wide assumption), not that it was found.
- **m8. Cost.** Haiku spend is capped and trivial. Claude Code spend for 3.5 hours of agentic coding on the same $40 key isn't budgeted at all, and that's the more likely overrun.

---

## Verdict

**Would it pass today?** On engine accuracy, yes. The rules engine is real, reproduces exactly, and handles every data trap in the pack (dates, payer names, rounding, dated bulletins, cross-file drawdown, export duplicates vs D05, one code per denial). **On the rubric, it's borderline.** The plan is built to win a leaderboard, while the assessors grade judgement, the candidate's own command of AI, honest testing and an implementation story. Today it would score high on system thinking, middling on testing, and is at risk on building with AI and on judgement about scope.

**The 3 changes that matter most:**
1. **B1:** The candidate has to own every finding and tell a true story of working with AI, with the analysis done outside Claude Code disclosed.
2. **M3:** The evaluation has to give a believable estimate for unseen claims, separate robust status from fragile codes, and stop presenting 98% as the expected score.
3. **M1 + M2:** Cut scope to a core that's safely done in 2.5 h, and give the AI a role whose value is shown with evidence, or state plainly why that role is small.
