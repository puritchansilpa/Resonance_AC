# Critique v3 (final): plan-v3.md and ideas-v3.md

*Client Critic, round 3. I checked the budget arithmetic myself, and checked C019757, the D07/D08 auth claim and the brief text against the data.*

## 1. What I verified

| Claim | Verdict |
|---|---|
| 165 core + 30 stretch + 45 contingency = 240 | **The arithmetic is right.** Phase 1 is 10+15+10+15+30+10+15+10 = 115. Phase 2 is 30 and Phase 3 is 20. The clock plan (115 + 5 slack + 30 + 20 + 10 slack + 30 stretch + 30 reserve) adds up to 240. Whether it's realistic: see M2. |
| C019757: 34 units, 483 verified min, D09 + D10, fixed at 32 | **Reproduces.** One verified visit, 07:45–15:48 on 2026-09-03, is 483 min. Floor rounding gives 32 units, which is whole hours, so the fix clears both D09 and D10. |
| All 93 D07 + 85 D08 claims have a valid auth on file | **Reproduces.** 178 claims across both files have an invalid auth_id, and every one has another auth covering the same patient, service and DOS. Remaining balance on that auth isn't checked (m3). |
| Summit table (Jul–Aug 21 D10 / 9 D99 / 1 D01 / 1 D07; Sep–Oct 14 / 3 / 2 / 1) | **Consistent** with the 35 D10 + 12 D99 amendment total and with my round-2 run |
| Holdout 97.97% vs 98.27% (23 D99 of 1,331) | Reproduced in round 2. I re-checked the 1,331 and the 23 this round |
| 2h checkpoint demoable on its own | **Partly.** The code is demoable. The presentation isn't: see m1. |
| 3h checkpoint demoable on its own | **Yes.** All 7 beats rest on core items C0–C9 plus Phase 3. Two on-screen numbers have no step that produces them: see m2. |
| Single 7-beat demo | **True within plan-v3.** ideas-v3 §2 still carries a different, 5-beat script (m4). |
| Honest wording | **Mostly fixed.** One false statement about the brief remains (M1). |

## 2. Were the v2 points fixed?

| v2 | Status |
|---|---|
| M1 "found it himself" | **Fixed.** §0's standard wording, README §8 and demo beat 6 all say "flagged before, reproduced in the build". Discovery credit is limited to things that come out of the build. Good. |
| M2 C4 underestimated | **Fixed for C4. The squeeze moved to C6** (see M2 below) |
| M3 AI relabelled | **Fixed under the second option I allowed.** The plan now says plainly that Haiku's value is wording, measures faithfulness and cost in the core, and has a fallback rule. The defence rests on a misstatement of the brief, though (M1 below). |
| M4 two demos | **Fixed in the plan.** ideas-v3 still contradicts it (m4) |
| M5 nothing for a coordinator | **Fixed.** `queue.html` with cards is in core C7 and is beat 4 |
| m1–m7 | **All fixed.** Action-class accuracy dropped, risk report in core, Summit status and code separate, date learned in `learn.py`, C020368 tagged, 61 corrected, "advises" wording |

---

## Blockers

None.

## Major

### M1. The defence of the AI's role misstates the brief (plan §10 row 4, §2.3, §1.3)
- **The misstatement.** Plan §10 says the Haiku note stays in core because "it is the per-claim AI the brief asks to show". The brief asks for no such thing. Its own idea (§6) is an assistant that will "**read each payer's rules**, check a claim against them before submission, predict which claims will be denied, and suggest the fix."
- **Where the AI actually sits.** In plan-v3 a human reads the rules (C3), rules do the checking, predicting and fixing, and the AI only writes the wording (C8). The one AI job that matches the brief's idea, drafting rules from payer prose, is stretch S2. With realistic time (M2) it won't be built.
- **The eval can't show Haiku is better.** The template baseline is generated from the same engine facts the grading sheet checks, so it scores perfectly by construction. The eval can show that Haiku is *safe*, never that it's *better*, and the plan admits readability is untested.
- **What happens in Q&A.** An assessor will ask why the AI in an "AI assistant" only paraphrases. "The brief asked for it" is false and will be caught.
- **A fix must achieve** a framing decision in §1, stated up front: hand-encoding payer rules is a deliberate scope choice made against the brief's "reads each payer's rules", with the reason given. The false "brief asks for per-claim AI" line must go. And the candidate must have a ready, honest answer for what Haiku adds over the template, given that the eval can't show it.

### M2. Per-step times were cut to hit 165, so the 2h checkpoint and the stretch window are fiction (plan §3.1, §3.2)
- **Cuts without scope cuts.** From v2 to v3, C1, C2 and C3 each lost 5 min with no reduction in scope. C3 still encodes 7 checks from 5 documents and hand spot-checks 14 claims in 15 min.
- **C6 got worse.** The v2 backtest step (25 min) and the risk report (10 min) are merged into C6 at **15 min**. That one prompt asks for:
  - 4 configs × 2 periods;
  - 6 metrics plus slices, ablations and a confusion matrix;
  - 5 risk analyses, two of which need extra engine runs (reversed tie order and simulated history state);
  - `predict.py`.
- **That's where the overrun lands.** The squeeze I flagged in C4 has moved to C6, and C6 is "never cut".
- **The cut rules absorb it, which is why this isn't a blocker.** The 30 min of stretch plus 45 of contingency gives about 75 min of real buffer. But App v1 will land nearer 2:20–2:30 than 2:00, and the stretch window will be spent on overrun. Stretch S1 (`recheck`) and S2 (the compiler) should be expected *not* to exist.
- **A fix must achieve** per-step times the candidate can defend from scope, not from subtraction. The demo and README must not depend on, or hint at, S1/S2 work the timeline won't deliver.

## Minor

- **m1. The "stopped at 2:00" demo has no slides.** Beat 2 shows `docs/design.png` and the README, which are only made in Phase 3. App v1 is demoable as software, not as a presentation. Either the design artifact moves earlier, or the fallback beat says what's shown instead.
- **m2. Two demo numbers have no step that produces them.**
  - Beat 1's "share of denials the documented rules explain" isn't in the C6 prompt. C3 prints flagged→denied per check, which isn't the same number.
  - Beat 3's "Sep–Oct N/N non-hourly Summit denied, M coded D10" isn't in the C6 prompt either. §4.2 only slices PY03 "June vs July+".
  - If the prompt doesn't ask for them, they won't be on screen.
- **m3. The D07/D08 fix is "a lookup", but the balance isn't checked.** Every flagged claim does have a covering auth (verified), but moving the claim onto that auth draws it down. The suggested fix can turn a D07 into a D02 or push a later claim into D02. Only `recheck` (stretch S1) would catch that. The card should either check balance or say it wasn't checked.
- **m4. ideas-v3 §2 is a second demo script.** It has 5 beats, the compiler and `recheck` in core, and Haiku in stretch, all of which plan §10 rejected. Poom reads both files. Mark ideas-v3 §2–§6 as superseded by plan-v3 §6 so he can't rehearse the wrong one.
- **m5. Ten minutes with zero slack.** The 7 beats fill exactly 10:00 with live commands and a browser. The drop list exists. Rehearse to 9:00.

---

## Final verdict

**PASS.** The plan would clear the assessment today, and comfortably on testing and system thinking:
- a time holdout with a stated ceiling that reproduces;
- status separated from codes;
- tests that don't grade themselves;
- a to_check risk register in core;
- honest provenance wording;
- named rule owners;
- a pilot plan;
- a screen a billing coordinator can follow.

Its weakest dimension is the AI, which is safe and measured but only paraphrases. That's a defensible engineering choice, but it isn't defended accurately yet.

**Last must-fix items, before the build starts:**
1. **M1:** Delete "the per-claim AI the brief asks to show". State the hand-encoded-rules scope choice against the brief's "reads each payer's rules" in §1, and prepare the honest answer to "what does Haiku add over the template?"
2. **M2:** Set per-step times from scope, especially C6. Treat stretch as not happening, and keep it out of the demo and README.
3. **m2 + m4:** Make sure every number shown in the demo is produced by a named core step, and mark ideas-v3's demo superseded.
