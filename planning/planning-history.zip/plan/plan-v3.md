# Plan v3 (final): Resonance take-home, Exchange4Health claims pre-check

This is the complete plan. v1 and v2 are left untouched and superseded.

Poom builds it himself in Claude Code on his own PC. The pre-build analysis behind this plan was done by AI agents, and the README discloses it. The build **reproduces and verifies** that analysis with Poom's own scripts. It does not claim to have discovered it.

Reference values from the pre-build analysis are in Appendix A. They are for checking Poom's output after his own run. They never go into prompts as targets.

Sources for every number:
- `profiling/holdout.py`, `flagsim.py`, `tocheck_risk.py`;
- `plan/scripts/ideas_v2_stats.py`, `ideas_v3_stats.py`;
- a recheck run this round (Appendix A).

---

## 0. Provenance and how Poom uses this plan

**What happened before the build.** AI agents (planner, visionary, critic) read the brief and profiled the data with pandas. They wrote plan-v1–v3, ideas-v1–v3 and critique-v1–v2. Poom has read them. So the main findings are **known going in**:
- date formats;
- payer rounding;
- dated bulletins;
- cross-file drawdown;
- payer-specific code priority;
- the Summit hourly rule.

**What the build does with them.** Each finding is reproduced and checked in Poom's repo, by a script he asks Claude Code for, runs and reads. Where his number differs from Appendix A, he investigates and logs why.

**Discovery credit** is claimed only for things that genuinely come out of the build:
- bugs Claude Code introduced and how he caught them;
- the Haiku eval result;
- the compiler gold check, if built;
- any mismatch with Appendix A.

**Per step (§3):**
1. Run the prompt given.
2. Read the code.
3. Run it.
4. Check the "Verify" items on actual rows.
5. Add one line to `docs/ai_log.md`: what Claude did, what Poom changed, what went wrong.

`docs/ai_log.md`, `CLAUDE.md` and the exported session history are the "how I worked with AI" evidence.

**Standard wording** (README, demo, Q&A): "The pre-build analysis, done with AI agents and disclosed in the README, flagged X. I reproduced and checked it in my own run; my number was Y (ai_log entry N)."

**Defend without notes:**
1. Why drawdown runs over both files in submitted-date order.
2. How code priority is learned from fit months, and which pairs are thin.
3. How the Summit rule is learned from fit months, and how it does out of time.
4. Why D99 is never predicted.
5. What Haiku does per claim, what it can't do, and the eval result.

---

## 1. Problem framing and scope

### 1.1 User and job
- **User:** an agency billing coordinator, the day before claims go out.
- **Question:** "Which of these claims will bounce, and what do I do about each one?"
- **Per claim, the tool gives:**
  - the verdict (pay or deny);
  - the one code the payer will print;
  - every rule the claim breaks;
  - the computed fix;
  - an action: submit, fix and submit, hold, drop duplicate, write off, or review.

### 1.2 In scope
- **Rules** from the three payers' manuals and bulletins, effective-dated by date of service (DOS).
- **One chronological engine** over history plus to_check: duplicates, auth drawdown, Harbor daily cap.
- **Learned from fit months, approved by a human:** code priority per payer, and the Summit hourly rule.
- **Backtest with a time holdout**, billing KPIs and a to_check risk report.
- **`predictions.csv`.**
- **`out/queue.html`:** a static work queue with one card per claim, for the coordinator.
- **A Haiku note per flagged claim**, with a measured eval (§4.4).

### 1.3 Out of scope, and why
- **Predicting the opaque D99s.** No feature explains them.
- **Auto-submitting or auto-correcting claims.** Money moves, so a human signs off.
- **EVV app or scheduling integration.** Not in the pack.
- **Payment amounts.** Paid history claims are paid in full.
- **A server-based UI.** It is a stretch item, a reskin of `queue.html`.

### 1.4 What good looks like (billing outcomes first)

| Outcome | Metric (all on the later-months holdout) |
|---|---|
| Don't hold claims that would pay | False holds: count and $ |
| Catch denials first | Denial recall and precision |
| Aim the fix | Status accuracy; exact status+code; code accuracy on multi-flag claims |
| Honest ceiling | D99 share printed next to every accuracy number |

Action classes are a deterministic mapping from code, EVV status and flags. They are **unit-tested, not scored**: history has codes, not actions.

**Pilot KPIs** (not measurable in the pack; see §8):
- first-pass paid rate;
- days to cash;
- rework hours per 100 claims;
- false-hold rate on live outcomes.

---

## 2. System design

### 2.1 Components
1. **`load.py` — normaliser.**
   - Explicit date formats only (`%Y-%m-%d`, `%m/%d/%Y`); fails on anything unparsed.
   - Maps payer spellings to PY01–PY03.
   - Strips and upper-cases service codes and modifiers.
   - Drops exact-duplicate export rows. These are not D05 duplicates.
2. **`rules/payers.yaml` — dated rules per payer.**
   - Covers rounding, filing limits, modifiers, daily cap, contract rules and code priority.
   - Each entry has `source`, `effective_from`/`to`, `date_basis: DOS`, and `status` (`documented` | `learned_confirmed` | `assumption`).
3. **`evv.py` — EVV matcher.**
   - Verified visits only, keyed by patient + service + clock-in date. Overnight visits count on the clock-in day.
   - Sums minutes, then converts them to units with the payer's rounding.
4. **`rules.py` — static checks:** D01, D03, D04, D07, D08, D09, D10.
   - Each returns its **evidence**: minutes, allowed units, lag vs limit, deadline date, auth window.
   - Each also returns a **computed fix**:
     - D09: units → allowed units.
     - D04: the required modifier.
     - D07/D08: the auth on file that covers the patient, service and DOS.
     - D10: the largest whole-hour count at or below allowed units, labelled "untested: 0 such claims in history".
     - D03: the deadline date.
5. **`engine.py` — one pass over history ∪ to_check**, sorted by (submitted_date, claim_id).
   - State: duplicate keys (D05; frequency-7 claims are exempt), auth balances (paid claims only), Harbor paid units per member per day (D06).
   - History rows update state with their actual outcome; to_check rows use their predicted outcome.
   - Records all flags, then picks the printed code with the payer's priority list.
6. **`learn.py` — learns from history up to a DOS cutoff** and writes to `proposed/`:
   - (a) **Code priority:** pairwise "reported over" counts among denied multi-flag claims, per payer, with counts kept so thin pairs are visible.
   - (b) **Summit rule date:** the first DOS month where non-hourly PY03 claims carry the amendment remark and none are paid. It is learned, not hard-coded.
7. **`backtest.py`** — holdout, metrics, slices, ablations and the to_check risk report.
8. **`predict.py`** — writes `out/predictions.csv` and `out/queue.html`.
9. **`explain.py`** — one Haiku call per flagged claim (§2.3), plus `note_eval.py`.

**Action classes** (rules, unit-tested):

| Class | When |
|---|---|
| `SUBMIT` | No flags |
| `FIX_AND_SUBMIT` | Fixable flags: D04, D07, D08, D09, D10 |
| `HOLD_EVV_PENDING` | D01 where the visit is `manual_edit_pending`. Wait; do not rework. |
| `FIX_VISIT` | D01 where the visit is `rejected` |
| `NO_VISIT_RECORD` | D01 where there is no EVV row |
| `DROP_DUPLICATE` | D05, naming the earlier claim_id and which file it is in |
| `WRITE_OFF_OR_SUBMIT_BY` | D03, with the deadline |
| `AUTH_SHORTFALL` | D02 |
| `DAILY_CAP` | D06 |
| `MANUAL_REVIEW` | Overrides the class (status is still predicted) when the printed code rests on a thin code-priority pair (seen 0–1 times) or on an `assumption` rule |

### 2.2 Rules vs AI

| Concern | Owner | Why |
|---|---|---|
| Dates, rounding, EVV match, auth window, drawdown, daily cap, duplicates, deadlines | Rules | Exact, stateful arithmetic |
| Computed fixes, including the replacement auth | Rules | Every D07/D08 claim in the pack has a valid auth on file (Appendix A), so the fix is a lookup |
| Printed code | Rules (learned priority, human-approved) | Auditable; tested out of time |
| `status`, `denial_code` | **Rules only** | The model never changes a prediction |
| Plain-language note per flagged claim | **Haiku** | §2.3 |
| Drafting a rule from a bulletin's prose | Model + human approval (stretch S2) | Placed by time value (§3.3) |

### 2.3 What Haiku does per claim, and what it doesn't

**Model choice.** The setup guide advises Haiku for any per-claim model calls. It doesn't limit the build to per-claim calls. So per-document calls (bulletin drafting) are allowed too. They are placed by time value.

**Input** (one flagged claim):
- the normalised claim;
- every flag with its evidence;
- the printed code;
- the action class;
- the rule-computed fixes;
- the verbatim rule text from the manual or bulletin.

**Output** (JSON):

```json
{"summary": "...", "why_each_rule": [{"code": "D09", "plain": "..."}],
 "what_to_do": ["..."], "watch_out": "..."}
```

**What it adds.** It turns several flags and numbers into one short instruction a biller can act on without the manual. That matters most on multi-flag claims.
- The payer prints one code. A biller who fixes only that one gets denied again on the next rule.
- Example: C019757. The payer will print D10, but the claim also breaks D09. Fixing to 32 units clears both.

**What it doesn't do.** It doesn't decide, compute or order fixes. Rules do all of that. Its value is wording, and the eval (§4.4) measures:
- **faithfulness**, automatically, on every note;
- **completeness and correctness** against engine facts, on a graded sample;
- **cost and latency** per claim.

If the notes don't meet the bar, the queue shows the template note and the README says why.

The AI job that does real work rules can't is reading payer prose into rules. That is stretch S2, with a gold check.

**Guardrails:**
- temperature 0; JSON schema; responses cached by input hash; `--limit` cap; `--dry-run` uses the template;
- model id from env `CLAUDE_MODEL`;
- banned advice (longer visits, rescheduling, billing more) is code-checked.

### 2.4 Human in the loop
- **Biller:** works `queue.html` top-down and decides. The tool never submits.
- **Payer-content analyst:** approves anything in `proposed/` (code priority, the learned Summit rule, model-drafted bulletin rules) after seeing the backtest delta.
- **D99 and thin-evidence claims:** manual review.

### 2.5 Rule ownership
- The **Exchange4Health payer-content team** owns one rule pack per payer, centrally. Agencies never edit YAML.
- Changes go `proposed/` → backtest delta → analyst approval → versioned release.
- Agency billing leads own the queue.

### 2.6 Unannounced payer changes
- **Production:** a drift monitor watches incoming denials. When a new remark × payer pattern reaches N denials (N = 5 is an ASSUMPTION), it proposes a candidate rule with support and precision.
- **This build:** `learn.py` does the same on fit months.
- **Governance facts to state:**
  - The payer codes the same Summit remark as D10 and as D99.
  - Payer-wide scope is an ASSUMPTION. It is consistent with AG008's billing pattern but not proven by it.
  - C020368 (AG008, to_check) rests on that assumption and is tagged `MANUAL_REVIEW`.

### 2.7 Design sketch

```mermaid
flowchart LR
  subgraph Inputs
    CH[claims_history] & CC[claims_to_check] & AU[authorizations] & EV[evv_visits]
    DOC[manuals + bulletins + denial_codes]
  end
  CH & CC & AU & EV --> N[load.py<br/>dates · names · codes · dedupe]
  DOC -->|hand-encoded, cited| CFG[(rules/payers.yaml<br/>dated, per payer)]
  DOC -.->|stretch S2: model drafts rule| P
  CH --> L[learn.py<br/>code priority + Summit date<br/>DOS cutoff]
  L --> P[/proposed/]
  P --> A{{Payer-content analyst<br/>approves after backtest delta}}
  A --> CFG
  N --> E[evv.py<br/>verified min → units]
  E --> R[rules.py<br/>flags + evidence + computed fix]
  CFG --> R
  R --> S[engine.py<br/>history ∪ to_check by submitted_date<br/>D05 · D02 · D06 · printed code]
  CFG --> S
  S --> PR[predictions.csv]
  S --> BT[backtest.py<br/>holdout · KPIs · risk report]
  S --> Q[queue.html<br/>action · reason · fix · deadline · $]
  S -->|flags, evidence, fixes, rule text| H[Haiku per flagged claim<br/>note · auto-checked]
  H --> Q
  Q --> B{{Biller decides,<br/>submits outside tool}}
```

Deliverable: `docs/design.md` (this mermaid) and `docs/design.png` (export from mermaid.live), linked from the README.

---

## 3. Build plan

### 3.1 Budget

| Block | Minutes |
|---|---|
| Phase 1, App v1 (end-to-end, demoable) | 115 |
| Phase 2, Haiku note + measured eval | 30 |
| Phase 3, README, design PNG, demo dry run | 20 |
| **Core total** | **165** |
| Stretch window (3:00–3:30) | 30 |
| **Contingency** (5 before the 2h checkpoint + 10 before the 3h checkpoint + 30 reserved at 3:30–4:00) | **45** |
| **Total** | **240** |

**Clock plan:**

| Clock | Activity |
|---|---|
| 0:00–1:55 | Phase 1 |
| **2:00** | **Checkpoint: App v1** |
| 2:00–2:30 | Phase 2 |
| 2:30–2:50 | Phase 3 |
| **3:00** | **Checkpoint: App v2** |
| 3:00–3:30 | Stretch, one item at a time. Unfinished work at 3:30 is stashed, not shipped. |
| 3:30–4:00 | Reserved contingency, then the final dry run |

**Tracking:** `docs/timelog.md` records start and stop per step. Claude Code spend:
- Sonnet by default; Opus at most once, for design.
- Run `/cost` after each step and log it.
- If spend passes $20 of the $40 before App v2, stop using Opus and shorten prompts.

### 3.2 Core steps

**Phase 1: App v1 (115 min)**

**C0. Repo and guardrails (10 min)**
- *Prompt:* "Set up a Python repo here: venv, requirements.txt (pandas, pyyaml, anthropic, python-dotenv, pytest), .gitignore with .env, .venv/, out/cache/. Add .env.example with empty ANTHROPIC_API_KEY and CLAUDE_MODEL. Write CLAUDE.md: never read or print the key; rules compute predictions, the model never does; explicit date formats; every rule cites its source file."
- *Verify:* `.env` is not in `git status`; `git grep -i "sk-ant"` is empty.
- *Done:* first commit.

**C1. Load and profile (15 min)**
- *Prompt:* "Write claimcheck/load.py. First print a profile: date patterns per column, payer name variants, service-code and modifier variants, exact duplicate rows. Then normalise with explicit formats and fail on anything unparsed. Save the profile to out/profile.txt."
- *Verify:* is any slash date's first field > 12? Payer variant count; duplicate row count. Compare 3 rows raw vs normalised. Check against Appendix A and log differences.
- *Tests:* both formats parse to the same day; payer variants → 3 ids; dedupe removes only identical rows.

**C2. EVV units (10 min)**
- *Prompt:* "Write evv.py: verified visits only, key patient+service+clock-in date, summed minutes, units by each payer's rounding rule from the manuals."
- *Verify:* write the tests by hand from the manual text: 127 min → 8 units for every payer; 128 → 9 for Northwind, 8 for Harbor and Summit; an overnight visit counts on its clock-in day.

**C3. Documented rules with evidence and computed fixes (15 min)**
- *Prompt:* "Write rules/payers.yaml and rules.py from the manuals and bulletins only, dated by DOS. Each check returns evidence and a computed fix. Print, per check, history claims flagged and how many were denied."
- *Verify:* any check below ~100% flagged→denied is wrong; find out why. Spot-check 2 claims per check. Commit `payers.yaml` now: it is the gold for stretch S2.

**C4. Chronological engine (30 min)**
- *Prompt:* "Write engine.py: one pass over history and to_check sorted by submitted_date then claim_id. Track duplicates (frequency 1 only), auth balances (paid only), Harbor member-day paid units. History uses actual outcomes for state, to_check uses predicted. Record all flags per claim. Add a switch to replay history alone."
- *Verify:*
  - Run D02 with history alone, then interleaved. Compare how many history D02s each explains.
  - Trace one auth claim by claim. The pre-build analysis says interleaving is needed; confirm or refute it on your own output and log the result.
- *Tests:* hand-made claims for duplicate, frequency-7 exemption, drawdown order and the daily cap.

**C5. Learn from fit months (10 min)**
- *Prompt:* "Write learn.py --cutoff DATE: per payer, count which code was reported over which other flag among denied multi-flag claims; output the order and every pair count. Also find the first DOS month where non-hourly PY03 claims carry the amendment remark and none are paid. Write both to proposed/."
- *Verify:* read the pair table. Which pairs have ≥3 observations and which have 0–1? Does the learned Summit date come from data, not code? Approve into `payers.yaml` yourself, recording who approved and when.

**C6. Backtest, holdout, risk report, predictions (15 min)**
- *Prompt:* "Write backtest.py: fit on DOS ≤ 2026-08-31 via learn.py, score DOS ≥ 2026-09-01; report fit and score periods for 4 configs (naive code order without Summit rule; + learned Summit rule; + learned priority; priority refit on all history). Metrics: false holds (n, $), denial recall/precision, status, exact, multi-flag accuracy, D99 ceiling, per payer, bulletin slices. Risk report for to_check: thin-pair claims, D02 that depend on earlier predicted-paid to_check claims, reversed tie order changes, simulated-history-state changes, D05 sources. Then predict.py → out/predictions.csv."
- *Verify:* holdout vs in-sample gap; misses by code; `predictions.csv` has 546 rows, `paid`/`denied` only, code blank iff paid, no D99.

**C7. Minimal review view (10 min)**
- *Prompt:* "In predict.py also write out/queue.html, one static file, no server. A summary line: flagged/total and $ at stake. Rows sorted by action group (fix now → hold → deadline missed → submit), then deadline, then $. Each row expands to a card: every flag with evidence, printed code, computed fix, source quote, template note, tags (learned rule, assumption, thin priority)."
- *Verify:* open it in a browser. Find C019757, a `HOLD_EVV_PENDING` claim and C020368, and check each card against the engine output.

**Checkpoint 2:00, App v1, demoable as is:**
- loader, dated rules, engine;
- learned priority and Summit date (fit months);
- `backtest_report.md` (holdout, KPIs, risk report);
- `predictions.csv`;
- `queue.html` with template notes.

If Phase 1 runs late: keep going on Phase 1, spend contingency, start no stretch. Phase 2 starts only once App v1 works.

**Phase 2: Haiku note + measured eval (30 min)**

**C8. explain.py (15 min)**
- *Prompt:* "Write explain.py: for each flagged to_check claim, send claim, flags, evidence, computed fixes, action class and quoted rule text to the model in env CLAUDE_MODEL. JSON schema from the plan. Cache by input hash, --limit, --dry-run template. Log input/output tokens and latency per call. Write notes into queue.html cards, template as fallback."
- *Verify:* read 5 notes next to their evidence, including C019757 and one hold.

**C9. note_eval.py (15 min)**
- *Prompt:* "Write note_eval.py: automatic checks on every note: schema valid; every number in the note text appears in the claim's evidence or fixes; every flag code mentioned; action matches the class; no banned advice. Pick a stratified sample of 20 (10 multi-flag, 5 hold/visit, 5 single-flag) into a grading sheet with the engine facts beside each note. Summarise tokens, latency (median, p95) and calls."
- *Verify:*
  - Grade the 20 yourself against the facts sheet. Four yes/no items: printed code right; every rule named; fix matches the engine's; action right.
  - Paste the result into `out/note_eval.md`.
  - Apply the decision rule (§4.4).

**Phase 3: README, design PNG, dry run (20 min)**
- README per §5, with the result tables pasted from `out/`.
- Export `docs/design.png`.
- One timed run through the demo script (§6).

**Checkpoint 3:00, App v2:** App v1 + Haiku notes in the queue cards + `out/note_eval.md` + README + design PNG.

### 3.3 Stretch (only from 3:00, in this order, stop at 3:30)

| # | Item | Min | Value per minute |
|---|---|---|---|
| S1 | `recheck <claim_id> --set field=value`: rerun the engine on an edited claim and print old vs new verdict | 10 | Highest. Makes the queue live and shows fix interactions computed by rules. |
| S2 | Slim bulletin-to-rule drafting. The model reads the Northwind bulletin and Summit §9.5. JSON rule + verbatim quote check, then a field-by-field diff against the C3 gold rule (committed before this runs). §9.5 must return `no_actionable_rule`. Output goes to `proposed/`; approval reruns the ablation. | 30 | The one AI job that reads prose rules. Best result is parity with the hand rule plus a correct refusal. |
| S3 | Harbor notice as a third compiler input | 5 | Small |
| S4 | Drift view: learned-rule evidence by DOS month + "alert at N denials" date | 15 | Governance talking point |
| S5 | Streamlit reskin of `queue.html` | 25 | Cosmetic |

With 30 minutes, the realistic stretch is S1 + part of S2, or S2 alone. Recommendation: S1 first (10), then S2 only if it can finish by 3:30. Otherwise stash it.

### 3.4 Cut order if behind
- **At 2:00, App v1 not working:** continue Phase 1 into contingency. Cut C7 to an HTML table without expanding cards if needed. Never cut C6.
- **At 2:30, App v1 still not working:** finish it, then do C8 with `--limit 30` and C9 with a 10-note sample, then Phase 3. No stretch.
- **At 3:00, App v2 not done:** finish Phase 2 and 3. No stretch.
- **At 3:30:** stop all building. Use the remaining time for recovery and a final dry run.
- **Never cut:** C0–C6, the README, the design sketch, key hygiene.

### 3.5 Repo layout (`C:\Users\Poom Chansilpa\Desktop\Coding\Resonance_AC\Resonance_AC`)

```
Resonance_AC/
  README.md  CLAUDE.md  requirements.txt  .gitignore  .env.example
  data/                     # synthetic pack, unchanged
  rules/payers.yaml
  proposed/
  claimcheck/  load.py evv.py rules.py engine.py learn.py backtest.py predict.py explain.py note_eval.py
  tests/       test_load.py test_evv.py test_rules.py test_engine.py test_actions.py
  out/         profile.txt backtest_report.md predictions.csv queue.html notes.jsonl note_eval.md cache/
  docs/        design.md design.png ai_log.md timelog.md
```

### 3.6 Windows commands

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
$env:ANTHROPIC_API_KEY = "<paste key>"   # this session only; or a local .env (git-ignored)
$env:CLAUDE_MODEL = "<Haiku model id from Anthropic docs>"
pytest -q
python -m claimcheck.learn --cutoff 2026-08-31
python -m claimcheck.backtest
python -m claimcheck.predict              # out\predictions.csv and out\queue.html
python -m claimcheck.explain --limit 200  # --dry-run needs no key
python -m claimcheck.note_eval
start out\queue.html
```

**Secrets**
- The key lives only in `ANTHROPIC_API_KEY`, set in the shell or in a local `.env` loaded by python-dotenv.
- `.env` is in `.gitignore` from the first commit; only `.env.example` is committed.
- No key in code, logs, `CLAUDE.md` or the exported session.
- `explain.py` exits with a clear message if the key is missing.

**Config shape (illustrative):**

```yaml
PY01:
  rounding: eight_minute
  filing_limit_days:
    - {days: 30, dos_to: 2026-07-31, source: "PY01 manual 6.1", status: documented}
    - {days: 45, dos_from: 2026-08-01, source: "PY01 bulletin 2026-07", status: documented}
  priority: {order: [...], learned_from: "DOS <= 2026-08-31", approved_by: Poom}
PY03:
  contract_rules:
    - {id: amendment_3_whole_hours, code: D10, check: units_multiple_of_4,
       dos_from: <learned by learn.py>, status: learned_confirmed, scope_assumption: payer_wide}
```

---

## 4. Evaluation

### 4.1 Time holdout (headline)
- **Fit** on DOS 2026-06-01 → 08-31; **score** on DOS 2026-09-01 → 10-20.
- Learned only from fit months: code priority and the Summit rule's start date.
- Documented rules come from the documents.
- Four configs, each reported on both periods:

| Config | What it shows |
|---|---|
| Documented rules, naive code order, no Summit rule | Floor |
| + Summit rule learned from fit months | Value of the learned rule on unseen months |
| + code priority learned from fit months | **Honest headline** |
| Priority refit on all history | In-sample reference; used for the final `predictions.csv` |

**Summit rule out of time:** report status and code separately, for example "Sep–Oct: N of N non-hourly Summit claims denied, M coded D10". Reference: 20 of 20 denied, 14 coded D10.

### 4.2 Metrics
- **Billing:** false holds (n, $); denial recall and precision.
- **Prediction:** status accuracy; exact accuracy; code accuracy where both actual and predicted are denied; multi-flag accuracy; confusion matrix.
- **Ceiling:** D99 share per period.
- **Slices:**
  - PY01 DOS before/after 2026-08-01;
  - PY02 T1019 pre-Sep / Sep+ weekday / Sep+ weekend;
  - PY03 June vs July+.
- **Ablations:** each bulletin and the Summit rule off, with history flips and how many flips match actuals.

**Tests are not circular.**
- Unit tests come from manual text and hand-made claims.
- The data oracle is the payer's recorded outcome, not an earlier script.

### 4.3 to_check risks (all in the core risk report, C6)

| Risk | Handling |
|---|---|
| Auth balances cross both files | Engine interleaves. Report counts D02 predictions that depend on earlier predicted-paid to_check claims. |
| History leakage through state | Sensitivity run with simulated history outcomes; report the count of changed predictions |
| D99 ceiling | D99 never predicted; expected miss rate stated from the holdout |
| Tie order | claim_id tie-break (assumption); reversed-order run; report changes |
| Thin code-priority pairs | Listed; those claims tagged `MANUAL_REVIEW` |
| Learned-rule scope (C020368) | Tagged `assumption` → `MANUAL_REVIEW` |
| Corrected claims (only in to_check) | Per `billing_basics.md`; listed as untested |
| DOS beyond history | Counted; no documented rule changes after 2026-09-01 |
| Duplicates inside to_check | D05 names the earlier claim and its file |
| Submission order is the biller's choice | Stated assumption; README advice "bill in DOS order", backed by the history D02 count |

**README confidence statement:**
- Status is robust to code-priority choices; expect roughly the holdout status figure.
- Codes are fragile on multi-flag claims, especially the thin-pair list.
- The in-sample 98% is a reference, not the expected score.

### 4.4 Haiku note eval (core, C9)
- **Automatic, on all notes:**
  - schema-valid %;
  - **faithfulness:** % of notes where every number in the text appears in the engine evidence or fixes;
  - completeness: every flag mentioned;
  - action consistent with the class;
  - banned-advice hits (target 0).
- **Graded sample of 20, stratified:**
  - Poom grades against an engine fact sheet, not by taste. Four yes/no items: printed code; every rule; fix matches; action.
  - The template note is graded on the same sheet as the baseline.
  - Sceptic note: Poom grades his own notes, so the items are factual checks with the answer beside them.
- **Cost and latency:** tokens and wall time per call from the API response (median, p95). $ per claim uses Anthropic's published Haiku price on the day.
- **Decision rule:** Haiku notes are shown in the queue only if faithfulness ≥ 95% and the fix item is 20/20 on the sample. Otherwise the template is shown and the README reports the failure.
- **Stated limit:**
  - What the eval shows is that Haiku writes faithful plain notes at a measured cost.
  - Whether a biller acts faster on them than on the template is untested here. It is measured in the pilot (§8).

### 4.5 predictions.csv
- Header `claim_id,status,denial_code`; 546 rows in input order.
- `status` is `paid` or `denied`.
- `denial_code` is one of `D01`–`D10`, or empty when paid. Never more than one code. Never `D99`.

---

## 5. README contents
1. What it does (3 lines), who it's for, the action classes.
2. Results: the holdout table (4 configs × 2 periods), billing KPIs, D99 ceiling, confidence statement, Summit rule out of time (status and code separately).
3. Run instructions (PowerShell and bash), `--dry-run` first, then `start out\queue.html`.
4. Key handling (env var only, `.env` ignored); `CLAUDE_MODEL`.
5. Design: sketch, rules vs AI, what Haiku does and doesn't do, the note eval result, human gates, rule owner.
6. Assumptions, one line each:
   - month-first slash dates;
   - submitted_date = submission order, ties by claim_id;
   - code priority learned from fit months, thin pairs listed;
   - Summit rule payer-wide from the learned date (C020368 flagged);
   - D99 not predicted;
   - export duplicates dropped;
   - corrected claims per `billing_basics.md`;
   - D10 fix untested.
7. Data quirks (from `out/profile.txt`).
8. **How I worked with AI.**
   - Disclosure, in these words: "Before the build, AI agents (planning, ideas and critique roles) analysed the brief and data and wrote the plan I followed. I reproduced and checked their findings with my own scripts in Claude Code. Where my numbers differed, I say so below."
   - Then `ai_log.md` highlights: what Claude Code got wrong and how it was caught.
   - Models used, `CLAUDE.md`, session history.
9. Next steps and rollout (§8).
10. Time spent (`timelog.md`) and Claude Code spend (`/cost`).

---

## 6. Demo script (10 min, one version)

Everything runs on Poom's laptop from his repo. Commands run live. `out/` and the Haiku cache are the fallback, so no beat needs a live API call.

| Time | Beat | What's on screen and said |
|---|---|---|
| 0:00–1:15 | **1. Problem and scope** | The coordinator's question. Rules decide, Haiku explains, humans approve. Out: D99, auto-submit. One line from `out/backtest_report.md`: share of denials the documented rules explain. |
| 1:15–2:15 | **2. Design** | `docs/design.png`: engine over both files, learned-rule gate, two human gates, rule owner. |
| 2:15–3:30 | **3. Proof** | Run `python -m claimcheck.backtest` live. Holdout table: exact on unseen months vs the D99 ceiling; false holds; misses are D99. Summit rule out of time: N/N denied, M coded D10. |
| 3:30–6:00 | **4. The coordinator's queue** | `start out\queue.html`. Summary: flagged/total and $ at stake. Open **C019757**: the payer will print D10, but it also breaks D09. 483 verified min → 32 units under Summit floor rounding; fix 34 → 32 clears both. Open the **HOLD_EVV_PENDING** claim: "wait for the aggregator, don't rework". Point at **C020368**'s assumption tag: "ask, don't trust". |
| 6:00–7:30 | **5. Haiku per claim, measured** | The C019757 Haiku note next to the template. `out/note_eval.md`: faithfulness %, the 20-claim fact check (Haiku vs template), tokens, latency, $ per claim. What it doesn't do: decide or compute. |
| 7:30–9:00 | **6. How I worked with AI** | Disclosure line (README §5.8 wording). 2–3 real `ai_log.md` entries: a Claude Code mistake and how it was caught. The interleave and priority findings: "flagged in the pre-build analysis; I reproduced them; here is my number." |
| 9:00–10:00 | **7. Next and rollout** | Pilot (§8), rule owner, drift monitor, "bill in DOS order", upstream EVV holds. Commercial maths only if asked. |

**If Poom stopped at the 2:00 checkpoint (App v1):** drop beat 5. Its 90 s go to Q&A. In beat 6, say the notes are template-only.

**If stretch exists:**
- **S1:** in beat 4, run `recheck C019757 --set units=32` live instead of reading the fix off the card. No time change.
- **S2:** in beat 6, show the gold diff and the §9.5 refusal for 45 s, replacing one `ai_log` entry. If the gold check failed, show the failure.

**Drop on the day if short, in order:** the C020368 glance → the HOLD card → the third `ai_log` entry. Never drop beat 3 or beat 6.

**Banned lines:** "schedule longer", "bill more". The C019757 fix lowers units to the verified time.

---

## 7. Risks and mitigations

| Risk | Mitigation |
|---|---|
| Engine overrun eats the holdout | C4/C5 split; contingency before the 2h checkpoint; C6 never cut |
| Code-priority overfit | Learned on fit months; thin pairs → `MANUAL_REVIEW` |
| Learned rule wrong in scope | Human approval; assumption tag; never auto-activated |
| Haiku note unfaithful | Automatic number check; template fallback; decision rule |
| Self-grading bias | Factual items with the answer beside them; template baseline; limit stated |
| Honesty gap on provenance | One standard wording, used everywhere (§0) |
| Network or API on demo day | Cache, `--dry-run`, pre-built `out/` |
| Claude Code spend | `/cost` per step; Sonnet default; $20 stop rule |
| Key leak | Env var only; `.env` ignored from the first commit; `git grep` before push |
| Windows quirks | `pathlib`, `encoding="utf-8"`, `start` to open HTML |

---

## 8. How this lands in an agency
1. **Shadow pilot, 4 weeks:** 2 agencies × 1 payer. The queue runs before each submission while billers submit as usual. Compare against payer outcomes weekly.
2. **Gate:** live false-hold rate and recall near the holdout figures. Billers rate notes useful on most flagged claims; this is the readability test the pack can't run.
3. **Assisted mode:** billers act on fix, hold and duplicate actions. Measure first-pass paid rate, days to cash and rework hours against the shadow baseline.
4. **Owners:**
   - Exchange4Health payer-content team: rule packs, drift alerts, approvals;
   - agency billing lead: queue;
   - Exchange4Health product: upstream EVV holds.
5. **Scale:** more payer packs, model-drafted bulletin rules with analyst approval, then checks at visit approval.

---

## 9. Response to critique-v2

The critic's sections §1 and §2 contained concessions and verifications. They are listed where they asked for a change.

| # | Point | Verdict | Reason | Section |
|---|---|---|---|---|
| §1 T1 | C007353 knock-on: plan-v1 was right | **Fixed** (no change) | The critic concedes; Appendix A keeps "1 paid→D02 (C007353)" | App. A |
| §1 AG008 | 0 of 61 in history, not 73; C020368 is the to_check case | **Fixed** | 61 kept; C020368 tagged as resting on the assumption | §2.6, App. A |
| §1 Haiku guidance | The guide advises on model choice, not on how many calls | **Fixed** | Reworded: Haiku for any per-claim calls; per-document calls allowed | §2.3 |
| §2 Summit 17/20 | Say "20/20 denied, 14 coded D10" | **Fixed** | Status and code reported separately | §4.1, App. A |
| M1 | "Found it himself" contradicts the disclosure | **Fixed** | One provenance wording: flagged before, reproduced in build; discovery credit only for build outputs | §0, §5.8, §6 beat 6 |
| M2 | C4 underestimated | **Fixed** | Split into C4 engine (30) + C5 learn (10) = 40 vs 35; 5 min slack before the 2h checkpoint; C6 holdout never cut | §3.2, §3.4 |
| M3 | AI role relabelled, not fixed | **Fixed** | Haiku note + measured eval are in core (Phase 2): auto-faithfulness on all notes, fact-sheet sample vs template, cost/latency, decision rule. Plain statement that its value is wording; fixes and interactions are rules. The prose-reading AI job is stretch S2 with a gold check. | §2.3, §4.4, §3.3 |
| M4 | Two demo scripts | **Fixed** | One script; cut points only drop beats; stretch swaps are in-place | §6 |
| M5 | Nothing a coordinator would touch | **Fixed** | `queue.html` with cards is in Phase 1 core and is beat 4 | §3.2 C7, §6 |
| m1 | Action-class accuracy has no ground truth | **Fixed** | Metric dropped; mapping unit-tested | §1.4, §4.2 |
| m2 | Risk report is stretch but README relies on it | **Fixed** | Risk report is in core C6 | §3.2 C6, §4.3 |
| m3 | Summit holdout wording | **Fixed** | As §2 above | §4.1 |
| m4 | Holdout hard-codes the Summit date | **Fixed** | `learn.py` derives the date from fit months; config holds `<learned>` | §2.1, §3.2 C5 |
| m5 | AG008 inference supports C020368 | **Fixed** | "Consistent with, not proof"; C020368 → `MANUAL_REVIEW` | §2.6 |
| m6 | ideas-v2 still quotes 73 | **Fixed** (no plan change) | The plan has used 61 since v2; ideas-v3 corrected it | App. A |
| m7 | Plan says the guide "recommends" per-claim calls | **Fixed** | Reworded | §2.3 |

**Count: 16 Fixed, 0 Rejected, 0 Deferred.** That is 12 numbered points (M1–M5, m1–m7) plus 4 items from §1–§2.

---

## 10. Visionary change list v3

| # | Change requested | Decision | Where / reason |
|---|---|---|---|
| 1 | Keep 5 demo beats; split live run into proof / queue / rules-current; name the compiler in Problem and Design | **Partly adopted** | One 7-beat script with proof and queue beats (§6). The compiler isn't named in Problem/Design because it is stretch; it swaps into beat 6 if built. |
| 2 | Add C8 queue.html + recheck (25 min) to core, with thin-pair and C020368 tags | **Partly adopted** | `queue.html` with tags is core C7 (10 min, minimal). `recheck` is stretch S1 (10): highest value per minute, but not needed for App v1. |
| 3 | Move the slim compiler into core (30 min) | **Rejected for core** | Core would exceed 165 min and the 3h checkpoint needs the Haiku eval. Kept as stretch S2 by time value. The gold rule is committed in C3 so S2 is ready. |
| 4 | Haiku Job A → stretch; drop S3; S5 as reskin | **Partly adopted** | Remark reader dropped; S5 reskin adopted. Haiku note stays in core with a measured eval: it is the per-claim AI the brief asks to show. |
| 5 | C4 35 → 45 min | **Partly adopted** | C4+C5 = 40 min plus 5 min checkpoint slack; the full +10 doesn't fit a 165-min core. |
| 6 | Drop action-class accuracy; unit-test the mapping; learn the Summit date from fit months | **Adopted** | §1.4, §2.1, §3.2 C5 |
| 7 | Wording: provenance, "advises", Summit line | **Adopted** | §0, §2.3, §4.1 |

**Count: 2 adopted, 4 partly adopted, 1 rejected.** The Visionary's 200-min core / 230-min total is replaced by a 165-min core + 30 stretch + 45 contingency = 240.

---

## Appendix A: Pre-build reference values (AI-agent analysis, disclosed; for cross-checking only)

**Data**
- History: 3,862 rows → 3,830 after dropping 32 exact duplicates; 2,731 paid / 1,099 denied.
- to_check: 546 rows (14 corrected).
- Slash dates are month-first. 9 payer spellings → 3 payers. 16 distinct remark strings.
- Every documented rule's flagged history claims were 100% denied.

**Holdout** (fit Jun–Aug, score Sep–Oct)

| Config | Score exact | Score status |
|---|---|---|
| Naive order, no Summit rule | 95.12% | 97.75% |
| + Summit rule | 95.64% | 98.42% |
| **+ priority learned from fit months** | **97.97%** | **98.42%** |
| Priority refit on all history | 98.20% | 98.42% |

- Ceiling 98.27% (23 D99 of 1,331).
- 1 false hold ($38); 20 missed denials, all opaque D99.
- Simulated history state: 97.96% exact.

**Summit hourly rule** (deduped, non-hourly = units % 4 ≠ 0)

| DOS window | Non-hourly claims | Denied | Codes | Paid |
|---|---|---|---|---|
| June | 105 | 22 | other codes | 83 |
| Jul–Aug (fit) | 32 | 32 | 21 D10, 9 D99, 1 D01, 1 D07 | 0 |
| Sep–Oct (score) | 20 | **20** | **14 D10**, 3 D99, 2 D01, 1 D07 | 0 |

- 47 amendment remarks (35 D10, 12 D99); 0 on hourly claims.
- First amendment DOS 2026-07-01; 5th amendment denial submitted 2026-07-21.
- AG008: June 6 of 13 non-hourly; July onward 0 of 61. to_check: 18 non-hourly Summit claims from July; the AG008 one is C020368.

**Bulletins**
- Northwind: 64 history claims in the 31–45-day window (43 paid).
  - The bulletin changes 49 history predictions (45 D03→paid, 3 D03→D05, 1 paid→D02: C007353); 47 of the 49 match actuals.
  - It changes 17 to_check predictions.
- Harbor notice: 36 history / 14 to_check changes.

**to_check** (prototype engine)
- 377 paid / 169 denied; $17,787.30 of $54,064.80 flagged.
- 29 multi-flag claims; 11 rest on code-priority pairs seen 0–1 times.
- 4 of 13 D02 predictions depend on earlier predicted-paid to_check claims.
- Reversed tie order: 0 changes. Simulated history state: 1 change.
- D05: 20 duplicate a history claim, 7 duplicate another to_check claim.
- D01: 19 have no EVV row, 5 rejected, 4 pending. Pending: C020752, C020748, C021249, C021017.

**Fixes** (re-verified this round)
- C019757 (PY03 T1019, 34 units, 483 verified min) has flags D09 + D10 and is printed as D10. Rechecked at 32 units: paid, with 0 other to_check predictions changed.
- All 93 D07-flagged claims and all 85 D08-flagged claims (history + to_check) have a valid auth on file for the patient, service and DOS.

**Other**
- 21 of 65 history D02s were lost to a later-DOS claim submitted earlier.
- EVV-decided denials: 420 / 1,099 (Q&A only).
