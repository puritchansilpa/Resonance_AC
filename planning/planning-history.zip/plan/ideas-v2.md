# Ideas v2: claims visionary, round 2

*All numbers in this file come from `plan/scripts/ideas_v2_stats.py`, run on `brief/data/` (history deduped from 3,862 rows to 3,830 by dropping the 32 exact-duplicate export rows). Anything that's a forecast or judgement is labelled **ASSUMPTION**. Numbers I take from plan-v1 or critique-v1 (both reproduced by the critic) are marked [plan-v1].*

---

## 0. Response to critique-v1

Every point that touches the ideas, with what I did about it. Points that only touch the base build (m3, m5) are listed at the end so nothing goes missing.

| # | Critique point (paraphrased) | Verdict | What changed |
|---|---|---|---|
| ✓-table | "64 Northwind claims, all paid" is wrong. | **Accepted. My error.** I counted "not D03" as "paid". | Corrected throughout: 64 claims in the 31–45-day window after 1 Aug, **43 paid**; the bulletin changes **49** history predictions, **47/49 match actuals**, exact accuracy 96.84% → 98.07% [plan-v1]. |
| ✓-table | "No patient has two visits for one service on one day" is wrong (8 exist, none billed). | **Accepted.** I only checked *billed* patient-days. | Wording is now "no *billed* claim falls on a multi-visit day, so summing is untested". |
| ✓-table | Amendment counts are raw rows. Deduped is 35 D10 + 12 D99 = 47, June 105. | **Accepted.** | All counts in v2 are deduped. |
| B1 | Findings were made by agents before the build. The candidate has to own them, and use of other AI tools must be disclosed. | **Accepted for the ideas.** | Every headline number now has a one-line derivation the candidate can say without notes (§1 and each idea's Evidence), and a single script reproduces them (`plan/scripts/ideas_v2_stats.py`). The ideas file is pre-build analysis and should be disclosed as such in the README "Tools used". I also removed the "surprise reveal" framing (see m7), because it invites the question "who found that?". |
| M1 | No contingency. The ideas "Hours check" was on top of a 210-min base. | **Accepted.** | Picks now cost **55 min firm + 15 optional**, and I propose a **swap** to pay for them: the bulletin compiler replaces plan step 8's Haiku explainer and LLM-only baseline (25 min). Net add to base: **+30 min firm**. Budget table in §3. |
| M2 | AI looks ornamental. The plan misread the brief as "Haiku per-claim only" and so rejected LLM bulletin extraction, the one place AI does real work. | **Accepted, and it drives v2.** The guide says Haiku is *cheaper* per claim, not that only per-claim calls are allowed. | Each idea now has an "AI earns its place?" test. Result: **AI stays in exactly one idea** (bulletin compiler), with a gold-standard check. AI is **cut** from the Hidden-Rule idea (16 distinct remark strings are something a human reads in 2 minutes) and was never in the Guardian, Runway or Fingerprint ideas. |
| M3 | In-sample. The amendment rule's date was read off history. | **Accepted for the ideas.** | Amendment-3 time holdout: learn from DOS Jul–Aug (30/32 non-hourly PY03 claims carry the amendment remark, the other 2 were denied for other reasons, 0 paid). Test on DOS Sep–Oct: **17/20 amendment, 3 other denials, 0 paid**. The rule predicts unseen months. The bulletin compiler is verified against a hand-encoded gold config, not against itself. |
| M4 | "What good looks like" is a leaderboard metric, not a billing outcome. | **Accepted for the commercial story.** | §4 now leads with billing-manager KPIs (clean-claim rate, $ wrongly held, denials missed, days to cash). The $38B scale maths is moved to a Q&A appendix. |
| M5 | Nobody owns rule config. How does an unannounced payer change get caught in production? | **Accepted. This became an idea.** | Owner: **Exchange4Health payer-content team** owns payer rule packs centrally. Agencies never edit YAML. The bulletin compiler drafts changes, and a payer-content analyst approves them. Unannounced changes are caught by the **Rule Drift Monitor** (Idea 3), which on this data would have raised Summit's amendment 3 after its 5th denial (submitted **2026-07-21**, 15 days after the first on 2026-07-06). |
| M6a | The "38% decided at clock-out" stat overclaims. D09 is decided by whoever enters units (128/239 are round-up), and D01 includes 78 coordinator/aggregator cases. | **Accepted on the wording. The number stands, with a different claim attached.** | 38.2% = 420/1,099 denials **by count**, and the defensible claim is "*decided by the EVV record alone*", not "decided at clock-out" or "caused by caregivers". Full derivation and follow-ups in §1. |
| M6b | Beat 1's "bill 4 or schedule 2h" is a padding nudge. | **Accepted. Removed.** | And "bill 4" had no evidence either: **0** Summit claims after July were billed in whole hours *below* verified time, so we can't show that down-billing pays. The Guardian now says **HOLD, with the reason**, and makes no suggestion to the caregiver or the biller. |
| M6c | Beat 2 still says "64/64". | **Accepted.** | Now 49 changed predictions, 47/49 match actuals [plan-v1]. |
| m1 | Pending EVV visits are a fixable HOLD, not a denial. | **Accepted.** | Guardian output has three states: **DENY-RISK** (no EVV row, or units over verified), **HOLD** (visit `manual_edit_pending`: wait for the aggregator), and **FIX VISIT** (`rejected`). History: 103 / 33 / 45. to_check: 19 / 4 / 5. |
| m2 | Drawdown assumes file order is the real submission order, and the biller controls order. | **Accepted. Evidence added.** | **21 of 65** historical D02s were beaten by a later-DOS claim on the same auth that was submitted earlier. That's the Runway's (Idea 4) advice: bill in DOS order. The tool's stated assumption: "file `submitted_date` = submission order". |
| m4 | Too many demo beats. Run on cached output. | **Accepted.** | Ideas no longer add beats. They *replace* plan §6's 7:00–8:15 "Hidden rule" slot with one 75-second beat, run from cached LLM output (§5). |
| m6 | Commercial maths will read as inflated. Keep it out of the 10 minutes. | **Accepted.** | Moved to an appendix, for Q&A only. |
| m7 | The hidden-rule "reveal" is a surprise to the people who planted it. Governance is what earns marks. | **Accepted.** | Reframed as Rule Drift Monitor: label noise (12 D99 vs 35 D10), human confirmation, the payer-wide assumption (AG008 complied: 0 of 73 non-hourly after July [critique-v1]), and the time holdout. |
| m8 | Claude Code spend isn't budgeted. | **Accepted for the ideas' share.** | The compiler makes about 5 LLM calls per run (2 bulletins + 3 manuals), cached, so it costs cents. I can't size Claude Code spend from the files. It belongs in the plan's budget. |
| m3, m5 | D05 between two to_check claims; unseen precedence pairs. | Base build only, so no ideas change. | None. |

---

## 1. The opening stat, re-derived

**Defensible version:** **38.2% of denials in this data pack (420 of 1,099, by count) are decided by the EVV record alone.** That's data Exchange4Health already holds before the claim is created. By dollars it's **36.5%** ($42,000.20 of $114,913.30 denied).

| Element | Exact value |
|---|---|
| Population | `claims_history.csv`, exact-duplicate rows dropped (3,862 → 3,830 claims), `status == denied` → **1,099** |
| Numerator | Denials reported as **D01** (181) + **D09** (239) = **420** |
| Definition | D01 = no *verified* EVV visit for patient + service + clock-in date. D09 = billed units > verified minutes converted with the payer's rounding (Northwind 8-minute rule; Harbor and Summit floor). |
| Validation | Join to `evv_visits.csv`: **0** of the 181 D01s have a verified visit; **0** of the 239 D09s are within verified units. Every claim the EVV check flags is denied (**441/441**). 21 of those were *reported* under another code because the payer reports one code only. |
| Filters | None beyond the dedupe. All payers, agencies and months. |
| Count vs $ | 38.2% by count, 36.5% by billed $ |

**"How did you get that?" (one line):** "I dropped 32 duplicate export rows, which leaves 1,099 denials. I joined every claim to its EVV visit on patient, service and clock-in date. 181 have no verified visit and 239 bill more units than the verified minutes allow under that payer's rounding. 420 over 1,099 is 38%."

**Likely follow-ups and answers:**
1. *"Isn't D09 a billing error, not the caregiver's?"* Yes, and that's the point. **128 of the 239** billed exactly ceil(minutes ÷ 15), so someone rounded up. The fix is to stop typing units: derive them from verified minutes using the payer's rule. I'm not claiming caregivers caused 38%. I'm claiming the EVV record alone decides it.
2. *"How much is genuinely visit-side?"* D01 = 181 (16.5%). Of those, 103 have no EVV row at all, 45 were `rejected` and 33 are `manual_edit_pending`. The 33 are a wait, not a denial (the m1 HOLD state).
3. *"Your earlier draft said 58.5%. Which is it?"* Different question and different rows. 58.5% / 604 of 1,104 was raw rows (32 duplicates included), by **dollars**, and it also counted D06 (daily max), D10 (Summit hourly) and D02 (auth exhausted). Deduped, that set is **599 / 1,099 = 54.5% by count, 58.3% by $**. I dropped it as an opener because it lumps three different owners together (visit, schedule and authorization) and invites exactly the "who actually decided that?" challenge. 38.2% has one owner, the EVV record, and survives the question.
4. *"Real world?"* No. It's a synthetic pack, so this is a statement about this data, not the industry.

---

## 2. Ideas

### Idea 1: Clock-out Guardian (rules only) ⭐ PICK (lite)

**Pitch:** Units come from the verified visit, not a keyboard. Hold anything the EVV record already says will bounce.

**Evidence:** 420 of 1,099 denials are EVV-decided (§1). 128/239 D09s are round-ups, median overbill 1 unit. to_check has 28 claims without a verified visit: 19 have no row, 5 are rejected and 4 are pending. Payer rounding matters: Northwind 127 min → 8 units, Harbor and Summit 128 min → 8, Northwind 128 → 9 [plan-v1 tests].

**Beyond the assistant:** It runs at the moment the data is created (clock-out and visit approval), not 15 days later (the median submission lag in history). Three states, per m1: **DENY-RISK**, **HOLD (pending aggregator)** and **FIX VISIT (rejected)**.

**AI earns its place?** **No AI, by design.** Rounding, matching and verification status are arithmetic and lookups. An LLM would add error and no value.

**Guardrail (M6b):** It never suggests longer visits, re-scheduling or a different unit count. It shows the billable units the verified time supports and, where a payer rule blocks the claim (e.g. Summit 110 min → 7 units, non-hourly after 1 July), says **HOLD + the rule + source**. A human decides. There's no evidence in the data that down-billing to whole hours pays (0 such claims), so we don't recommend it.

**Build:** plan-v1 already has the units calculator and the "do not bill until verified" list (step 9). Increment: three-state labels and the no-nudge copy, **10 min**.

**Scores:** Impact 4 · Build 10 min (incremental) · Demo 3 (it's a calculator; the stat carries it)

**Risks / limits:** The real caregiver app isn't available, so this is a simulated surface. Say so. Multi-visit-day summing is untested (8 multi-visit days exist, none billed).

---

### Idea 2: Bulletin-to-Rule Compiler (LLM + human approval) ⭐ PICK (the AI centrepiece)

**Pitch:** A payer publishes prose and gets back a dated, approved, backtested rule. The AI drafts, a human approves, and history checks the result.

**Evidence:**
- Northwind bulletin 2026-07 (45-day filing for DOS ≥ 2026-08-01): switching it on changes **49** history predictions, **47/49** match actuals, and exact accuracy goes from 96.84% to 98.07%. It changes 17 to_check predictions [plan-v1, reproduced by critique].
- Harbor notice 2026-08 (weekend T1019 needs U3 from DOS 2026-09-01): 36 history and 14 to_check prediction changes, exact 97.18% → 98.07% [plan-v1]. Raw history: 25 weekend U3 paid, 3 weekend U2 → D04.
- Summit §9.5 "additional billing requirements may apply under your agency's contract" contains **no extractable rule**. The real one (amendment 3) is in no document.

**AI earns its place?** **Yes. This is the one place rules can't do the job.**
- *What deterministic code can't do:* read a free-text notice and work out the payer, the rule type, the old and new values, the scope (service code, weekday/weekend) and the effective date, keyed to DOS rather than submission date. Regex over 5 short docs would work for exactly these 5 and break on the 6th. At 180+ payers, prose intake is the bottleneck, and today it's done by hand.
- *What the LLM outputs:* a JSON rule diff against a fixed schema (`payer, rule_type ∈ {timely_filing, modifier, rounding, daily_max, auth, contract_other}, params, effective_from, date_basis, scope, source_quote`). The `source_quote` must be a verbatim substring of the doc, checked by code. It also outputs `"no_actionable_rule"` with a reason when the text doesn't specify one.
- *Human in the loop:* the diff is written to `proposed/`, never to live config. A payer-content analyst (M5 owner) approves it with one command, and only then does it merge.
- *How it's verified against history:* (1) a **gold check**: the hand-encoded rules in plan-v1's config are the answer key. The extraction must match field for field on the 2 bulletins and on the rounding, filing and modifier rules in the 3 manuals. (2) A **refusal check**: Summit §9.5 must come back `no_actionable_rule`. Inventing a rule there is a test failure. (3) A **backtest gate**: on approval, the existing ablation reruns and shows the flips (49 → 47 correct for Northwind) before the change goes live. *ASSUMPTION: Haiku-tier extraction passes the gold check. Unverified until it's built. If it fails, show the failure; that's a better "how I checked the AI" story than a pass.*

**Build:** extraction script, schema validation, quote check, gold diff, `proposed/` + approve command. It reuses plan's ablation for the backtest gate. **40–45 min.** Paid for by cutting plan step 8 (Haiku explainer + LLM-only baseline, 25 min); keep a template explanation instead.

**Scores:** Impact 4 · Build 45 min · Demo 5

**Risks / limits:** n = 5 documents, so it demonstrates the capability rather than proving it at scale. Say so. LLM date errors are caught by the gold and backtest checks, but in production, without gold, the backtest gate and the human are the only safeguards. Network dependency on demo day → cache the outputs.

---

### Idea 3: Rule Drift Monitor (was "Hidden-Rule Detective"; AI cut) ⭐ PICK (optional, 15 min)

**Pitch:** When a payer changes the rules without telling anyone, find out from the denials within two weeks, not from the month-end write-off report.

**Evidence:**
- 47 denials (deduped) carry "Contract amendment 3: … whole hours" / "Units not billable per amendment 3 …": **35 coded D10, 12 coded D99**. So the payer's own codes are noisy, and the remark text is the more reliable signal.
- PY03 non-hourly claims: **June 105 → 0 amendment** (83 paid). **Jul–Aug 32 → 30 amendment, 2 other denials, 0 paid. Sep–Oct (holdout) 20 → 17 amendment, 3 other denials, 0 paid.**
- 11 of 12 agencies hit. AG008 complied (0 of 73 non-hourly after July [critique-v1]), which supports the payer-wide assumption.
- Detection timing (by `submitted_date`): first amendment denial 2026-07-06, 5th on **2026-07-21**, 10th 2026-08-10.

**Beyond the assistant:** This is the production answer to M5: rules stay current because the network's denials are watched, not because someone reads every contract. One agency's denial protects every other agency.

**AI earns its place?** **No. Cut.** History has **16 distinct remark strings**. Grouping by exact remark × payer × DOS month × unit pattern (plan's deterministic `mine_remarks.py`) finds it, and a human reads 16 strings in two minutes. An LLM "hypothesis" step here would be decoration. *Where an LLM might earn a place:* normalising free-text remarks across 180+ payers with thousands of wordings. **This synthetic data can't support that claim**, so it stays a sentence in "next steps".

**Human in the loop:** the monitor only creates a *candidate* rule with support, precision and holdout numbers. It goes to the same approval queue as Idea 2, labelled "learned from denials, not from a document".

**Build:** plan step 7 already builds the miner (15 min). Increment: the DOS-month holdout table + "alert when a new remark × payer reaches 5 denials". **15 min, optional.** First to cut.

**Scores:** Impact 4 · Build 15 min (incremental) · Demo 3 (governance story, not a reveal)

**Risks / limits:** Planted data is clean. Real remarks are messy and real amendments may be per-agency ("your agency's contract"). A threshold of 5 is an **ASSUMPTION**. Never auto-activate.

---

### Idea 4: Authorization Runway (rules only) — not a pick (plan-v1 has the minimal flag)

**Pitch:** Bill in date-of-service order, and see which auths run out before the claims do.

**Evidence:** **21 of 65** D02s were denied because a *later-DOS* claim on the same auth was submitted earlier and paid first. Example: AUTH10512, June-21 visit `C003070` submitted 09/29 after later visits had drawn the balance. Drawdown has to interleave both files to explain all 65 D02s [plan-v1].

**AI earns its place?** No. It's a stateful ledger, and that's exactly what LLMs do badly.

**Scores:** Impact 3 · Build 20 min beyond plan's at-risk flag (sort advice + balance view) · Demo 2

**Why not picked:** plan-v1 already carries the at-risk flag. A forecast isn't supportable (no future schedule in the pack). The "bill in DOS order" line goes into the README and the demo close for free.

---

### Idea 5: Agency Denial Fingerprint — DROPPED

**Why dropped:** small cells (some codes have 0–3 per agency across 12 agencies), off the core job, and there's no AI role. The one useful line survives as a talking point: D09 runs from 3.5% of claims (AG005) to 9.4% (AG006), and the 239 D09s are spread over many caregivers, so it's an agency process problem, not a rogue caregiver. That's a coaching and RCM-upsell story for Q&A only.

### Idea 6: Certified Clean Claim (payer-side pre-adjudication) — DROPPED from build, Q&A only

**Why dropped:** the only supporting fact is that payer adjudication here is almost entirely rule-computable (1,038 of 1,099 denials, 94.4% [plan-v1]). There's nothing in the data on payer appetite, adjudication cost or payment speed. It's a strategy hypothesis, not a build.

### Idea 7: LLM reader for "see payer correspondence" denials — DROPPED

**Why dropped:** 61 opaque D99s ("Denied - contact payer", "Under review - see payer correspondence") have no correspondence in the pack. An LLM would have nothing to read. The data can't support it. Route these to a human and say so.

---

## 3. Scores and build budget

| # | Idea | AI? | Impact | Build (incremental) | Demo | Status |
|---|---|---|---|---|---|---|
| 1 | Clock-out Guardian | none | 4 | 10 min | 3 | ⭐ PICK |
| 2 | Bulletin-to-Rule Compiler | **LLM, gold-checked** | 4 | 45 min | 5 | ⭐ PICK |
| 3 | Rule Drift Monitor | none (cut) | 4 | 15 min | 3 | ⭐ PICK, optional |
| 4 | Authorization Runway | none | 3 | 20 min | 2 | not picked |
| 5 | Agency Denial Fingerprint | none | 2 | 30 min | 2 | DROPPED |
| 6 | Certified Clean Claim | none | 5 (long run) | 0 | 1 | DROPPED (Q&A) |
| 7 | Correspondence reader | LLM | — | — | — | DROPPED (no data) |

**Fit against plan-v1 (210 min, zero contingency) and critique M1 (core inside about 150 min):**

| Line | Min |
|---|---|
| plan-v1 base | 210 |
| − step 8 (Haiku explainer + LLM-only baseline), replaced by a template explanation | −25 |
| + Idea 2 compiler | +45 |
| + Idea 1 increment | +10 |
| **= firm total** | **240** |
| + Idea 3 increment (optional) | +15 → 255 ✗ |

So the firm picks fit **only at the 4-hour ceiling with plan-v1 as written**. They need plan-v2 to trim its core, which critique M1 already demands (e.g. the Streamlit scope in step 9). At a 150-min core: 150 + 55 = **205 min, leaving 35 min of contingency** and room for Idea 3. Cut order if time runs short: Idea 3 → Idea 1 copy → (last) Idea 2. Idea 2 is the only AI in the build that does work rules can't, so cutting it reopens M2.

---

## 4. Commercial story (short; billing outcomes first)

**What a billing manager signs up to** (all measurable on this data's backtest):
- **Denials caught before submission** (recall of "denied"). EVV-decided denials alone are 420 of 1,099 (38.2%).
- **Claims wrongly held** (false holds, i.e. cash delayed for nothing). This is the number that kills adoption if it's high.
- **HOLD vs DENY split.** In to_check, 4 claims should *wait* (pending visit), not be reworked.
- *ASSUMPTION, not in the data:* days to cash and rework hours per denial. Measure these in a pilot, don't claim them.

**Who pays:** providers (billing module, and the existing outsourced RCM line). Payers (fewer bad claims, programme-integrity fit, and long term the shared rule pack from Idea 6). Caregivers don't pay; they benefit from correct hours first time. Pricing isn't published (brief §4), so there's no ROI price claim.

**Moat:** Ideas 1 and 3 need the visit, the auth and the claim outcome for the same visit, across many agencies. A standalone claim scrubber has only the claim.

**Appendix, for Q&A only (m6):** $38B ÷ 32,000 providers ≈ $1.19M per provider per year (from the brief; *ASSUMPTION: evenly spread, all claim revenue*). Any "preventable $" beyond that needs an assumed real-world denial rate. The pack's 30.4% ($114,913 / $377,464 deduped) is synthetic and almost certainly inflated, so I won't put a network-wide figure on screen.

---

## 5. Demo moment (fits plan §6 slots; adds no beats)

- **0:00 opener (one sentence, in plan's "Problem" slot):** "38% of the denials in this pack, 420 of 1,099, are decided by the EVV record alone, before anyone types a claim." Keep the §1 one-liner ready.
- **Units calculator (inside plan's live-demo slot, 20 s):** Northwind 127 min → **8 units, not 9**. Summit 110 min → **HOLD: 7 units, non-hourly, amendment 3 since July**. No suggestion of what to bill.
- **Replace plan's 7:00–8:15 "Hidden rule" beat with "Keeping rules current" (75 s, cached output):**
  1. Show the Northwind bulletin text (5 lines of prose).
  2. Show the cached LLM output: a JSON diff with a verbatim source quote, sitting in `proposed/`.
  3. Show the gold check passing (or failing; tell the truth) and **Summit §9.5 → `no_actionable_rule`**. *"The most important output is the one where it said it couldn't tell."*
  4. Approve → the backtest gate shows 49 flips, 47 correct. Then one sentence: "Rules no document contains get caught from denials instead. Summit's whole-hours change would have alerted on 21 July, after five denials."
- **Guardrails, said out loud:** rules compute every prediction. The LLM only drafts rule changes, which are quote-checked, gold-checked and human-approved. Nothing goes live without a backtest.
