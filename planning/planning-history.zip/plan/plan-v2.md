# Plan v2: Resonance take-home, Exchange4Health claims pre-check

Standalone plan. It replaces plan-v1 (left untouched). Poom drives the build himself in Claude Code, from his own scripts.

Every number in this file was produced by code on `brief/data/`:
- `profiling/holdout.py`, `profiling/flagsim.py`, `profiling/tocheck_risk.py` (new this round);
- `plan/scripts/ideas_v2_stats.py` (Visionary, re-run by me).

In §1–§8, numbers appear only as **things the build must measure**. Pre-build reference values sit in Appendix A, labelled. Use them to cross-check after Poom's own run, never as targets in prompts.

---

## 0. Ownership and disclosure (how this plan is meant to be used)

**Who did what**
- Pre-build analysis was done by AI agents outside Claude Code: this plan, two ideas files, a critique and profiling scripts. The README's "Tools used" section says so plainly, as the setup guide asks.
- The build is Poom's, in Claude Code. Every finding the app relies on must come out of a script Poom asked for, ran and read in his own repo:
  - date formats
  - payer rounding
  - effective-dated bulletins
  - cross-file auth drawdown
  - code precedence
  - Summit amendment 3

**The working rule for each step (§3)**
1. Poom gives Claude Code the prompt in this plan.
2. He reads the code it writes.
3. He runs it.
4. He checks the "Verify yourself" items by looking at rows, not at a pass/fail line.
5. He writes one line in `docs/ai_log.md`: what Claude did, what he changed, what went wrong.

That log, plus `CLAUDE.md` and the exported session history, is the "how I worked with AI" story. **No failure is scripted in advance.** The demo reports whatever actually went wrong.

**Defend-without-notes list.** Before the demo, Poom must be able to explain each of these from his own output:
1. Why drawdown must run over both files in submitted-date order.
2. How the code-precedence table was learned, and which pairs are guesses.
3. Why the Summit hourly rule is treated as learned, how it holds out of time, and why D10 is the predicted code.
4. Why D99 is never predicted.
5. What Haiku adds over a template, with his graded sample.

---

## 1. Problem framing and scope

### 1.1 User and job
- **User:** an agency billing coordinator, the day before claims go out.
- **Job:** for each claim, the tool answers four things:
  1. Will it pay?
  2. If not, which single code will the payer report?
  3. Which rules does it break? (It can be several. The payer prints one.)
  4. What does the biller do: submit, fix and submit, hold, or write off?

### 1.2 In scope
- **Pre-submission check of `claims_to_check.csv`:**
  - the three payers' manuals and bulletins, as effective-dated rules;
  - the cross-file chronological engine for duplicates, auth drawdown and daily max;
  - one learned contract rule (Summit), behind human confirmation.
- **Per-claim Haiku action note** for every flagged claim (§2.3).
- **Evaluation:**
  - a backtest with a time holdout;
  - billing KPIs;
  - a to_check risk report;
  - a graded sample of Haiku output.
- **Outputs:** `predictions.csv`, a backtest report and a short README with a design sketch.

### 1.3 Out of scope, and why
- **Predicting opaque D99s** ("Denied - contact payer", "Under review…"). Nothing in the data explains them. They are routed to a human.
- **Real EVV app or scheduling integration.** Not in the pack.
- **Auto-submitting or auto-correcting claims.** Money moves, so a human signs off.
- **Payment amounts.** Paid claims in history are paid in full.
- **A full UI.** It is optional (stretch S5). The core is CLI + markdown report + CSV.

### 1.4 What good looks like (billing outcomes first)

| Outcome | Metric | Why a billing lead cares |
|---|---|---|
| Don't hold good claims | **False holds**: predicted denied, actually paid (count and $) | Each one delays cash for nothing. It kills adoption if high. |
| Catch denials before the payer does | **Denial recall** | Each miss is rework or a write-off |
| Right action | % of flagged claims with the correct action class (fix / hold / write off) | A hold for a pending EVV visit is not a denial (m1) |
| Right code | Exact status + code accuracy | Needed to aim the fix; secondary |
| Trustworthy on unseen claims | All of the above on a **later-months holdout** | The assessors grade the 546 unseen claims |

**Pilot KPIs** (not measurable in the pack; measured in a pilot, §8):
- first-pass paid rate;
- days from DOS to cash;
- rework hours per 100 claims;
- false-hold rate.

---

## 2. System design

### 2.1 Components
1. **`load.py` — normaliser.**
   - Explicit date formats only (`%Y-%m-%d`, `%m/%d/%Y`), no `dayfirst` guessing; fails on any unparsed value.
   - Maps payer spellings to PY01–PY03.
   - Strips and upper-cases service codes and modifiers.
   - Drops exact-duplicate export rows (not the same as D05 duplicates).
2. **`rules/payers.yaml` — effective-dated rules per payer.**
   - Covers rounding, filing limit, modifier, daily max, contract rules and precedence.
   - Each entry has `source`, `effective_from`/`to`, `date_basis: DOS`, and `status` (`documented` | `learned_confirmed` | `assumption`).
3. **`evv.py` — EVV matcher.**
   - Key: verified visits by patient + service + clock-in date (overnight visits belong to the clock-in day).
   - Sums minutes, then converts them to units with the payer's rounding.
4. **`rules.py` — static checks** (pure functions):
   - D01 no verified visit
   - D03 filing limit by DOS window
   - D04 PY02 T1019 modifier, weekend U3 from the notice date
   - D07 missing auth
   - D08 auth invalid
   - D09 units over verified time
   - D10 learned Summit rule
   - Each returns evidence: minutes, allowed units, lag, limit, deadline date, auth window.
5. **`engine.py` — one chronological pass** over history ∪ to_check, sorted by (submitted_date, claim_id).
   - State: duplicate keys (D05), auth balances (D02), PY02 member-day paid units (D06).
   - History rows update state with their actual outcome; to_check rows use their predicted outcome.
   - Records **all** flags. Then it picks the reported code with the payer's precedence list.
6. **`learn.py` — learns from history:**
   - (a) code precedence per payer, from pairwise wins among multi-flag denied claims;
   - (b) candidate contract rules from remark × payer × DOS month × unit pattern.
   - Takes a date cutoff, so the holdout is honest. Output goes to `proposed/` for Poom to approve into config.
7. **`explain.py` — Haiku, one call per flagged claim** (§2.3).
8. **`backtest.py`, `predict.py`** — reports and `out/predictions.csv`.

**Action classes added by the rules** (not the model):

| Class | When |
|---|---|
| `SUBMIT` | No flags |
| `HOLD_EVV_PENDING` | D01 where the visit is `manual_edit_pending`. Wait for the aggregator; do not rework (m1). |
| `FIX_VISIT` | D01 where the visit is `rejected` |
| `FIX_AND_SUBMIT` | Fixable flags: units, modifier, auth number |
| `DROP_DUPLICATE` | Names the earlier claim_id it duplicates, in history or in to_check (m3) |
| `WRITE_OFF_OR_SUBMIT_BY` | D03, with the computed deadline date |
| `MANUAL_REVIEW` | Thin-evidence precedence, or anything unexpected |

### 2.2 Rules vs AI

| Concern | Owner | Reason |
|---|---|---|
| Dates, lags, effective dates, rounding, EVV match, auth window, drawdown, daily max, duplicates | Rules | Exact, stateful arithmetic. An LLM adds error. |
| Which code the payer reports | Rules (learned precedence table, human-approved) | Auditable; tested out of time |
| `status`, `denial_code` in predictions.csv | **Rules only** | The model never changes a prediction |
| Action note for the biller (all issues, ordered fixes, resubmission instruction) | **Haiku** | See §2.3 |
| Reading payer free-text remarks on returned denials | **Haiku** | See §2.3 |
| New or changed rules | `learn.py` proposes (stretch: LLM drafts from bulletins), **human approves** | A wrong rule blocks payable claims |

### 2.3 What Haiku does per claim that rules can't

Haiku is called **once per flagged claim**, using the cheaper per-claim pattern the setup guide recommends. Its role is deliberately small. Rules decide; Haiku makes the decision usable and reads text. It does two jobs.

**Job A — action note for a flagged to_check claim.**

*Input:*
- normalised claim fields;
- every flag with its evidence;
- the reported code;
- the action class;
- the verbatim rule text from the manual or bulletin (quoted from `brief/data`);
- the corrected-claim rule from `billing_basics.md`.

*Output:* schema-validated JSON:

```json
{"summary": "...", "issues": [{"code": "D09", "why": "..."}],
 "fix_steps": [{"order": 1, "action": "...", "field": "units", "from": 15, "to": 14}],
 "resubmit_as": "new | corrected (frequency 7, original_claim_id=...) | do not resubmit",
 "watch_out": "..."}
```

*What it adds over a template:*
- Claims that break several rules need fixes **combined and ordered**. The payer prints one code, so a biller who fixes only that one gets denied again on the next rule.
- Some fixes interact:
  - Cutting units to clear D09 changes the auth balance (D02) and the Harbor day total (D06).
  - A passed filing deadline makes every other fix pointless.
  - A pending EVV visit means "wait", not "rework".
- A template lists flags. Haiku writes one instruction in billing language, with the order and the reason.
- Whether that actually beats a template is **measured, not assumed** (§4.4).

**Job B — remark reader** (history and returned denials).

*Input:* the payer's free-text remark, the reported code, `denial_codes.md`.

*Output:* `{code_meant_by_remark, matches_reported_code: bool, note}`.

*What it adds:*
- It catches cases where the payer's code and its words disagree, which feeds the rule monitor (§2.6).
- Honest limit: this pack has only 16 distinct remark strings. A lookup table would also work here. The LLM's value is reading wordings it has never seen, across 180+ payers.
- The eval tests that directly. Haiku gets no lookup, only the code list.

**Guardrails on both jobs:**
- temperature 0; JSON schema; responses cached on disk by input hash; hard cap on calls per run;
- `--dry-run` uses templates and needs no key;
- model id from env `CLAUDE_MODEL` (Haiku tier).

**Code-checked consistency on Job A:**
- Every numeric `from`/`to` must equal an engine evidence value.
- Every flag must appear in `issues`.
- `resubmit_as` must agree with the action class.
- No text may suggest longer visits or different scheduling (the no-upcoding rule).
- A failure is logged and the template is shown instead.

### 2.4 Human in the loop
- **Biller:** works the flagged queue (`MANUAL_REVIEW` first) and accepts or edits each note. The tool never submits.
- **Payer-content analyst** (owner, §2.5): approves any rule or precedence change from `proposed/`, after seeing the backtest delta (how many history predictions flip, and how many flips match actual outcomes).
- **Opaque D99s:** go to manual review and are never auto-labelled.

### 2.5 Who owns the rules (M5)
- The **Exchange4Health payer-content team** owns one rule pack per payer, centrally. Agencies never edit YAML.
- Inputs are payer manuals, bulletins and (in production) denial feedback from the whole network.
- Changes go through `proposed/` → backtest delta → analyst approval → versioned release.
- Agency billing leads own the queue, not the rules.

### 2.6 Unannounced payer changes (amendment 3 as the worked case)
- **Production:** a rule-drift monitor runs over incoming denials. It alerts when a new remark × payer pattern reaches N denials (N = 5 is an ASSUMPTION). The candidate rule (payer, condition, effective date, support, precision) goes to `proposed/`, labelled "learned from denials, not from a document".
- **In this build:** `learn.py` finds it with a cutoff of DOS ≤ 2026-08-31. Poom inspects the evidence table and approves the rule into config with `status: learned_confirmed`.
- **Governance points to say out loud:**
  - The payer codes the same remark as D10 and as D99, so the remark is the more reliable signal.
  - The rule is applied payer-wide, an ASSUMPTION backed by checking the one agency never hit.
  - It is checked out of time (§4.1).

### 2.7 Design sketch

```mermaid
flowchart LR
  subgraph Inputs
    CH[claims_history] & CC[claims_to_check] & AU[authorizations] & EV[evv_visits]
    DOC[manuals + bulletins + denial_codes]
  end
  CH & CC & AU & EV --> N[load.py<br/>dates · payer names · codes · dedupe]
  DOC -->|hand-encoded, cited| CFG[(rules/payers.yaml<br/>effective-dated, per payer)]
  CH --> L[learn.py<br/>precedence + candidate rules<br/>date cutoff for holdout]
  L --> P[/proposed/]
  P --> A{{Payer-content analyst<br/>approves after backtest delta}}
  A --> CFG
  N --> E[evv.py<br/>verified min → units, payer rounding]
  E --> R[rules.py static checks]
  CFG --> R
  R --> S[engine.py chronological pass<br/>history ∪ to_check by submitted_date<br/>D05 · D02 · D06 · all flags · precedence]
  CFG --> S
  S --> PR[predictions.csv]
  S --> BT[backtest.py<br/>holdout · KPIs · to_check risk]
  S -->|flags + evidence + quoted rule| H[Haiku per flagged claim<br/>action note · remark reader<br/>schema + consistency checks]
  H --> Q[Queue: report or Streamlit]
  S --> Q
  Q --> B{{Biller decides,<br/>submits outside tool}}
```

Deliverable: `docs/design.md` (this mermaid) and `docs/design.png` (export from mermaid.live), linked from the README.

---

## 3. Build plan (core 150 min, stretch separate, hard cap 4h)

### 3.0 Time and cost tracking
- Poom keeps `docs/timelog.md` with start and stop per step. The pre-build agent analysis is disclosed separately and is not presented as build time.
- **Claude Code spend** (m8): Sonnet by default and Opus only for one design step, as the setup guide suggests. Run `/cost` at the end of every step and log it.
- If spend passes $20 of the $40 key before the core is done, stop using Opus and shorten the prompts. Haiku calls are capped per run and cached.

### 3.1 Core steps (150 min)

Each step has a prompt for Claude Code, a "Verify yourself" list and a done-when.

**C0. Repo and guardrails (10 min)**
- *Prompt:* "Set up a Python repo in this folder: venv, requirements.txt (pandas, pyyaml, anthropic, python-dotenv, pytest), .gitignore with .env, .venv/, out/cache/. Add .env.example with empty ANTHROPIC_API_KEY and CLAUDE_MODEL. Write CLAUDE.md: never read or print the key; rules compute predictions, the LLM never does; explicit date formats only; every rule cites its source file."
- *Verify yourself:* `git status` doesn't list `.env`. `CLAUDE.md` says what you want.
- *Done when:* first commit pushed with no secrets (`git grep -i "sk-ant"` returns nothing).

**C1. Load and normalise (20 min)**
- *Prompt:* "Write claimcheck/load.py. Profile every column of the 4 CSVs first and print: distinct date patterns per date column, payer name variants, service-code and modifier variants, exact duplicate rows. Then normalise them with explicit formats and fail loudly on anything unparsed."
- *Verify yourself:*
  - Read the profile output. Decide for yourself whether `03/04/2026` style dates are month-first: is there a slash date whose first field is > 12?
  - Count the payer spellings and exact duplicate rows.
  - Open 3 normalised rows next to the raw rows.
- *Tests:* behaviour, not pinned counts. Both date formats parse to the same day; payer variants map to 3 ids; trailing-space codes normalise; dedupe removes only fully identical rows.
- *Done when:* `pytest tests/test_load.py` passes and the profile printout is saved to `out/profile.txt`.

**C2. EVV units with payer rounding (15 min)**
- *Prompt:* "Write evv.py: verified visits only, key patient+service+clock-in date, sum minutes per key, convert to units with the rounding rule from each payer manual."
- *Verify yourself:*
  - Read the three manuals and write the rounding tests **by hand**: 127 min → 8 units (Northwind 8-minute rule: 120+7) and 8 (floor); 128 min → 9 (Northwind) and 8 (floor).
  - An overnight visit counts on its clock-in day.
- *Done when:* tests pass and Poom can say which payer rounds which way, from the manual text.

**C3. Static rules from the documents (20 min)**
- *Prompt:* "Write rules/payers.yaml and rules.py from the payer manuals and bulletins only. Rules are effective-dated on date of service. Each check returns its evidence. Then print, for each check, how many history claims it flags and how many of those were actually denied."
- *Verify yourself:*
  - Any check where flagged claims are not ~100% denied is wrong. Find out why before moving on.
  - Spot-check 2 flagged claims per check by hand.
  - Look at what PY02 weekend T1019 claims did before and after 2026-09-01.
- *Done when:* every documented check has flagged→denied near 100%, with any gap explained in `docs/ai_log.md`.

**C4. Chronological engine + learned precedence (35 min)**
- *Prompt A:* "Write engine.py: one pass over history and to_check together, sorted by submitted_date then claim_id. Track duplicate keys (frequency 1 only; corrected claims are not duplicates), auth balances (only paid claims draw down), and Harbor member-day paid units. History rows update state with their real outcome; to_check rows with the predicted outcome. Record every flag per claim."
- *Prompt B:* "Write learn.py: for claims with 2+ flags that were denied, count which code the payer reported over which other flag, per payer. Accept a DOS cutoff. Print the pairwise table with counts and the resulting order. Write it to proposed/precedence.yaml."
- *Verify yourself:*
  - Run the D02 check **twice**: replaying history alone, and with to_check interleaved. Do all D02s explain themselves with history alone? If not, open one unexplained auth and trace its balance claim by claim. This is the interleave finding; Poom should find it himself.
  - Read the pairwise table: which pairs have ≥3 observations, and which have 0–1?
  - Approve the order into config yourself.
- *Done when:* one command prints flagged→reported agreement per code, and Poom has signed off `rules/payers.yaml` precedence.

**C5. Backtest with time holdout + predictions (25 min)**
- *Prompt:* "Write backtest.py. Fit precedence and contract-rule candidates on DOS up to 2026-08-31 only, score on DOS from 2026-09-01. Report both periods and the full set: false holds (count, $), denial recall and precision, status accuracy, exact accuracy, code accuracy among correctly-denied, accuracy on multi-flag claims, per payer, confusion matrix, bulletin slices. Then write predict.py → out/predictions.csv with header claim_id,status,denial_code."
- *Verify yourself:*
  - Compare holdout and in-sample. If the holdout is much worse, precedence is overfit.
  - List the misses by code. Is anything left besides D99?
  - Open `predictions.csv`: 546 rows; status only `paid`/`denied`; code blank only when paid.
- *Done when:* `out/backtest_report.md` and `out/predictions.csv` exist and the holdout numbers are in the README.

**C6. Haiku action note, Job A (15 min)**
- *Prompt:* "Write explain.py: for each flagged to_check claim, send the claim, all flags with evidence, the action class and the quoted rule text to the model in env CLAUDE_MODEL. Require the JSON schema in the plan. Validate: numbers must match engine evidence, every flag covered, no scheduling or visit-length advice. Cache by input hash, cap calls with --limit, --dry-run uses a template. Log tokens and latency per call."
- *Verify yourself:*
  - Run `--limit 10`.
  - Read all 10 next to the engine evidence.
  - Check one multi-flag claim and one `HOLD_EVV_PENDING` claim closely.
- *Done when:* 10 notes pass the code checks, or failures are logged and understood.

**C7. README and design sketch (10 min)**
- *Done when:* README §5 sections are filled from real output, `docs/design.png` is exported, and a fresh clone runs `python -m claimcheck.backtest` on Windows.

**Core total: 10+20+15+20+35+25+15+10 = 150 min.**

### 3.2 Stretch, in this order

| # | Item | Min | Why this order |
|---|---|---|---|
| S1 | Haiku Job A eval: 30-claim graded sample, blind vs template, cost/latency summary (§4.4) | 20 | Evidence that the AI earns its place (graded) |
| S2 | to_check risk report (§4.3) | 10 | Makes the unseen-claim estimate believable |
| S3 | Haiku Job B remark reader on a 150-claim stratified history sample + agreement table | 20 | Second AI job, measured |
| S4 | Rule-drift view: learned-rule evidence table by DOS month + "alert at N denials" date | 15 | Governance story for amendment 3 |
| S5 | Read-only Streamlit queue over `out/` files (flagged first, note + evidence) | 25 | Nicer demo; the CLI works without it |
| S6 | Bulletin-to-rule drafting: one LLM call per bulletin/manual → rule diff in `proposed/`, quote check, gold check vs hand config, refusal check on Summit §9.5 | 40 | Highest AI ambition, highest risk, last |

### 3.3 Cut order (keeps the 4h cap safe)
- **At 2h00:** if C5 isn't done, run C6 in `--dry-run` (template) mode, finish C5 and C7, skip all stretch, and ship. If C5 is done, start S1.
- **At 3h00:** finish the item in progress, then start nothing new except S2 if it fits in 10 min.
- **At 3h30:** stop building. 30 min for README polish, the design PNG and one demo dry run.
- **Drop order** if anything overruns: S6 → S5 → S4 → S3 → S2 → S1.
- **Never drop:** C0–C5, C7, key hygiene.

### 3.4 Repo layout (`C:\Users\Poom Chansilpa\Desktop\Coding\Resonance_AC\Resonance_AC`)

```
Resonance_AC/
  README.md  CLAUDE.md  requirements.txt  .gitignore  .env.example
  data/                       # synthetic pack, unchanged
  rules/payers.yaml
  proposed/                   # learned or drafted rules awaiting approval
  claimcheck/  load.py evv.py rules.py engine.py learn.py backtest.py predict.py explain.py
  app.py                      # S5 only
  tests/       test_load.py test_evv.py test_rules.py test_engine.py
  out/         profile.txt backtest_report.md predictions.csv notes.jsonl cache/
  docs/        design.md design.png ai_log.md timelog.md
```

### 3.5 Windows commands

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
$env:ANTHROPIC_API_KEY = "<paste key>"     # this session only; or a local .env (git-ignored)
$env:CLAUDE_MODEL = "<Haiku model id from the Anthropic docs>"
pytest -q
python -m claimcheck.learn --cutoff 2026-08-31
python -m claimcheck.backtest
python -m claimcheck.predict                # out\predictions.csv
python -m claimcheck.explain --limit 30     # add --dry-run to skip the API
```

**Secrets**
- The key lives only in `ANTHROPIC_API_KEY`, set in the shell or in a local `.env` loaded by python-dotenv.
- `.env` is in `.gitignore` before the first commit, and only `.env.example` is committed.
- No key in code, logs, `CLAUDE.md` or the session history export.
- `explain.py` exits with a clear message if the key is missing.

**Config shape (illustrative):**

```yaml
PY01:
  rounding: eight_minute
  filing_limit_days:
    - {days: 30, dos_to: 2026-07-31, source: "PY01 manual 6.1", status: documented}
    - {days: 45, dos_from: 2026-08-01, source: "PY01 bulletin 2026-07", status: documented}
  precedence: {order: [...], learned_from: "DOS <= 2026-08-31", approved_by: Poom}
PY03:
  contract_rules:
    - {id: amendment_3_whole_hours, code: D10, check: units_multiple_of_4,
       dos_from: <learned>, status: learned_confirmed, evidence: out/learn_report.md}
```

---

## 4. Evaluation

### 4.1 Time holdout (the headline)
- **Split by DOS:**
  - **fit** on 2026-06-01 → 08-31 (2,499 claims);
  - **score** on 2026-09-01 → 10-20 (1,331 claims).
- **Fitted on the fit months only:** the precedence table and the learned Summit rule.
- **Documented rules:** come from the manuals, so they need no fitting.
- **The report shows four configurations on both periods**, so the reader sees what each learned piece is worth:

| Config | Purpose |
|---|---|
| Documented rules, naive code order (denial_codes.md order), no learned rule | Floor: no tuning at all |
| + learned Summit rule (fit months) | Value of the learned rule out of time |
| + learned precedence (fit months) | **Honest headline for unseen claims** |
| Precedence refit on all history | In-sample upper reference; used for the final predictions.csv |

- **Learned rule out of time.** The report prints PY03 non-hourly claims by DOS month in both periods (amendment denials, other denials, paid), and the effective date the miner found from the fit months only.
- **Ceiling.** Opaque D99s in each period cap exact accuracy. The report prints that ceiling next to every accuracy number.

### 4.2 Metrics (both periods, all history, per payer)
- **Billing:**
  - false holds (count, $);
  - denial recall and precision;
  - action-class accuracy on flagged claims.
- **Prediction:**
  - status accuracy;
  - exact status+code;
  - code accuracy among claims both actually and predictedly denied;
  - accuracy on multi-flag claims;
  - confusion matrix incl. PAID.
- **Slices:**
  - PY01 DOS before/after 2026-08-01;
  - PY02 T1019 pre-Sep / Sep+ weekday / Sep+ weekend;
  - PY03 June vs July+.
- **Ablations:** each bulletin and the learned rule switched off, with history flips and how many flips match actuals.

**Non-circular tests (M3).**
- Unit tests come from manual text with hand-made claims, not from earlier scripts' counts.
- The data-level check is "claims a documented rule flags are denied by the payer", which is the payer's own record, not our earlier code.

### 4.3 What the backtest can't see about to_check, and how each is handled

| Risk | How it's handled or reported |
|---|---|
| **Auth balances cross both files.** to_check submitted dates overlap history, so some history D02s only make sense once to_check claims draw down first. | The engine interleaves both files. The report counts to_check D02 predictions that depend on an earlier *predicted-paid* to_check claim. These are shown as lower confidence. |
| **History leakage.** History outcomes after a to_check claim partly reveal whether it paid. | State uses actual history outcomes (as in production). Sensitivity run: replay with *simulated* history outcomes and count how many to_check predictions change. |
| **D99 ceiling.** Opaque D99s are never predicted. | The report states the expected miss rate from the holdout D99 share. `predictions.csv` never contains D99. |
| **Tie order.** Many claims share an auth and a submitted date. | Tie-break by claim_id, stated as an assumption. Sensitivity run with the tie order reversed. The report prints how many predictions change. |
| **Unseen or thin precedence pairs.** | The report lists every to_check claim whose reported code depends on a pair seen 0–1 times in history. Action class `MANUAL_REVIEW`; status is still predicted. |
| **Corrected claims (frequency 7)** exist only in to_check. | Handled per `billing_basics.md` (never a duplicate, judged on their own dates). Listed separately in the report as untested. |
| **DOS beyond history** (to_check runs to 2026-11-10). | The report counts them. No documented rule changes after 2026-09-01; the Sep–Nov auths cover them. |
| **Duplicates inside to_check.** | Each D05 names the claim it duplicates and where it lives (history or to_check), so the biller knows which to drop. |
| **Submission order is the biller's choice** (m2). | Stated assumption: "file submitted_date = submission order". The report counts history D02s lost to a later-DOS claim submitted earlier, which supports the README advice "bill in DOS order". |

**Confidence statement for `predictions.csv`** (wording for the README):
- Status should be about as accurate as the holdout status number, and it is robust to precedence choices.
- Codes are fragile on multi-flag claims, especially the thin-pair list.
- 98% is an in-sample figure with a ceiling, never the expected score.

### 4.4 Evaluating Haiku (does the AI earn its place?)
- **Job A, graded sample (S1).** 30 flagged to_check claims, stratified: 10 single-flag, 15 multi-flag, 5 hold/visit cases.
  - For each, Poom sees the Haiku note and the template note in random order (blind A/B).
  - He grades both on 4 yes/no items:
    1. the reported code is explained correctly;
    2. every flag is covered;
    3. the fix steps are correct and in a workable order;
    4. it is actionable without the manual, with no upcoding nudge.
  - Report: pass rate per item for each version, the A/B preference count, and examples of the best and worst notes.
  - If Haiku doesn't beat the template, say so and ship the template. That is a valid finding.
- **Fix correctness, automatic, on all calls:** schema-valid %, numeric-consistency failures, missing-flag failures and banned-advice failures. All are logged in `out/notes.jsonl`.
- **Job B, remark reader (S3).** 150 history denials, stratified by remark string and payer. Haiku has no lookup table.
  - Agreement between the code its reading implies and the reported code.
  - A list of disagreements, read by Poom: are they Haiku errors or payer coding noise?
- **Cost and latency:** input/output tokens and wall time per call from the API response. Report median and p95, plus $ per claim using the price on Anthropic's pricing page on the day (not hard-coded).
- Estimated scale: about 170 Job A calls (flagged to_check) + 150 Job B calls. All cached, so the demo makes no live calls unless chosen.

### 4.5 predictions.csv format
- Header exactly `claim_id,status,denial_code`, with 546 rows in input order.
- `status` is lowercase `paid` or `denied`, as in history.
- `denial_code` is one of `D01`–`D10` (zero-padded as in history), or empty when paid. Never more than one code. Never `D99`.

---

## 5. README contents
1. What it does (3 lines), who it's for, and the action classes.
2. Results:
   - holdout table (4 configs × 2 periods);
   - billing KPIs;
   - D99 ceiling;
   - the confidence statement from §4.3.
3. How to run (Windows PowerShell and bash), `--dry-run` first.
4. API key handling (environment variable only, `.env` ignored); model id via `CLAUDE_MODEL`.
5. Design: sketch, rules vs AI table, what Haiku does and its graded result, human gates, rule owner.
6. Assumptions, one line each:
   - month-first slash dates;
   - submitted_date = submission order, ties by claim_id;
   - precedence learned from fit months, thin pairs listed;
   - Summit rule applied payer-wide from the learned date;
   - D99 not predicted;
   - export duplicate rows dropped;
   - corrected claims per billing_basics.
7. Data quirks found (from `out/profile.txt`).
8. How I worked with AI:
   - Claude Code models used;
   - `docs/ai_log.md` highlights (what went wrong, how it was caught);
   - session history / `CLAUDE.md`;
   - **disclosure that planning and profiling were done beforehand with other AI agents**, and what was redone in the build.
9. Next steps and business rollout (§8).
10. Time spent (from `docs/timelog.md`) and Claude Code spend (from `/cost`).

---

## 6. Demo (10 min, four beats, live on real output)

The demo runs from Poom's repo on his laptop. It runs commands live; `out/` and the Haiku cache act as the fallback if the network or a command fails. No beat depends on a live API call.

| Time | Beat | What's on screen |
|---|---|---|
| 0:00–1:30 | **Problem and choice** | The billing coordinator's question. Why rules own prediction and Haiku owns the action note. What's out (D99, auto-submit, UI). One sentence on the payer being near-deterministic, from Poom's own C3 printout. |
| 1:30–3:00 | **Design** | `docs/design.png`: the chronological engine, the learned-rule gate, the two human gates, who owns the rules. |
| 3:00–6:30 | **Live run** | `python -m claimcheck.backtest` live (a few seconds). Then show: holdout table (honest headline), false holds and recall, the misses being D99. Then `predict` → `predictions.csv`. Open two flagged to_check claims with their Haiku notes: one multi-flag, one `HOLD_EVV_PENDING`. Show the graded-sample result (S1) if built. |
| 6:30–8:30 | **How I worked with AI** | `docs/ai_log.md`: 2–3 real entries (what Claude got wrong, how Poom caught it). How the interleave and precedence were found in his own runs. Disclosure of the pre-build agent analysis. |
| 8:30–10:00 | **Next and rollout** | Pilot plan (§8), rule ownership, drift monitor. "Bill in DOS order" advice from the D02 analysis. |

**Drop on the day if short:** the second flagged claim, then the graded-sample slide. Never drop the AI beat.

Lines a payer would read as upcoding are banned: no "schedule longer", no "bill X more". Commercial maths stays out of the 10 minutes and is kept for Q&A only.

---

## 7. Risks and mitigations

| Risk | Mitigation |
|---|---|
| Precedence overfit | Holdout fit on early months; thin pairs → `MANUAL_REVIEW` |
| Learned rule wrong at scale | Human approval, holdout table, "learned" label, never auto-activated |
| Circular tests | Unit tests from manual text; payer outcomes as the oracle |
| LLM writes a wrong fix | Numeric consistency check, template fallback, model never sets status |
| Haiku adds nothing | Blind graded sample; ship the template if it loses, and say so |
| Network or API on demo day | Cache, `--dry-run`, pre-run `out/` |
| Claude Code spend | `/cost` per step; Sonnet default; stop rule at $20 before the core is done |
| Time overrun | §3.3 cut order; hard stop at 3h30 for polish |
| Key leak | Env var only; `.env` ignored before first commit; `git grep` before push |
| Windows quirks | `pathlib`, `encoding="utf-8"`, no shell-specific scripts |

---

## 8. How this lands in an agency (M4)
1. **Shadow pilot, 4 weeks:** 2 agencies × 1 payer. The tool runs on every claim before submission. The biller still submits as usual. Compare predictions with payer outcomes weekly.
2. **Success gate:** false-hold rate and denial recall on live outcomes, at or near holdout levels. The biller rates notes useful on most flagged claims.
3. **Assisted mode:** billers act on `FIX_AND_SUBMIT`, `HOLD_EVV_PENDING` and `DROP_DUPLICATE`. Measure first-pass paid rate, days to cash and rework hours against the pilot baseline.
4. **Owners:**
   - Exchange4Health payer-content team: rule packs, drift alerts, approvals;
   - agency billing lead: queue;
   - Exchange4Health product: the EVV-side holds.
5. **Scale:** more payers (rule packs), then upstream checks at visit approval (pending or rejected visits, units from verified minutes).

---

## 9. Response to critique-v1

T1 and T2 are the two items flagged in the critic's "What I verified" table. B1, M1–M6 and m1–m8 use the critic's numbering.

| # | Point | Verdict | Reason | Where |
|---|---|---|---|---|
| T1 | plan-v1 §4 slip: the history bulletin knock-on is "D02→paid", not "paid→D02" | **Rejected** | Re-run: claim C007353 is paid under the 30-day rule and D02 under the 45-day bulletin (actual: D02). plan-v1 was right: an extra paid claim drains the auth. | Appendix A |
| T2 | No time holdout exists | **Fixed** | Holdout is now the headline (fit Jun–Aug, score Sep–Oct, 4 configs), built in core step C5 | §4.1, §3.1 C5 |
| B1 | Candidate doesn't own the AI story; findings pre-made; failures scripted | **Fixed** | Plan is now prompts + "verify yourself"; findings are rediscovered in Poom's scripts; numbers moved to a labelled appendix; no scripted failure; agent analysis disclosed | §0, §3.1, §5 item 8, §6 |
| M1 | Scope fills the time box, no contingency | **Fixed** | Core 150 min; stretch separate and ordered; cut points at 2h/3h/3h30; time log | §3 |
| M2 | AI ornamental; "per-claim only" misread | **Fixed** | Haiku now has two measured jobs (multi-rule action note, remark reader) with blind grading vs template and cost/latency. The guide only says per-claim is cheaper, so bulletin drafting returns as stretch S6. | §2.3, §4.4, §3.2 |
| M3 | Eval in-sample; circular tests; silent on to_check | **Fixed** | Holdout, ceiling, robust status vs fragile code, non-circular tests, to_check risk table with a handling for each | §4 |
| M4 | Success is a leaderboard metric; no rollout | **Fixed** | Billing KPIs lead; pilot plan with gates and owners | §1.4, §8 |
| M5 | Nobody owns the rule config | **Fixed** | Exchange4Health payer-content team owns the rule packs; `proposed/` → backtest delta → approval; drift monitor for unannounced changes | §2.5, §2.6 |
| M6 | Ideas overclaim (38% opener, "schedule 2h", 64/64) | **Fixed** | No opener stat built on owner attribution; no visit-length or scheduling advice anywhere (code-checked); 64/64 gone | §6, §2.3, §10 |
| m1 | Pending EVV is a hold, not a denial | **Fixed** | Action classes `HOLD_EVV_PENDING` / `FIX_VISIT` | §2.1 |
| m2 | Drawdown assumes file order | **Fixed** | One-line assumption + evidence for "bill in DOS order" + tie-order sensitivity run | §4.3 |
| m3 | to_check-internal duplicates need a named claim | **Fixed** | `DROP_DUPLICATE` names the earlier claim and its file | §2.1, §4.3 |
| m4 | Too many demo beats; run on cached output | **Fixed** | 4 beats; live commands with `out/` and cache as fallback; drop list | §6 |
| m5 | Report must list predictions on unseen pairs | **Fixed** | Thin-pair list in the risk report, routed to `MANUAL_REVIEW` | §4.3 |
| m6 | Commercial maths reads as inflated | **Fixed** | Out of the 10 minutes; Q&A only | §6, §10 |
| m7 | Hidden rule framed as a reveal | **Fixed** | Framed as governance: label noise, approval, payer-wide assumption, holdout | §2.6 |
| m8 | Claude Code spend not budgeted | **Fixed** | `/cost` per step, Sonnet default, a stop rule; spend reported in README. The exact amount can't be predicted from the files. | §3.0, §5 item 10 |

**Count: 16 Fixed, 1 Rejected, 0 Deferred.**

---

## 10. Visionary ideas v2

| Idea | Decision | Where / one-line reason |
|---|---|---|
| 1 Clock-out Guardian (lite) | **Adopted, partly** | Three-state EVV outcome is in core as action classes (§2.1). The units calculator UI is rejected: UI time, and the demo runs on real claims instead. |
| 2 Bulletin-to-Rule Compiler | **Adopted as stretch S6 (last)** | Gold check vs hand config + refusal check on Summit §9.5 + quote check (§3.2). The proposed swap that drops the per-claim Haiku note is rejected: per-claim Haiku is the measured AI core. |
| 3 Rule Drift Monitor (no AI) | **Adopted** | Production design in §2.6. Learning in core (`learn.py`); the drift view is stretch S4. |
| 4 Authorization Runway | **Rejected as a feature** | No schedule data to forecast with. Kept as the "bill in DOS order" README line backed by the D02 evidence (§4.3). |
| 5 Agency Denial Fingerprint | **Rejected** | Off the core job; small cells per agency × code. |
| 6 Certified Clean Claim | **Rejected for the build** | Nothing in the data tests it; Q&A only. |
| 7 Correspondence reader | **Rejected** | No correspondence in the pack to read. |
| Opener "38.2% decided by the EVV record alone" | **Rejected as opener** | True as arithmetic (Appendix A), but it invites the "who decided it?" debate. Kept for Q&A. |
| Commercial appendix | **Rejected for the demo** | Assumption-heavy; Q&A only. |

**Count: 3 adopted (1 partly, 1 as stretch), 4 rejected, plus 2 sub-proposals rejected (opener stat, the compiler-for-explainer swap).**

---

## Appendix A — Pre-build reference values (disclosed; for cross-checking only)

Produced before the build by AI agents' scripts (`profiling/`, `plan/scripts/`). Poom's own run should rediscover these. If his numbers differ, investigate; don't copy.

**Data**
- History: 3,862 rows → 3,830 after dropping 32 exact duplicates; 2,731 paid / 1,099 denied.
- to_check: 546 rows (532 new, 14 corrected).
- Slash dates are month-first: no first field > 12.
- 9 payer spellings → 3 payers.
- 16 distinct remark strings.

**Documented rules**
- Every documented rule's flagged claims were 100% denied.
- PY01 uses the 8-minute rule; PY02 and PY03 round down (floor).

**Holdout** (fit DOS Jun–Aug, score Sep–Oct; `profiling/holdout.py`)

| Config | Fit months exact | **Score months exact** | Score months status |
|---|---|---|---|
| Naive order, no learned rule | 95.36% | 95.12% | 97.75% |
| Naive order + learned Summit rule | 95.92% | 95.64% | 98.42% |
| **Learned precedence (fit months) + Summit rule** | 97.84% | **97.97%** | **98.42%** |
| Precedence refit on all history | 98.00% | 98.20% | 98.42% |

- Score-months ceiling (D99 share): 98.27%.
- Score months: denial precision 99.73%, recall 94.79%; 1 false hold ($38); 20 missed denials, all opaque D99.
- Multi-flag accuracy in score months: 93.2% (learned) vs 40.7% (naive order).

**Summit amendment 3**
- PY03 non-hourly claims:
  - June: 105, with 0 amendment denials (83 paid);
  - Jul–Aug (fit months): 32 → 30 amendment, 2 other denials, 0 paid;
  - Sep–Oct (score months): 20 → 17 amendment, 3 other denials, 0 paid.
- First amendment DOS 2026-07-01. 47 remarks: 35 coded D10, 12 coded D99.
- 11 of 12 agencies hit. AG008 had 6 of 13 non-hourly claims in June and 0 of 61 from July (it complied, so not exempt).
- Drift timing: 5th amendment denial submitted 2026-07-21.

**Northwind bulletin**
- History: 49 prediction changes (45 D03→paid, 3 D03→D05, 1 paid→D02: C007353).
- to_check: 17 changes.
- Exact accuracy 96.84% → 98.07%.

**to_check risks** (`profiling/tocheck_risk.py`)
- Predicted 377 paid / 169 denied.
- 149 claims have DOS after the last history DOS (2026-10-20).
- 29 multi-flag claims; 11 depend on a pair seen 0–1 times in history.
- 4 of 13 D02 predictions depend on earlier predicted-paid to_check claims; 12 history D02s depend on to_check draws.
- Reversed tie order changes 0 predictions.
- Simulated (not actual) history state changes 1 to_check prediction.
- 27 D05s: 20 duplicate a history claim, 7 duplicate another to_check claim.
- 28 D01s: 19 have no EVV row, 5 rejected, 4 pending.
- Corrected claims (14): 12 paid, 1 D10, 1 D02.

**Other**
- 21 of 65 history D02s were lost to a later-DOS claim submitted earlier.
- EVV-decided denials (D01+D09): 420 / 1,099 (38.2%); 128 of the 239 D09s billed exactly ceil(min/15).
