# Plan v1: Resonance take-home, Exchange4Health claims pre-check

Base build plan. Every number below comes from a file in `brief/` or from pandas profiling scripts in `/workspace/resonance-ac/profiling/` (`p1.py`–`p16.py`, `engine.py`, `sim2.py`, `flips.py`). Where the plan relies on an assumption, it says ASSUMPTION.

---

## 0. Data facts (profiled)

**Files and shape**

| File | Rows | Notes |
|---|---|---|
| `claims_history.csv` | 3,862 rows, 17 cols | **32 rows are exact duplicates** (export artefact) → **3,830 unique claims**. Deduped: 2,731 paid / 1,099 denied. Raw: 2,758 / 1,104. |
| `claims_to_check.csv` | 546 rows, 13 cols | 532 new (`frequency_code` 1) + 14 corrected (`7`). All 14 `original_claim_id`s exist in history (originals: 7× D07, 4× D10, 3× D04). |
| `authorizations.csv` | 780 | 390 cover 2026-06-01→08-31, 390 cover 2026-09-01→11-30. Exactly 2 auths per patient+payer+service. Units 8–468, median 128. Each patient has one payer. |
| `evv_visits.csv` | 5,076 | 4,989 verified, 50 rejected, 37 manual_edit_pending. 60–554 min per visit. 191 cross midnight. 8 patient+service+days have >1 visit (none of them is billed). |

**Dates**
- Claims use two formats: ISO `YYYY-MM-DD` and `MM/DD/YYYY`. History: 457 DOS and 423 submitted dates are slash format; to_check: 73 and 63.
- Slash dates are month-first: the first field is never >12; the second is >12 in 262 history DOS. No ambiguity.
- `authorizations.csv` dates are all ISO. EVV is all `YYYY-MM-DD HH:MM`.
- History DOS 2026-06-01→2026-10-20; submitted 2026-06-02→**2027-01-31**. Lag 1–110 days, median 15.
- to_check DOS 2026-08-06→2026-11-10; submitted 2026-08-24→2027-02-17.

**Naming mess**
- Payer: 9 spellings of 3 payers (`PY01`, `NORTHWIND HP`, `Northwind Health Plan`, `PY02`, `Harbor Medicaid Plan`, `Harbor Medicaid`, `PY03`, `SUMMIT CARE`, `Summit Care Partners`). Deduped split: PY01 1,410 / PY02 1,385 / PY03 1,035. to_check: PY01 190 / PY02 199 / PY03 157.
- `service_code` has trailing spaces on 176 history and 34 to_check rows.
- `modifier`: blank on 3,024 history rows; 134 messy variants (`' U1'`, `'u2'`, `'U2 '`…). Modifiers appear only on T1019. Payers accept messy variants once stripped and upper-cased (46 paid PY02 T1019 claims have a messy U2/U3).
- U1 appears on PY01/PY03 T1019 claims. No rule mentions it and it never causes a denial.

**Outcomes (deduped history)**

| Code | Meaning | n | PY01 | PY02 | PY03 |
|---|---|---|---|---|---|
| D09 | Units > EVV-verified time | 239 | ✓ | ✓ | ✓ |
| D03 | Late filing | 218 | ✓ | 0 (no limit) | ✓ |
| D01 | No verified EVV | 181 | ✓ | ✓ | ✓ |
| D06 | Daily max | 79 | 0 | ✓ only | 0 |
| D07 | Auth number missing | 75 | ✓ | ✓ | ✓ |
| D99 | Other / manual review | 73 | ✓ | ✓ | ✓ |
| D08 | Auth invalid for DOS | 70 | ✓ | ✓ | ✓ |
| D02 | Auth balance exceeded | 65 | ✓ | ✓ | ✓ |
| D04 | Modifier | 37 | 0 | ✓ only | 0 |
| D10 | Contract-specific | 35 | 0 | 0 | ✓ only |
| D05 | Duplicate | 27 | ✓ | ✓ | ✓ |

- Remarks: 17 distinct strings. Several codes have 2 wordings (D01, D02, D08). All 70 D08s are DOS outside the auth window, including the 36 that say "Auth/service mismatch". No claim has a patient, service or payer mismatch with its auth.
- D99 (73) = 61 opaque ("Denied - contact payer", "Under review…"), spread evenly across payers, agencies and months (about 2.1% of otherwise-clean claims) + **12 that carry the Summit "amendment 3" remark** (same remark as D10).

**Rules confirmed against history** (each documented rule → 100% of flagged claims denied; every reported code is flagged)

| Rule | Source | Flagged | Denied | Reported as that code |
|---|---|---|---|---|
| D01 no verified visit (patient+service+clock-in date) | all manuals | 181 | 181 | 181 (103 no EVV row, 45 rejected, 33 pending) |
| D09 units > payer-rounded verified minutes | manuals | 260 | 260 | 239 |
| D03 filing limit (PY01 30/45 d, PY03 60 d, PY02 none) | manuals + bulletin | 279 | 279 | 218 |
| D07 blank auth_id | manuals | 84 | 84 | 75 |
| D08 DOS outside auth window | manuals | 80 | 80 | 70 |
| D04 PY02 T1019 modifier (U2; U3 on weekends from DOS 2026-09-01) | Harbor manual + notice | 41 | 41 | 37 |
| D05 duplicate (freq 1, same patient+service+DOS+payer as an earlier submission) | billing_basics | 30 | 30 | 27 |
| D06 PY02 paid units per member per day > 32, in submission order | Harbor manual | 79+1 | 80 | 79 (1 took D02) |
| D02 auth balance, paid claims drawn down in submission order | billing_basics | see below | | 65/65 |

**Payer rounding (minutes → units) is real and payer-specific**
- PY01 (8-minute rule): 581 claims billed the extra unit (remainder ≥ 8 min). 438 paid; **none** got D09.
- PY02 and PY03 (floor): the same pattern (21 claims each) → all 21 PY02 and 21 of 25 PY03 got D09 (the other 4 took D07/D10 first).

**Effective-dated rules, all keyed on date of service**
- PY01 bulletin 2026-07: filing 30 → 45 days for DOS ≥ 2026-08-01.
- PY02 notice 2026-08: weekend T1019 needs U3 (not U2) for DOS ≥ 2026-09-01. History: 25 weekend U3 paid and 3 weekend U2 → D04 after that date; before it, weekend U3 → D04 (2 of 2).
- PY03 unwritten "amendment 3" (whole hours, units % 4 = 0) for DOS ≥ 2026-07-01. See §2.4.

**One code per denial: which code wins.** The docs say only "the payer reports one code". They do not give an order. History has 75 claims with ≥2 static flags. The order is **payer-specific**:

| Payer | Observed precedence (high → low) | Evidence |
|---|---|---|
| PY01 | D01 > D09 > D07/D08 > D02 > D03 > D05 | D01>D03 (11), D09>D03 (19), D07>D03 (5), D08>D03 (4), D09>D07 (3), D09>D08 (6), D02>D03 (7), D03>D05 (1) |
| PY02 | D01 > D09 > D07/D08 > D04 > D06 > D02 | D01>D04 (2), D01>D07 (2), D01>D08 (1), D09>D04 (2), D09>D07 (2), D06>D02 (1); any static flag beats D06 (27 cases) |
| PY03 | D01 > D07/D08 > D10 > D09 > D02 > D03 | D07>D09 (3), D08>D09 (2), D01>D10 (3), D07>D10 (2), D10>D09 (12), D02>D03 (4), D09>D03 (4) |

Pairs never seen together (for example PY03 D10 vs D03, or D05 vs most codes) are ASSUMPTION and marked as such in config.

**Authorization drawdown spans both files.** to_check claims are "not yet submitted", but 540 of 546 have a submitted date before the last history submission (2027-01-31). If you replay history alone, 10 of the 65 D02s cannot be explained. If you interleave to_check claims by submitted date, all 65 are explained. Example: AUTH10768, claim `C011708`: 52 units left − 28 paid (C018009) − 6 − 12 (to_check C020137, C020934, both submitted 2026-09-26) = 6 < 7 → D02. So the engine must run one chronological pass over **both** files. 203 history claims share an auth and a submitted date with another claim; tie-break by `claim_id` (ASSUMPTION; fits history).

**Prototype rule replay** (profiling only, not the app): **3,756 / 3,830 = 98.07% exact** (status + code); **98.38% status accuracy**. All 74 misses are: 61 opaque D99 (we predict paid), 12 amendment-remark D99 (we predict D10), 1 paid claim we call D02. PY01 98.37%, PY02 98.19%, PY03 97.49%. DOS Jun–Aug 98.00%, Sep–Oct 98.20%. Caveat: the precedence was read off this same history, so these numbers are in-sample (see §4).

Prototype to_check output: 377 paid / 169 denied (D01 28, D05 27, D03 26, D09 24, D06 18, D10 17, D02 13, D07 9, D08 5, D04 2). The real build should reproduce this within a few claims.

---

## 1. Problem framing and scope

**User.** An agency billing coordinator, the day before claims go out.

**Job.** For each claim: will it be paid? If not, which single code will the payer report, what is every rule it breaks, and what exact fix makes it payable?

**What good looks like.**
1. ≥ 97% exact status+code on a held-out slice of history.
2. Every denial prediction cites the rule, the source document and the computed numbers (for example "214 verified min → 14 units under Summit floor rounding; billed 15").
3. `predictions.csv` for all 546 claims.
4. A biller can act on the fix without reading a manual.

**In scope**
- Pre-submission check of `claims_to_check.csv` against all three payers' documented rules and bulletins.
- One learned rule (Summit amendment 3), behind human confirmation.
- Backtest on history.
- Plain-English explanation and fix per flagged claim (Haiku).
- A small local UI.

**Out of scope, and why**
- Predicting the 61 opaque D99s. No feature explains them (uniform across payer, agency, month).
- Real EVV app or scheduling integration. Not in the pack; the brief asks for a prototype.
- Auto-submitting or auto-correcting claims. Money moves; a human signs off.
- Payment amounts and partial pays. Every paid claim in history is paid in full (paid_amount = billed_amount for 100%).
- Multi-visit-day summing beyond the simple sum. It is implemented, but untested: no billed claim hits one of the 8 multi-visit days.
- LLM-drafted rules from bulletins. The brief allows Haiku per-claim calls only; there are 2 bulletins, so they are hand-encoded and cited (see §8).

**Why this slice.** History shows the payer is essentially deterministic: 1,038 of 1,099 denials (94.4%) come from computable rules. So the highest-value build is a correct, auditable rules engine that wins on accuracy. The model then adds the part rules do badly: telling a human, in context, what to do.

---

## 2. System design

### 2.1 Components

1. **Loader / normaliser** (`load.py`). Parses both date formats with explicit formats (`%Y-%m-%d`, `%m/%d/%Y`), never `dayfirst` guessing. It also maps the 9 payer spellings to PY01–03, strips and upper-cases service codes and modifiers, drops the 32 exact duplicate history rows, and fails loudly on any unparsed value.
2. **Payer rule config** (`rules/payers.yaml`). Effective-dated rule tables per payer: rounding mode, filing limit by DOS window, modifier requirement by DOS window and weekday, daily max, contract rules, precedence list. Every entry carries `source` (file + section), `effective_from`, `effective_to`, `status` (`documented` | `learned_confirmed` | `assumption`).
3. **EVV matcher** (`evv.py`). Keeps verified visits only. Key = patient_id + service_code + clock-in date (a visit belongs to its clock-in date, even past midnight). Sums minutes per key, then converts to units with the payer's rounding.
4. **Static checks** (`rules.py`). Pure functions, claim + context → set of flags with evidence: D01, D03, D04, D07, D08, D09, D10.
5. **Sequential engine** (`engine.py`). One pass over history ∪ to_check sorted by (submitted_date, claim_id). It holds state for duplicate keys (D05), auth balances (D02) and PY02 daily paid units (D06). Then it picks the winning code with the payer's precedence list. State updates only on paid claims: actual outcome for history rows, predicted outcome for to_check rows.
6. **Remark miner** (`mine_remarks.py`, deterministic pandas). Groups history denials by remark × payer × DOS month × unit pattern. Prints support/precision for candidate rules. A human promotes a candidate into config.
7. **Explainer** (`explain.py`, Claude Haiku, one call per flagged claim). Covered in §2.3.
8. **Backtest + predict** (`backtest.py`, `predict.py`). Metrics report, confusion matrix, slices, `out/predictions.csv`.
9. **UI** (`app.py`, Streamlit). Work queue of to_check claims (denied/at-risk first), claim detail with evidence + explanation, backtest page, rule config page with on/off toggles per dated rule, and a minutes→units calculator.

### 2.2 Rules vs AI

| Concern | Owner | Why |
|---|---|---|
| Date parsing, lag, effective dates | Rules | Exact arithmetic; one wrong date flips D03 |
| Minutes → units, payer rounding | Rules | 581 PY01 claims hinge on the 8-minute rule |
| EVV matching, overnight, verified status | Rules | Join + filter |
| Auth validity, drawdown order, daily max | Rules | Stateful, order-dependent; LLMs can't do this reliably per claim |
| Duplicates | Rules | Key lookup over prior submissions |
| Which code wins | Rules (precedence table) | Learned once from history, auditable |
| Status and code in `predictions.csv` | **Rules only** | The model never changes the prediction |
| Explaining all broken rules + ordered fix list in billing language | **Haiku** | Payer reports one code, but 75 history claims break ≥2 rules. A biller who fixes only the reported one gets denied again. The model turns the full flag set + evidence into one coherent instruction ("Cut units 15→14 AND add auth AUTH12466, then resubmit as frequency 7 referencing C0xxxxx") |
| Opaque or unexpected remarks on returned denials | Haiku (stretch) | Free-text triage; routes to human |
| New rule from data | Rules propose, human approves | A wrong learned rule blocks payable claims |

**Haiku guardrails**
- Input: structured JSON (claim, flags, computed numbers, winning code, the exact quoted rule text from the manual/bulletin).
- Output: JSON schema `{summary, fixes:[{action, field, from, to}], resubmit_as, confidence_note}`.
- Validate: every `field/from/to` must match a rule-computed value, or the output is discarded and a template explanation is used.
- Temperature 0. Responses cached on disk by claim hash. Hard cap on calls per run (default 200).
- `--dry-run` runs everything with templates and no key.
- Model id from env `CLAUDE_MODEL` (Haiku tier, per the setup guide). Not hard-coded.

**Justification experiment (cheap).** Run Haiku alone on 100 history claims with the manuals in the prompt, asked to predict status+code. Compare with the rules. This shows on screen why computation stays in code. It runs once and its results are cached.

### 2.3 Human in the loop
- **Biller** reviews every predicted denial and every "at risk" claim (auth balance after this claim < 10% or within 2 days of a filing deadline), then accepts or edits the fix. Nothing is submitted by the tool.
- **Rule owner** approves any config change: new bulletin, learned rule, precedence change. Approval needs a backtest delta report: how many history predictions flip, and how many of those flips match actual outcomes.
- **D99 / unexplained** → manual review queue. These are never auto-labelled.

### 2.4 Learned rule: Summit "amendment 3"
- Not in any document. Summit manual §9.5 only says "additional billing requirements may apply under your agency's contract".
- Remarks: 47 deduped claims (48 raw) say "Contract amendment 3: services must be billed in whole hours" or "Units not billable per amendment 3 (hourly increments)". 35 are coded D10, **12 coded D99** (inconsistent payer coding).
- PY03 claims with units % 4 ≠ 0, by DOS month:

| DOS month | Non-hourly PY03 claims | Amendment denials | Other code first | Paid |
|---|---|---|---|---|
| 2026-06 | 105 | 0 | 22 | 83 |
| 2026-07 | 16 | 15 (11 D10, 4 D99) | 1 (D01) | 0 |
| 2026-08 | 16 | 15 (10 D10, 5 D99) | 1 (D07) | 0 |
| 2026-09 | 14 | 12 (10 D10, 2 D99) | 2 (D01, D07) | 0 |
| 2026-10 | 6 | 5 (4 D10, 1 D99) | 1 (D01) | 0 |

- Every non-hourly PY03 claim with DOS ≥ 2026-07-01 is denied (52/52; 47 amendment, 5 took D01/D07 first). Hourly-unit PY03 claims after July pay normally. Split by **DOS**, not submitted date: June-DOS claims submitted in July still paid. 11 of 12 agencies hit (not AG008), so it is applied payer-wide (ASSUMPTION: the "agency contract" is the same for all 12).
- Handling: the miner surfaces it with support and precision. Config holds `D10_whole_hours {payer: PY03, effective_from: 2026-07-01, status: learned_confirmed, confirmed_by: <name>, evidence: backtest}`. The UI labels it "learned from denials, not from a document". Predicted code is D10 (35 of 47 historical labels). The 12 D99-coded ones are counted as known label noise in the report.
- Value: without the rule, history exact accuracy drops 98.07% → 97.15% (47 predictions change). In to_check, 17 claims are predicted D10 because of it (18 have non-hourly units; 1 takes D07).

### 2.5 Design sketch

```mermaid
flowchart LR
  subgraph Inputs
    CH[claims_history.csv]
    CC[claims_to_check.csv]
    AU[authorizations.csv]
    EV[evv_visits.csv]
    DOC[manuals + bulletins + denial_codes.md]
  end
  CH & CC & AU & EV --> N[Loader / normaliser<br/>dates, payer names, codes, dedupe]
  DOC -->|hand-encoded, cited| CFG[(rules/payers.yaml<br/>effective-dated, per payer,<br/>precedence lists)]
  CH --> MINE[Remark miner<br/>candidate rules + support]
  MINE -->|candidate| HUM1{{Rule owner approves<br/>after backtest delta}}
  HUM1 --> CFG
  N --> EVM[EVV matcher<br/>verified minutes → units<br/>payer rounding]
  N --> ST[Static checks<br/>D01 D03 D04 D07 D08 D09 D10]
  EVM --> ST
  CFG --> ST
  ST --> SEQ[Chronological engine<br/>history ∪ to_check by submitted_date<br/>D05 dup, D02 auth drawdown, D06 daily max<br/>payer precedence → one code]
  CFG --> SEQ
  SEQ --> PRED[predictions.csv<br/>claim_id,status,denial_code]
  SEQ --> BT[Backtest report<br/>accuracy, confusion, slices]
  SEQ -->|flags + evidence + rule text| LLM[Claude Haiku<br/>per flagged claim<br/>explanation + fix list<br/>schema-validated]
  LLM --> UI[Streamlit work queue]
  SEQ --> UI
  UI --> HUM2{{Biller reviews,<br/>edits, submits outside tool}}
  BT --> UI
```

Deliverable: this mermaid in `docs/design.md`, rendered to `docs/design.png` (mermaid.live export) and linked from the README. A hand photo is fine too.

---

## 3. Build steps (≈3h30 with Claude Code)

Each step ends in a check you can run. Commands are given for PowerShell; bash equivalents are obvious.

| # | Step | Time | Done when |
|---|---|---|---|
| 0 | Repo setup: venv, `requirements.txt` (pandas, pyyaml, streamlit, anthropic, python-dotenv, pytest), `.gitignore` with `.env`, `.env.example`, `CLAUDE.md` with these rules, copy `brief/data` → `data/` | 15 m | `git status` shows no `.env`; `python -c "import pandas"` works |
| 1 | `load.py` normaliser + `tests/test_load.py` | 20 m | Tests assert: 3,830 history claims after dedupe; 546 to_check; 3 payers; 0 unparsed dates; 457 slash DOS parsed month-first; service codes ∈ {T1005, T1019, S5125} |
| 2 | `evv.py` + per-payer rounding | 15 m | Unit tests: 127 min → 8 (PY01), 8 (PY02/03); 128 min → 9 (PY01), 8 (floor); overnight visit belongs to clock-in date |
| 3 | `rules/payers.yaml` + `rules.py` static checks | 25 m | On history: each flag → 100% denied (table in §0 reproduced: D01 181, D09 260, D03 279, D07 84, D08 80, D04 41) |
| 4 | `engine.py` chronological pass (D05, D02, D06) + precedence | 30 m | History exact ≈ 98.1%, D02 65/65, D06 79/79, D05 27/27; misses = 61 + 12 + ≈1 |
| 5 | `backtest.py` report + temporal holdout | 20 m | `out/backtest_report.md` with all §4 metrics; holdout numbers printed |
| 6 | `predict.py` → `out/predictions.csv` | 5 m | 546 rows, header exactly `claim_id,status,denial_code`, statuses ∈ {paid, denied}, code blank iff paid |
| 7 | `mine_remarks.py` | 15 m | Prints the §2.4 month table; amendment rule shows support 47, precision 47/47 on non-hourly PY03 DOS ≥ Jul 1 that took no other code |
| 8 | `explain.py` (Haiku) + cache + dry-run + 100-claim LLM-only baseline | 25 m | 10 sample explanations pass schema validation; `--dry-run` works with no key; baseline accuracy recorded |
| 9 | `app.py` Streamlit: queue, detail, backtest, rule toggles, units calculator | 25 m | `streamlit run app.py` loads; toggling the PY01 bulletin off reruns the backtest and shows the delta |
| 10 | README, `docs/design.md` + PNG, demo rehearsal | 15 m | Fresh clone + README steps run end to end on Windows |

Total: 210 min.

**Repo layout** (`C:\Users\Poom Chansilpa\Desktop\Coding\Resonance_AC\Resonance_AC`)

```
Resonance_AC/
  README.md
  CLAUDE.md
  requirements.txt
  .gitignore            # .env, .venv/, __pycache__/, out/cache/
  .env.example          # ANTHROPIC_API_KEY=  CLAUDE_MODEL=
  data/                 # synthetic pack, unchanged
  rules/payers.yaml
  claimcheck/
    __init__.py
    load.py  evv.py  rules.py  engine.py
    mine_remarks.py  explain.py  backtest.py  predict.py
  app.py
  tests/  test_load.py  test_evv.py  test_rules.py  test_engine.py
  out/    predictions.csv  backtest_report.md  cache/
  docs/   design.md  design.png
```

**Windows commands**

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
$env:ANTHROPIC_API_KEY = "<paste key>"   # this session only; or put it in .env (git-ignored)
pytest -q
python -m claimcheck.backtest
python -m claimcheck.predict              # writes out\predictions.csv
python -m claimcheck.explain --limit 50   # add --dry-run to skip the API
streamlit run app.py
```

**Secrets.** The key lives only in the `ANTHROPIC_API_KEY` environment variable, or in a local `.env` loaded by python-dotenv. `.env` is in `.gitignore` before the first commit. Only `.env.example` with empty values is committed. No key in code, notebooks, logs or `CLAUDE.md`. `explain.py` exits cleanly with a message when the variable is missing.

**Config shape (illustrative)**

```yaml
PY01:
  rounding: eight_minute
  filing_limit_days:
    - {days: 30, dos_to: 2026-07-31, source: "PY01 manual 6.1"}
    - {days: 45, dos_from: 2026-08-01, source: "PY01 bulletin 2026-07"}
  precedence: [D01, D09, D07, D08, D02, D03, D05]
PY03:
  rounding: floor
  filing_limit_days: [{days: 60, source: "PY03 handbook 9.3"}]
  contract_rules:
    - {id: amendment_3_whole_hours, code: D10, check: units_multiple_of_4,
       dos_from: 2026-07-01, status: learned_confirmed, source: "history remarks"}
  precedence: [D01, D07, D08, D10, D09, D02, D03, D05]
```

---

## 4. Evaluation

**Backtest set.** 3,830 deduped history claims. History rows use actual outcomes to update state, and to_check rows use predicted outcomes. This matches production, where earlier outcomes are known.

**Metrics** (all in `out/backtest_report.md`)
- Status accuracy (paid vs denied); precision/recall of "denied".
- Exact accuracy (status + code).
- Denial-code accuracy on actual denials.
- Confusion matrix of true vs predicted code (12×12 incl. PAID).
- Per payer: PY01 / PY02 / PY03.
- Bulletin slices: PY01 DOS < vs ≥ 2026-08-01; PY02 T1019 pre-Sep / Sep+ weekday / Sep+ weekend; PY03 DOS June vs ≥ July.
- Error budget line: opaque D99 (61) + amendment-coded D99 (12) = 73 = ceiling of 98.09% exact for any rules system.

**Honesty controls**
- **Temporal holdout.** Fix precedence and the learned rule from DOS June–August only, then score DOS September–October (1,331 claims).
- **Ablations.** Each dated rule switched off, with the delta shown. Both bulletins are verified below.
- LLM-only baseline on 100 claims (§2.2).

**Bulletin flip counts (verified)**
- PY01 45-day bulletin vs the old 30-day rule. 64 history claims are PY01, DOS ≥ 2026-08-01, filed 31–45 days late. Only 43 were paid; the other 21 were denied for other reasons. So the Visionary's "all 64 paid" is wrong.
  - Prediction changes: **history 49** (45 D03→paid, 3 D03→D05, 1 paid→D02 via drawdown knock-on); **to_check 17** (10 D03→paid, 6 D03→D05, 1 paid→D02).
  - History actuals for the 49: 43 paid, 3 D05, 1 D02, 2 D99 → 47/49 match the new rule.
  - Exact accuracy 96.84% → 98.07%; status 97.28% → 98.38%.
- PY02 weekend-U3 notice: history 36 changes, to_check 14. Exact 97.18% → 98.07%.

**predictions.csv format** (from data)
- Header exactly `claim_id,status,denial_code`. 546 rows, one per to_check claim, order as in input.
- `status` lowercase `paid` or `denied`, as in history.
- `denial_code` one of `D01`–`D10`, `D99` (zero-padded, as in history and `denial_code.md`). Empty string when paid. Never more than one code.
- We never predict D99 (ASSUMPTION: opaque D99s are unpredictable). This costs about 2% expected accuracy and is stated in the README.

---

## 5. README contents
1. What it does (3 lines) and who it's for.
2. Results table: backtest exact/status accuracy, per payer, holdout, error budget.
3. How to run on Windows/macOS (commands from §3), with `--dry-run` first.
4. API key handling (env var only; `.env` git-ignored).
5. Design: link to `docs/design.png`; rules vs AI table; human-in-the-loop points.
6. Assumptions, each one line:
   - month-first slash dates
   - drawdown interleaves both files and ties break by claim_id
   - precedence learned from history, unseen pairs assumed
   - amendment 3 payer-wide from DOS 2026-07-01
   - D99 not predicted
   - duplicate export rows dropped
   - U1 harmless
7. Data quirks found (§0 list).
8. How I worked with Claude Code: model per task, where it went wrong, how outputs were checked (tests against profiled counts).
9. Next steps (§6 close).
10. Tools used.

---

## 6. Demo story (10 min)

| Time | Beat | Show |
|---|---|---|
| 0:00–1:00 | Problem and choice | "28.7% of these claims were denied (1,099 of 3,830). 94% of denials follow computable rules. So: rules engine for accuracy, AI for the human part." Scope in/out in one breath. |
| 1:00–2:30 | Design | `docs/design.png`. Rules vs Haiku table. Two human gates: biller and rule owner. |
| 2:30–5:30 | Live demo | Streamlit queue for to_check: 169 predicted denials. Open a multi-flag claim; show evidence (minutes, rounding, auth balance) and the Haiku fix list covering every broken rule. Units calculator: 127 min → 8 units Northwind vs Summit, plus the Summit hourly warning. |
| 5:30–7:00 | Proof | Backtest page: 98.1% exact, confusion matrix, per payer, holdout. Toggle the Northwind bulletin off: 49 predictions flip, accuracy drops to 96.8%; toggle on. Show the 73 misses = D99 noise. |
| 7:00–8:15 | Hidden rule | Miner table: June 0/105, July+ 52/52 denied. "In no document. Learned, then confirmed by a human before it goes live." |
| 8:15–9:15 | Working with AI | CLAUDE.md, tests pinned to profiled counts, one place Claude Code got it wrong (for example dayfirst date parsing or drawdown order) and how the test caught it. |
| 9:15–10:00 | Next | Run at clock-out and scheduling (Guardian), auth runway alerts, bulletin intake at 180+ payers, payer-side clean-claim certification. |

---

## 7. Risks and mitigations

| Risk | Mitigation |
|---|---|
| Precedence overfit (small n per pair, in-sample) | Temporal holdout; config marks unseen pairs `assumption`; report lists claims whose code depends on an assumed pair (for example 3 to_check PY03 claims where D10 beats D03) |
| Drawdown depends on to_check outcomes (circular) | Deterministic single pass; report how many to_check D02s depend on earlier predicted-paid to_check claims |
| Same-day tie order on an auth (203 history claims share auth+date) | claim_id tie-break, documented; flag ties that change the outcome |
| Date mis-parse | Explicit formats, fail on unknown, tests on counts |
| LLM hallucinated fix | Schema + value check against rule output; template fallback; the model never sets status |
| API cost / outage | Haiku only, cache, call cap, dry-run |
| Learned rule is wrong at scale | Human approval + backtest delta gate; labelled "learned" in UI |
| Key leak | Env var only, `.env` ignored before first commit, `git grep -i sk-ant` before push |
| Windows path/encoding issues | `pathlib`, `encoding="utf-8"`, no shell-specific scripts |

**Cut list** (cut from the top when time runs short)
1. LLM-only baseline experiment.
2. Units calculator panel.
3. Rule toggles in UI. Keep the ablation numbers in the report.
4. Streamlit app entirely. Fall back to CLI + markdown report + `explain` output printed for 5 claims.
5. Remark miner script. Hard-code the rule with its evidence table pasted into README.
6. Temporal holdout. Keep in-sample metrics, stated as such.

Never cut: normaliser tests, chronological engine, `predictions.csv`, backtest report, README, design sketch, key hygiene.

---

## 8. Visionary ideas (from `plan/ideas-v1.md`)

| Idea | Decision | Where / why |
|---|---|---|
| Effective-dated rule config (Idea 2 prerequisite) | **Adopted** | §2.1 item 2, §3 config. Verified: 3 rules switch on DOS dates (PY01 2026-08-01, PY02 2026-09-01, PY03 2026-07-01); both bulletin ablations improve history accuracy (§4) |
| 1 Clock-out Guardian | **Adopted, lite** | Units calculator in UI + "do not bill until verified" list (87 rejected or pending visits); simulated surface only. Full point-of-care product → demo close |
| 2 Bulletin-to-Rule Compiler | **Partly adopted** | Dated config + toggle + backtest delta + human approval are in. LLM extraction of bulletins rejected: brief limits Haiku to per-claim calls and 2 bulletins are faster hand-encoded |
| 3 Hidden-Rule Detective | **Adopted, deterministic** | §2.4 + `mine_remarks.py`; LLM hypothesis call rejected (not per-claim); human confirmation kept |
| 4 Authorization Runway | **Adopted, minimal** | "At risk" flag in queue (balance after claim); forecasting rejected: no schedule data |
| 5 Agency Denial Fingerprint | **Rejected** | Off the core job; small cells (some codes 0–3 per agency); time |
| 6 Certified Clean Claim | **Rejected for build** | Narrative only in demo close; nothing in data to test it |
| Commercial / scale maths | **Rejected for build** | Assumption-heavy; keep for discussion if asked |

**Visionary claims checked**
- "64 Northwind claims flip, all paid": refuted in detail. 64 are in the window, 43 paid; 49 history predictions change (47 match actuals), 17 to_check change.
- "No patient has two visits for one service on one day": refuted. 8 such patient+service+days exist (none billed).
- Amendment counts 36 D10 / 12 D99 / 48 total are raw rows; deduped 35 / 12 / 47. June 106 → deduped 105.
- Weekend U3 (25 paid, 3 U2 → D04) and D01 split (104/45/33 raw; 103/45/33 deduped): confirmed.
