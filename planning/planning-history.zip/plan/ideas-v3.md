# Ideas v3 (final): one demo, a coordinator screen, AI proven in core

*Numbers: `plan/scripts/ideas_v3_stats.py` (Part A reads `brief/data/` CSVs directly, with history deduped from 3,862 rows to 3,830 claims. Part B sizes the coordinator queue from the pre-build prototype engine's to_check predictions in `profiling/run_v1_1.pkl`). `plan/scripts/ideas_v2_stats.py` still reproduces the v2 figures. Figures from plan-v2 Appendix A or critique-v2 are marked [plan-v2] / [critique-v2]. **Every number here is a pre-build reference value produced by AI agents and disclosed as such.** Poom's own build must reproduce it, not quote it.*

---

## 0. Response to critique-v2

All points that touch the ideas are listed. Points that are plan-only are listed last for completeness.

| # | Critique point (paraphrased) | Verdict | Change in v3 |
|---|---|---|---|
| §2 / m3 | Summit holdout wording: "held on 17 of 20" flatters. Say "20/20 denied, 14 coded D10". | **Accepted. Verified from the CSVs** (§1). | The Summit Sep–Oct line is now **"20 of 20 denied, 14 of them coded D10"** (plus 3 D99 carrying the amendment remark, 2 D01, 1 D07). Every other Summit figure has been restated on the same deduped definition (§1 table): v1's "48/53" was raw rows, and deduped it is 47 amendment remarks among 52 non-hourly claims from July onwards, all 52 denied. |
| m6 / §1 | ideas-v2 quoted "AG008: 0 of 73" (the critic's own v1 error). It's 0 of 61 in history. | **Accepted. Verified.** | AG008 Summit: June **6 of 13** non-hourly, July onwards **0 of 61**. |
| m5 | "AG008 complied, so not exempt" is an inference, and it's the only support for predicting D10 on **C020368**. | **Accepted.** | The coordinator queue tags C020368 "rests on payer-wide ASSUMPTION" and routes it to `MANUAL_REVIEW` with the status still predicted (§3). The ideas now say "consistent with payer-wide", never "proves". |
| §1 Haiku guidance | The guide gives advice on model choice *if* you call per claim. It neither restricts nor recommends per-claim calls. | **Accepted.** ideas-v2 said "cheaper, not only allowed", which is consistent. | No change needed. I use the critic's exact reading in §4. |
| M1 | "Found it himself" contradicts the disclosure. | **Accepted for the ideas' wording too.** ideas-v2 B1 said the candidate "can say without notes", which is fine, but the demo lines must not claim discovery. | Demo script (§2) and idea text say **"the pre-build analysis flagged X. I reproduced it in my own run (ai_log entry N)."** Discovery credit only goes to things that emerge during the build. The compiler's gold-check result *is* new build output, so it can be claimed. |
| M2 | C4 is underestimated (6 deliverables in 35 min). The holdout headline mustn't be what pays for it. | **Accepted. Budgeted.** | The budget (§5) gives C4 **+10 min (35 → 45)** before adding anything of mine. The ideas' additions sit *after* C5, so an engine overrun hits them, not the holdout. |
| M3 | AI is relabelled, not fixed. Job A's ordering and fix interactions are computable, so what's left is wording. Job B is redundant (16 strings). The only real AI evidence (S6 compiler) is in stretch, last. | **Accepted, and the critic's own logic drives the fix.** | (a) **Bulletin-to-rule compiler moves into core** as a slim version: 1 real bulletin + 1 refusal document, gold diff against a hand-written rule committed *before* the LLM runs, then the backtest delta (§4). (b) The "fix interactions" job moves to **rules**: a `recheck` command reruns the engine on the edited claim (§3). That's the non-AI baseline the critic named, and it's better than an LLM at it. (c) **Haiku Job A leaves core** (template notes in core, graded Haiku notes as stretch S1). Job B is dropped. Net: one AI job in core, judged against a gold standard a sceptic can inspect, plus a stated limit: *in this pack the AI can at best match the hand-written rule. Its value is speed at 180+ payers, which this pack can't measure.* |
| M4 | Plan and ideas describe two demos (opener, calculator, hidden-rule slot, compiler). | **Accepted. I adopt plan-v2's demo** (5 beats, same order, names and times) and slot the ideas inside it (§2). | Opener: plan wins. 38.2% is Q&A only. Units calculator: dropped; real claims in the queue show units evidence instead. Hidden-rule beat: gone; Summit appears as a queue row and one line in "Next". Compiler: shown inside the plan's Live-run beat, from core output. |
| M5 | The core demo shows nothing a billing coordinator would touch. | **Accepted. This is the main new spec.** | Core adds `out/queue.html` (a static work queue: reason, fix action, $ at stake, filing deadline, sorted by actionability → deadline → $) and `recheck` (edit one field, rerun the engine, see the new verdict). **25 min.** What the coordinator clicks in the demo is in §2 and §3. |
| m1 | "Action-class accuracy" has no ground truth. | **Accepted.** ideas-v2's three EVV states are rules, not predictions. | Action class is a deterministic mapping from (code, EVV status, flags), **tested by unit tests, not scored**. Drop the accuracy metric. |
| m2 | The to_check risk report (S2) is stretch, but README claims rely on it. | **Partly accepted for the ideas.** | The queue needs the thin-pair list to set `MANUAL_REVIEW` (11 claims [critique-v2]). So the thin-pair list comes into core with the queue (counted in its 15 min). The rest of S2 stays stretch. That's the Architect's call. |
| m4 | The holdout hard-codes `d10_from='2026-07-01'`. | **Accepted. Relevant to Drift Monitor.** | The drift idea now says the learned date must come from fit-month data: the first DOS month in which non-hourly PY03 claims carry the amendment remark and none are paid. On fit months alone that's July (Jul–Aug: 32 non-hourly, 0 paid, 30 remarks; June: 105, 83 paid, 0 remarks). |
| m7 | plan §2.3 says the guide "recommends" per-claim calls. | Plan-only wording. | None from me. It's in the Architect's list for consistency (§6, item 7). |
| §1 T1 | C007353 knock-on: plan-v1 "1 paid→D02" was right. | Plan-only; no ideas claim depends on it. | None. The ideas quote 49 history flips, 47 matching, which already includes it. |
| §2 / §3 other | Other spot-checks reproduce, B1 mostly fixed, the rest fixed. | Noted. | None. |

---

## 1. Summit (PY03) amendment 3, verified numbers

Definition: deduped `claims_history.csv`, payer normalised to PY03, **non-hourly = units % 4 ≠ 0**, windows by date of service. "Amendment remark" = remark contains "amendment 3".

| DOS window | Non-hourly claims | Denied | Paid | Codes | With amendment remark |
|---|---|---|---|---|---|
| June | 105 | 22 | 83 | 8 D09, 5 D03, 4 D01, 2 D99, 2 D08, 1 D02 | 0 |
| Jul–Aug (fit) | 32 | **32** | 0 | 21 D10, 9 D99, 1 D01, 1 D07 | 30 (21 D10 + 9 D99) |
| **Sep–Oct (holdout)** | **20** | **20** | **0** | **14 D10**, 3 D99, 2 D01, 1 D07 | 17 (14 D10 + 3 D99) |
| Jul–Oct total | 52 | 52 | 0 | 35 D10, 12 D99, 3 D01, 2 D07 | 47 (35 D10 + 12 D99) |

- **Headline line: "Sep–Oct: 20 of 20 non-hourly Summit claims denied, 14 of them coded D10."** The rule's status call is 20/20. Its code call (we predict D10) is right on 14/20. 3 are the same remark coded D99 (payer label noise), and 3 lost to D01/D07 under one-code-per-denial.
- No amendment remark appears on an hourly claim (0). Amendment DOS range is 2026-07-01 → 2026-10-15.
- AG008: June 6 of 13 non-hourly → July onwards 0 of 61. That's *consistent with* a payer-wide rule. It doesn't prove it.
- to_check: 18 non-hourly Summit claims with DOS ≥ July. One is AG008's **C020368**, which gets the assumption tag.
- Superseded figures: v1 "36 D10 / 12 D99 / 48", "48 of 53" and "106 June" were raw rows. v2 "17/20 held" is replaced by the line above.

---

## 2. The one demo (plan-v2 §6 structure, ideas slotted in)

Same 5 beats, order, names and times as plan-v2. Changes are marked **[Δn]** and listed in §6. Everything runs on core output. Live commands use `out/` and the cache as fallback, and no beat needs a live API call.

| Time | Beat (plan-v2 name) | What happens on screen | Built in |
|---|---|---|---|
| 0:00–1:30 | **Problem and choice** | The coordinator's question: "which of tomorrow's claims will bounce, and what do I do about each?" Rules own prediction. **[Δ1] AI owns reading payer documents into *proposed* rules, which a human approves.** Out of scope: D99, auto-submit. The near-deterministic payer, from Poom's own C3 printout. *(No 38.2% opener. It's Q&A only.)* | C3 |
| 1:30–3:00 | **Design** | `docs/design.png`: engine, learned-rule gate, **bulletin → `proposed/` → analyst approval [Δ1]**, two human gates, rule owner (payer-content team). | C7 |
| 3:00–3:45 | **Live run: proof** | `python -m claimcheck.backtest` live. Holdout table: exact on unseen months vs the D99 ceiling (reference values 97.97% vs 98.27%, false holds 1 ($38), misses all D99 [plan-v2]. His run must reproduce them). | C5 |
| 3:45–5:15 | **Live run: the coordinator's queue [Δ2]** | Open `out/queue.html`. Header: flagged / total and $ at stake (prototype reference: **169 of 546, $17,787.30**). **Click C019757** (Summit T1019, 34 units, $207.40). The card shows: payer will print **D10**, but it also breaks **D09**. Verified visit 483 min → **32 units** under Summit floor rounding. Fix: **units 34 → 32**, which is the verified time and clears both rules. Run `recheck C019757 --set units=32` live: the new verdict is SUBMIT if the auth balance allows (*expected; confirm in build*). Then point to **C020752**: `HOLD_EVV_PENDING`, "wait for the aggregator, don't rework" ($108). One glance at C020368's assumption tag. | new core C8 |
| 5:15–6:30 | **Live run: keeping rules current [Δ3]** | Northwind bulletin 2026-07 (5 lines of prose) → cached LLM output in `proposed/`: JSON rule with a verbatim source quote → **diff against the hand-written rule** (committed earlier, git timestamp shown): match or mismatch, told truthfully. → Summit §9.5 → **`no_actionable_rule`**. → Approve → backtest delta: **49 history predictions change, 47 match actual outcomes; 17 to_check predictions change** [plan-v2]. | new core C6′ |
| 6:30–8:30 | **How I worked with AI** | Plan-v2 content: `docs/ai_log.md`, 2–3 real entries. **[Δ4] Wording: "the pre-build analysis flagged the interleave and the precedence; I reproduced and checked them in my run".** The compiler gold check is genuine build output. Disclosure of the pre-build agents. | C0–C7 |
| 8:30–10:00 | **Next and rollout** | Plan-v2 pilot (§8), rule owner, **drift monitor** with one line: "Summit's whole-hours change, learned from Jul–Aug, held on Sep–Oct: 20 of 20 denied, 14 coded D10", and "bill in DOS order" (21 of 65 D02s lost to a later-DOS claim submitted earlier). Upstream EVV checks at visit approval. | README |

**Swap rules (if stretch exists):**
- If **S1** (graded Haiku notes) is built, show the A/B result for 20 s at the end of the queue segment, taken from the C020752 glance.
- If **S5** (Streamlit) is built, it replaces `queue.html` with the same content and clicks.
- If the compiler **fails** its gold check, show the failure and what caught it. That's the "how I checked the AI" story.

**Drop on the day, in order:** the live `recheck` (read the fix off the card instead) → the C020752 glance → the Summit §9.5 refusal step. Never drop the compiler diff or the holdout table.

**Banned lines (unchanged):** no "schedule longer", no "bill more". In C019757 the fix *lowers* units to verified time, and the card never suggests going up to 36 to reach an hourly boundary.

---

## 3. Coordinator surface in core (spec, not code)

**`out/queue.html`**: one static file written by `predict.py`. No server, opens in a browser.
- **Row:** claim_id · payer · service · DOS · units · **$ billed (at stake)** · predicted verdict/code · **action class** · **one-line reason** ("483 verified min = 32 units; billed 34") · **fix action** ("units 34→32") · **filing deadline** (DOS + payer limit; Harbor: none) · tags (`learned rule`, `assumption`, `thin precedence`).
- **Order:** (1) actionable now: `FIX_AND_SUBMIT`, `FIX_VISIT`, `DROP_DUPLICATE`, `MANUAL_REVIEW`. (2) Waiting: `HOLD_EVV_PENDING`. (3) Deadline missed: `WRITE_OFF_OR_SUBMIT_BY`. (4) `SUBMIT`. Within each: filing deadline ascending, then $ descending.
- **Click a row** → claim card: every flag with evidence (minutes, rounding, auth balance before/after, lag vs limit), the code the payer will print, the source rule quote, and the template note (Haiku note if S1 exists).
- **Prototype sizing** (reference, Part B): 169 flagged of 546, **$17,787.30 of $54,064.80** at stake. Fix-and-submit 35 ($3,342.30), daily cap 18 ($2,826.80), duplicates 27 ($2,572.10), late filing 26 ($2,466.10), no visit record 19 ($2,037.00), learned-rule fix 17 ($1,606.00), auth shortfall 13 ($1,306.20), auth window 5 ($632.40), hold-pending 4 ($500.40), fix-visit 5 ($498.00). 29 flagged claims break 2+ rules.

**`python -m claimcheck.recheck <claim_id> --set field=value`**: copies the claim, applies the edit, reruns the same chronological engine, and prints old vs new verdict and every flag. This answers critique M3: combined fixes and interactions (cutting units changes D02/D06) are **computed by rules**, not written up by an LLM.

**What the coordinator does in the demo:** opens the queue, clicks the top-value multi-flag claim, reads why, applies the fix, rechecks, gets SUBMIT. Then sees a HOLD that means "wait" and an assumption tag that means "ask". A non-engineer can follow it.

**Minutes (honest):** `queue.html` with sort, cards and thin-pair tags: **15**. `recheck`: **10** (the engine is already a function over a dataframe, so this is one-row override plumbing; it's the first core item cut if behind). **Total 25.**

---

## 4. Minimum AI proof in core: slim Bulletin-to-Rule Compiler (C6′)

- **Why rules can't do it:** the input is prose. Turning "for dates of service on or after 1 August 2026, claims must be received within 45 calendar days" into `{payer: PY01, rule_type: timely_filing, params: {days: 45}, effective_from: 2026-08-01, date_basis: DOS, supersedes: 30}` means reading natural language. A regex written for this sentence is the hand-encoding, not a parser. The setup guide's Haiku advice is about model choice *if* you call per claim. It doesn't restrict calls per document (critique-v2 §1).
- **Inputs (core):** Northwind bulletin 2026-07 (positive case) and Summit handbook §9.5 (refusal case). Harbor notice 2026-08 is an optional third (+5 min).
- **Sceptic-proof checks:**
  1. **Gold first.** The hand-written rule in `rules/payers.yaml` is committed (from C3) *before* the compiler is written. Field-by-field diff: payer, rule type, value, effective date, date basis.
  2. **Quote check.** The `source_quote` must be a verbatim substring of the doc (code check).
  3. **Refusal.** §9.5 must return `no_actionable_rule`. An invented rule is a failure.
  4. **Backtest gate.** On approval, C5's ablation shows 49 history flips (47 match actuals) and 17 to_check changes [plan-v2].
- **Human in the loop:** output goes only to `proposed/`, and a one-command approval by the payer-content analyst merges it.
- **Stated limit:** n = 1–2 bulletins. In this pack the best possible result is *parity* with the hand-written rule plus a correct refusal. Its value is speed and coverage at 180+ payers, which this pack **can't measure**. Say exactly that.
- **Minutes:** **30** (one call per doc, JSON schema, quote check, gold diff, `proposed/` + approve, wired to the existing ablation).
- **Funded by:** moving C6 (Haiku Job A, 15 min) to stretch S1, with core notes as templates, and dropping S3 (remark reader; plan-v2 itself says a lookup table works for 16 strings). The rest comes out of the time between the core finishing and the 3h30 polish stop (§5).

---

## 5. Ideas, re-scored and final picks

| # | Idea | AI? | Impact | Build (in core) | Demo | Status |
|---|---|---|---|---|---|---|
| 1 | Clock-out Guardian → **coordinator queue + recheck** (its EVV states are plan action classes) | none | 4 | 25 min | 5 | ⭐ PICK (core C8) |
| 2 | **Bulletin-to-Rule Compiler, slim** | LLM, gold-checked | 4 | 30 min | 5 | ⭐ PICK (core C6′) |
| 3 | Rule Drift Monitor | none | 3 | 0 extra (learned date inside C4/C5 per m4; the drift view stays stretch S4) | 2 (one line in Next) | folded into plan, not a separate pick |
| 4 | Authorization Runway | none | 2 | 0 (D02 rows show `AUTH_SHORTFALL` in the queue; "bill in DOS order" in README) | 1 | folded |
| 5 | Agency Denial Fingerprint | none | — | — | — | **DROPPED**: small cells, off the core job |
| 6 | Certified Clean Claim | none | — | — | — | **DROPPED** from build, Q&A only: nothing in the data tests it |
| 7 | Correspondence reader | LLM | — | — | — | **DROPPED**: no correspondence in the pack |
| — | Haiku Job A action note | LLM | 2 | moved to stretch S1 | 2 | demoted: wording only (critique-v2 M3) |
| — | Haiku Job B remark reader | LLM | 1 | — | — | **DROPPED**: 16 strings, a lookup table works |

**Budget against plan-v2 (core 150, hard stop 3h30 for polish, cap 4h):**

| Line | Min |
|---|---|
| plan-v2 core | 150 |
| + C4 realism (critique M2) | +10 |
| − C6 Haiku Job A → stretch S1 | −15 |
| + C6′ slim compiler | +30 |
| + C8 queue.html (15) + recheck (10) | +25 |
| **New core** | **200** |
| Polish, design PNG, demo dry run (plan-v2 3h30 rule) | 30 |
| **Total** | **230 ≤ 240** |

That leaves about 10 min of slack before the 3h30 stop. Stretch (S1 graded Haiku notes, S2 full risk report, S4 drift view) realistically won't happen, and the demo doesn't need it. **If behind at 2h30:** drop `recheck` (−10), then the Summit refusal case (−5). The C5 holdout comes before C6′ and C8 in build order, so it's never what gets squeezed.

---

## 6. Change list for the Architect (minimal)

1. **§6 demo:** keep the 5 beats and times. Split Live run into 3:00–3:45 proof / 3:45–5:15 queue / 5:15–6:30 rules-current. Problem and Design beats name the compiler path (as in §2 above).
2. **§3.1 core:** add **C8 queue.html + recheck (25 min)** after C5, including the thin-pair `MANUAL_REVIEW` tags and the C020368 assumption tag.
3. **§3.1 core:** move **S6 into core as C6′ slim compiler (30 min)**: Northwind bulletin + Summit §9.5 refusal, gold rule committed in C3 before the compiler runs.
4. **§3.1/§3.2:** C6 Haiku Job A → stretch S1 (template notes in core). Drop S3. S5 becomes an optional reskin of `queue.html`.
5. **C4:** 35 → 45 min (critique M2).
6. **§4.2:** delete "action-class accuracy" and unit-test the mapping instead (m1). `learn.py` must learn the Summit effective date from fit months (m4).
7. **Wording:** "found it himself" / "found in his own runs" → "flagged in pre-build analysis, reproduced and checked in my run" (M1). §2.3 "recommends" → "advises Haiku if calling per claim" (m7). Summit line → "20 of 20 denied, 14 coded D10".

---

## 7. Commercial story (unchanged; Q&A only)

Billing-manager KPIs lead (false holds, denial recall, $ at stake per queue, HOLD vs fix). The pilot KPIs are plan-v2 §8. The scale maths ($38B ÷ 32,000 ≈ $1.19M per provider, every rate beyond that an ASSUMPTION) stays out of the 10 minutes. Q&A answer to "why Exchange4Health?": the queue's reasons need the visit, the auth and the claim outcome together, which only the platform holds. 38.2% of denials (420/1,099 by count) are decided by the EVV record alone, which makes visit-side checks the next step.
