# Critique v2: plan-v2.md and ideas-v2.md

*Client Critic, round 2. I re-ran `profiling/holdout.py`, `profiling/tocheck_risk.py`, `profiling/flips.py` and `plan/scripts/ideas_v2_stats.py`, and traced C007353 by hand. Every number below comes from those runs or from the brief text.*

## 1. Disputed points: where I was wrong

**T1, the Northwind knock-on (C007353). I was wrong, and the Architect's rejection stands.** Traced directly: C007353 is predicted **paid** under the 30-day rule and **D02** under the 45-day bulletin. Its actual outcome is D02. Under the bulletin, earlier claims that used to be D03 are now paid, they draw down the authorization, and that leaves this claim short. plan-v1's "1 paid→D02" was correct. I misread a pandas groupby printout, where the blank cell for "paid" sat in the column I hadn't expected.

**AG008. My v1 number was wrong too.** "0 of 73 non-hourly after July" counted to_check rows. History alone gives **0 of 61**, which is what plan-v2 says. to_check also contains one AG008 non-hourly Summit claim, **C020368** (DOS 2026-10-29, 18 units), predicted D10. ideas-v2 still quotes my 73 and needs to change it to 61.

**The Haiku guidance.** The source text says: *"If your app calls Claude once per claim, Haiku 5.5 is much cheaper for that; running thousands of claims through a large model will use up your credit quickly."* That's advice on **which model to use, if** you call it once per claim. It neither limits you to per-claim calls (plan-v1's reading) nor recommends calling per claim (plan-v2 §2.3: "the cheaper per-claim pattern the setup guide recommends"). My v1 reading holds. plan-v2's wording overstates it slightly. It's harmless, but an assessor who wrote that guide would notice.

## 2. Claims I was asked to verify

| Claim | Verdict |
|---|---|
| Time holdout 97.97% exact vs a 98.27% ceiling | **Reproduces.** Learned Jun–Aug precedence plus the Summit rule, scored on Sep–Oct DOS (1,331 claims): status 98.42%, exact 97.97%, 1 false hold ($38), 20 missed denials, all D99. The ceiling is 1 − 23/1,331 D99 = 98.27%. When history state is simulated instead of taken from actuals, exact accuracy stays at 97.96%. So label leakage through drawdown state is negligible. |
| Summit rule held on 17 of 20 | **Reproduces, but it's flattering in one direction and modest in the other.** All 20 Sep–Oct non-hourly Summit claims were denied, so the rule's *status* call is 20/20. 17 of them carry the amendment remark. Only **14 are coded D10** (3 are coded D99), so the rule's *code* is right on 14 of 20. Say "20/20 denied, 17 with the amendment remark", not "held on 17". |
| Core takes 150 min | The arithmetic checks out (10+20+15+20+35+25+15+10). Whether it's achievable: see M2. |
| Other numbers I spot-checked | All reproduce: 420/1,099 EVV-decided, 441/441 EVV-flagged denied, 128/239 round-ups, 21/65 D02s lost to a later-DOS claim submitted earlier, 5th amendment denial on 2026-07-21, 11 thin-pair to_check claims, 27 D05s (20 duplicating history, 7 duplicating to_check), 0 predictions sensitive to tie order. |

## 3. Were the v1 points fixed or just relabelled?

| v1 | Status | Note |
|---|---|---|
| T2 holdout | **Fixed for real** | Built, reproduces, and is now the headline |
| B1 ownership | **Mostly fixed** | Disclosure, ai_log and no scripted failure are all in. One leftover: see M1 below |
| M1 scope | **Fixed** | 150-min core, timed cut points, separate stretch. Leftover risk is in C4 (M2) |
| M2 ornamental AI | **Relabelled, not fixed** | See M3 below |
| M3 eval | **Mostly fixed** | Holdout, ceiling, non-circular tests. But the to_check risk report is stretch S2 (see m2) |
| M4 outcomes | **Fixed** | Billing KPIs lead, and there's a pilot plan. One metric has no ground truth (m1) |
| M5 rule owner | **Fixed** | Payer-content team, `proposed/` folder, drift monitor |
| M6 ideas overclaim | **Fixed in the plan, still contested in ideas** | See M4 below |
| m1–m8 | **Fixed** | m5's count is 11, not my ~15. I accept their computation |

---

## Blockers

None. The plan would no longer fail the assessment on its own.

## Major

### M1. The "found it himself" wording still contradicts the disclosure (plan §0, C4 "Verify yourself", §6 6:30–8:30)
- C4 says "This is the interleave finding; Poom should find it himself." The demo beat says "How the interleave and precedence were found in his own runs." But Appendix A and three planning files hand him the answer first. He'll *verify* these findings, not *find* them. An assessor who reads the disclosure and then hears "I found" will mark the candidate down on honesty, which is worse than the original B1.
- **A fix must achieve** wording, in the demo and the README, that matches what actually happened: the analysis was done beforehand by disclosed agents, then reproduced and checked in Claude Code. Any credit claimed for discovery has to come from something that genuinely emerged during the build.

### M2. C4 is the riskiest 35 minutes and is underestimated (plan §3.1 C4)
- C4 includes writing the engine and `learn.py`, running D02 twice, tracing one authorization claim by claim by hand, reading the pairwise table, judging thin pairs and approving the precedence order. Each of the other steps has one or two deliverables. This one has six, and the "verify yourself" reading is the part B1 needs most. If it overruns, C5 (the holdout headline) is what gets squeezed, and the 2h00 cut rule only protects C5 by dropping Haiku.
- **A fix must achieve** a C4 budget the candidate has reason to believe, or a split. The holdout headline must not be the casualty of an engine overrun.

### M3. The AI role is relabelled, not fixed (plan §2.3, §3.2, §4.4; ideas §2 Idea 2)
- **What's actually justified is thinner than the plan says.** The reasons given for Job A, "fixes combined and ordered" and "cutting units changes D02/D06", are things the engine can compute: re-run the proposed corrected claim through the same rules. What's left that rules can't do is wording.
  - Job B is admitted to be redundant here ("A lookup table would also work"). ideas-v2 cut the LLM from remarks for exactly that reason.
- **The evidence that AI earns its place is all stretch.** S1 (the graded sample) is first in line but still optional. S6 (the bulletin compiler, the one job the ideas call "the one place rules can't do the job") is **last**, at 40 min, behind a cut order that drops it first. In the likely core-only outcome, the AI is 10 Haiku notes eyeballed in C6, with no comparison against the template.
- **The grading won't convince a sceptic.** The builder grades his own system on 30 notes, "blind", when LLM prose and template text are obvious at a glance.
- **A fix must achieve** one AI job whose value over a non-AI baseline is shown inside the core time, judged in a way a sceptic accepts. Or the plan states plainly that the AI's role is cosmetic and defends that choice.

### M4. Plan and ideas now disagree on the demo, so there's no single story (plan §6, §10; ideas §5)
- **Opener.** Plan §10 rejects the 38.2% stat as an opener, but ideas §5 opens with it.
- **Units calculator.** The plan rejects the calculator UI, but the ideas script a 20-second calculator beat.
- **Hidden-rule beat.** The ideas map onto plan-v1's "7:00–8:15 Hidden rule" slot, which plan-v2 no longer has.
- **AI centrepiece.** The ideas call the compiler the centrepiece, the plan builds it last, and the plan's demo never shows it.
- Ten minutes can't hold two scripts.
- **A fix must achieve** one reconciled demo where every beat is backed by something in the core build, plus an explicit "if S-items exist, swap X for Y" rule.

### M5. The core demo shows nothing a billing coordinator would touch (plan §6 3:00–6:30, S5)
- The user is defined as a billing coordinator. But in the core build the demo is a terminal running `backtest`, a markdown table and a CSV, with two JSON-backed notes. The only view built for a user (S5) is fifth in the drop order. The brief asks for "a live demo". Assessors who lean towards transformation will want to see the coordinator's experience, and a billing lead would ask "where do I click?"
- **A fix must achieve** a live segment where a non-engineer can follow one claim from input to verdict to the action the biller takes. Whatever form it takes, it has to be in the core, not in stretch.

## Minor

- **m1. "Action-class accuracy" has no ground truth** (plan §1.4, §4.2). The history has codes, not actions like HOLD, FIX or WRITE_OFF. Action classes are derived from the predicted code and the EVV status, so scoring them against history is circular. Define an oracle or drop the metric.
- **m2. The to_check risk report is stretch S2** (plan §3.2), but the README confidence statement (§4.3) and the M3 fix rely on its numbers. If S2 is cut, the claims about unseen claims have nothing behind them.
- **m3. The Summit holdout wording.** See §2: use "20/20 denied, 14 coded D10".
- **m4. The holdout script hard-codes the rule's date** (`d10_from='2026-07-01'`) instead of learning it from fit-month data. C5's prompt asks for it to be learned. Make sure the build really does that, or the holdout's "learned rule" isn't learned.
- **m5. AG008: "complied, so not exempt" is an inference.** AG008 billing whole hours from July on fits being told the rule, but it does not prove the rule covers every agency. But it's the only support for predicting D10 on **C020368**, the one AG008 non-hourly to_check claim. Flag that claim as resting on the payer-wide assumption.
- **m6. ideas-v2 still quotes "0 of 73"** (my v1 error). The figure is 0 of 61 in history.
- **m7. plan §2.3 says the guide "recommends" per-claim calls.** It doesn't (see §1).

---

## Verdict

**Would it pass today? Yes, likely with a solid mark.** The evaluation now survives a sceptic: a real time holdout, a stated ceiling, robust status separated from fragile codes, non-circular tests and a risk register for to_check, and the numbers reproduce. Scope fits the time with real cut points. Ownership and rollout are credible. What's still exposed: the claim that AI earns its place, a demo that's two scripts and a terminal, and a "found it myself" line that contradicts the plan's own disclosure.

**The 3 changes that matter most:**
1. **M3:** Put one measured, sceptic-proof AI job inside the core, or say plainly that the AI's role is cosmetic and defend it.
2. **M4 + M5:** One reconciled 10-minute demo, built only on the core, including a segment a billing coordinator could follow.
3. **M1:** Make the demo and README wording match the disclosure: the analysis was done before the build and verified during it, not discovered in it.
